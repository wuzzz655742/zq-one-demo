@echo off
chcp 65001 >nul
cd /d %~dp0
where python >nul 2>nul
if errorlevel 1 (
  echo [Wanmei Chengyi] Python was not found on this computer.
  echo You can open index.html directly, or install Python 3 and run this file again.
  pause
  exit /b 1
)
python serve.py
pause
