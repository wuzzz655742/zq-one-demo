# -*- coding: utf-8 -*-
"""
app.py —— 完美诚毅 App 后端服务（第二阶段）

一个 Flask 进程同时承担两件事（同源，避免跨域）：
  1. /api/...        通用表 CRUD，供前端 HttpRepo 调用，数据落 MySQL；
  2. 其他路径         托管第一阶段的静态前端（index.html / js / vendor）。

启动：
  .venv\\Scripts\\python.exe backend\\app.py
环境变量（可选，主要给测试用）：
  CHENGYI_CONFIG      指定配置文件路径
  CHENGYI_PORT        指定端口
  CHENGYI_NO_BROWSER  设为 1 时不自动开浏览器
"""
import os
import socket
import threading
import traceback
import webbrowser
from pathlib import Path

import flask
from flask import Flask, request, jsonify, send_from_directory, abort

from db import (
    BASE_DIR, STORE_ORDER, ApiError, Repo, connect, load_config,
)

# 前端静态根目录：backend 的上一级（index.html 所在目录）
STATIC_ROOT = BASE_DIR.parent


def create_app(cfg):
    app = Flask(__name__)

    def get_repo():
        if "repo" not in flask.g:
            conn = connect(cfg["mysql"])
            flask.g.conn = conn
            flask.g.repo = Repo(conn)
        return flask.g.repo

    @app.teardown_request
    def _close_conn(exc):
        conn = flask.g.pop("conn", None)
        if conn is not None:
            try:
                conn.close()
            except Exception:
                pass

    def ok(**kwargs):
        return jsonify(dict(ok=True, **kwargs))

    def fail(message, status):
        return jsonify(ok=False, error=message), status

    @app.errorhandler(ApiError)
    def _handle_api_error(e):
        return fail(e.message, e.status)

    @app.errorhandler(404)
    def _handle_404(e):
        if request.path.startswith("/api/"):
            return fail("接口不存在：%s" % request.path, 404)
        return e

    @app.errorhandler(Exception)
    def _handle_all(e):
        traceback.print_exc()
        return fail("服务器错误：%s" % e, 500)

    # ---------- 健康检查 / 连接探测 ----------
    @app.get("/api/health")
    def api_health():
        get_repo()  # 真正建立一次 MySQL 连接，失败会被错误处理捕获
        return ok(app="chengyi-campus-server", db=cfg["mysql"]["database"], stores=STORE_ORDER)

    # ---------- 通用表 CRUD ----------
    @app.get("/api/tables/<store>")
    def api_list(store):
        return ok(data=get_repo().all(store))

    @app.get("/api/tables/<store>/<path:key>")
    def api_get(store, key):
        # 仓储语义：查不到记录是“空结果”而非错误，返回 200 + data=None（前端得到 undefined）
        return ok(data=get_repo().get(store, key))

    @app.put("/api/tables/<store>")
    def api_put(store):
        body = request.get_json(silent=True)
        if not isinstance(body, dict):
            return fail("请求体必须是 JSON 对象", 400)
        return ok(data=get_repo().put(store, body))

    @app.post("/api/tables/<store>/bulk")
    def api_bulk(store):
        body = request.get_json(silent=True)
        if not isinstance(body, list):
            return fail("请求体必须是 JSON 数组", 400)
        count = get_repo().bulk_put(store, body)
        return ok(count=count)

    @app.delete("/api/tables/<store>/<path:key>")
    def api_delete(store, key):
        get_repo().delete(store, key)
        return ok()

    @app.post("/api/tables/<store>/clear")
    def api_clear(store):
        get_repo().clear(store)
        return ok()

    @app.get("/api/export")
    def api_export():
        return ok(data=get_repo().export_all())

    @app.post("/api/replace")
    def api_replace():
        body = request.get_json(silent=True)
        if not isinstance(body, dict) or not isinstance(body.get("data"), dict):
            return fail("请求体需要形如 {data: {表名: [记录]}}", 400)
        get_repo().replace_all(body["data"])
        return ok()

    # ---------- 静态前端托管 ----------
    @app.get("/")
    def index():
        return send_from_directory(STATIC_ROOT, "index.html")

    @app.get("/<path:path>")
    def static_files(path):
        if path.startswith("api/"):
            abort(404)
        target = STATIC_ROOT / path
        try:
            target.relative_to(STATIC_ROOT)  # 防目录穿越
        except ValueError:
            abort(404)
        if target.is_file():
            return send_from_directory(STATIC_ROOT, path)
        # 单页应用兜底：未知前端路径返回首页
        return send_from_directory(STATIC_ROOT, "index.html")

    return app


def find_free_port(host, start, end):
    for port in range(start, end + 1):
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        try:
            sock.bind((host, port))
            return port
        except OSError:
            continue
        finally:
            sock.close()
    return None


def main():
    cfg_path = os.environ.get("CHENGYI_CONFIG")
    cfg = load_config(cfg_path)
    server = cfg["server"]
    host = server.get("host", "127.0.0.1")
    start = int(server.get("port", 8000))
    end = int(server.get("port_end", start))
    env_port = os.environ.get("CHENGYI_PORT")
    port = int(env_port) if env_port else find_free_port(host, start, end)
    if not port:
        print("端口 %d-%d 均被占用，请关闭占用程序后重试。" % (start, end))
        raise SystemExit(1)

    no_browser = bool(os.environ.get("CHENGYI_NO_BROWSER"))
    open_browser = server.get("open_browser", "true").lower() == "true" and not no_browser
    app = create_app(cfg)
    url = "http://%s:%d/index.html" % (host, port)

    print("=" * 56)
    print("  完美诚毅 App 后端已启动（MySQL: %s）" % cfg["mysql"]["database"])
    print("  访问地址：" + url)
    print("  请保持本窗口开启；关闭窗口即停止服务。")
    print("=" * 56)

    if open_browser:
        threading.Timer(1.0, lambda: webbrowser.open(url)).start()
    # 单进程多线程；关闭 reloader 避免开发服务器双开
    app.run(host=host, port=port, threaded=True, debug=False, use_reloader=False)


if __name__ == "__main__":
    main()
