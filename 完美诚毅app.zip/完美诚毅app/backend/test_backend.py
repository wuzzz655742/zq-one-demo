# -*- coding: utf-8 -*-
"""
test_backend.py —— 后端（Flask + MySQL）测试套件

测试库：chengyi_campus_test（与开发库 chengyi_campus 隔离）。
运行：
    .venv\\Scripts\\python.exe backend\\test_backend.py
首次运行会自动在测试库执行 schema.sql 建表（CREATE TABLE IF NOT EXISTS）。
"""
import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from app import create_app, STATIC_ROOT  # noqa: E402
from db import (  # noqa: E402
    BASE_DIR, STORE_ORDER, TABLES, Repo, connect, load_config,
)

TEST_CONFIG = os.path.join(os.path.dirname(os.path.abspath(__file__)), "config.test.ini")
CFG = load_config(TEST_CONFIG)


def _build_schema(conn):
    """在测试库执行 schema.sql 中的 CREATE TABLE 语句（跳过建库/USE/注释）。"""
    sql = (BASE_DIR / "schema.sql").read_text(encoding="utf-8")
    lines = [ln for ln in sql.splitlines() if not ln.strip().startswith("--")]
    statements = "\n".join(lines).split(";")
    with conn.cursor() as cur:
        for stmt in statements:
            head = stmt.strip().upper()
            if not head:
                continue
            if head.startswith("CREATE DATABASE") or head.startswith("USE "):
                continue
            cur.execute(stmt)
    conn.commit()


def _admin_conn():
    return connect(CFG["mysql"])


def _empty_all(conn):
    with conn.cursor() as cur:
        for store in STORE_ORDER:
            cur.execute("DELETE FROM `%s`" % TABLES[store]["table"])
    conn.commit()


def setUpModule():
    conn = _admin_conn()
    try:
        _build_schema(conn)
    finally:
        conn.close()


class BackendApiTest(unittest.TestCase):
    def setUp(self):
        conn = _admin_conn()
        _empty_all(conn)
        conn.close()
        self.app = create_app(CFG)
        self.client = self.app.test_client()

    # ---------- 健康检查 ----------
    def test_health(self):
        r = self.client.get("/api/health")
        self.assertEqual(r.status_code, 200)
        body = r.get_json()
        self.assertTrue(body["ok"])
        self.assertEqual(body["db"], "chengyi_campus_test")
        self.assertEqual(len(body["stores"]), 15)

    # ---------- 增 / 查 / 改 / 删 ----------
    def test_put_get_all_delete(self):
        shop = {"id": "shop_t1", "name": "测试餐厅", "category": "外卖",
                "deliveryDesc": "校内自取", "minOrder": 10, "icon": "canteen",
                "color": "#ff8a3d", "notice": "测试公告"}
        r = self.client.put("/api/tables/shops", json=shop)
        self.assertEqual(r.status_code, 200, r.get_data(as_text=True))
        self.assertEqual(r.get_json()["data"]["name"], "测试餐厅")

        r = self.client.get("/api/tables/shops/shop_t1")
        self.assertEqual(r.status_code, 200)
        self.assertEqual(r.get_json()["data"]["minOrder"], 10.0)
        self.assertIsInstance(r.get_json()["data"]["minOrder"], float)

        r = self.client.get("/api/tables/shops")
        self.assertEqual(len(r.get_json()["data"]), 1)

        r = self.client.get("/api/tables/shops/not_exist")
        self.assertEqual(r.status_code, 200)
        body = r.get_json()
        self.assertTrue(body["ok"])
        self.assertIsNone(body["data"])

        r = self.client.delete("/api/tables/shops/shop_t1")
        self.assertTrue(r.get_json()["ok"])
        self.assertEqual(len(self.client.get("/api/tables/shops").get_json()["data"]), 0)

    def test_upsert_updates_instead_of_duplicate(self):
        shop = {"id": "shop_u", "name": "旧名", "category": "外卖", "minOrder": 0}
        self.client.put("/api/tables/shops", json=shop)
        shop["name"] = "新名"
        shop["minOrder"] = 20
        self.client.put("/api/tables/shops", json=shop)
        rows = self.client.get("/api/tables/shops").get_json()["data"]
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]["name"], "新名")
        self.assertEqual(rows[0]["minOrder"], 20.0)

    def test_bulk_insert(self):
        products = [
            {"id": "p1", "shopId": "shop_t1", "name": "商品1", "price": 0.2, "unit": "张",
             "category": "打印", "icon": "print", "stock": "normal", "desc": ""},
            {"id": "p2", "shopId": "shop_t1", "name": "商品2", "price": 3.5, "unit": "罐",
             "category": "饮料", "icon": "water", "stock": "normal", "desc": ""},
        ]
        r = self.client.post("/api/tables/products/bulk", json=products)
        self.assertEqual(r.status_code, 200, r.get_data(as_text=True))
        self.assertEqual(r.get_json()["count"], 2)
        self.assertEqual(len(self.client.get("/api/tables/products").get_json()["data"]), 2)

    # ---------- 类型保真 ----------
    def test_type_conversions(self):
        # DECIMAL -> float
        self.client.put("/api/tables/products", json={
            "id": "pr_dec", "shopId": "s", "name": "打印", "price": 0.2, "unit": "张"})
        pr = self.client.get("/api/tables/products/pr_dec").get_json()["data"]
        self.assertAlmostEqual(pr["price"], 0.2, places=6)
        self.assertIsInstance(pr["price"], float)

        # settings/meta value 为 JSON，混合类型保真
        self.client.put("/api/tables/settings", json={"key": "cardBalance", "value": 14.18})
        self.client.put("/api/tables/settings", json={"key": "semesterStart", "value": "2026-09-07"})
        bal = self.client.get("/api/tables/settings/cardBalance").get_json()["data"]
        sem = self.client.get("/api/tables/settings/semesterStart").get_json()["data"]
        self.assertEqual(bal["value"], 14.18)
        self.assertIsInstance(bal["value"], float)
        self.assertEqual(sem["value"], "2026-09-07")
        self.assertIsInstance(sem["value"], str)

        # notices.createdAt 为 int
        self.client.put("/api/tables/notices", json={
            "id": "notice_x", "iconType": "horn", "content": "通知", "timeText": "", "createdAt": 2})
        nc = self.client.get("/api/tables/notices/notice_x").get_json()["data"]
        self.assertEqual(nc["createdAt"], 2)
        self.assertIsInstance(nc["createdAt"], int)

        # memos.done 为 int
        self.client.put("/api/tables/memos", json={
            "id": "m1", "userId": "u1", "content": "备忘", "done": 1,
            "createdAt": "2026-10-01T00:00:00.000Z", "completedAt": "2026-10-01T01:00:00.000Z"})
        mm = self.client.get("/api/tables/memos/m1").get_json()["data"]
        self.assertEqual(mm["done"], 1)
        self.assertIsInstance(mm["done"], int)

        # orders.items / logs 为 JSON 数组
        order = {
            "id": "o1", "orderNo": "CY1", "userId": "u1", "shopId": "shop_t1", "shopName": "店",
            "items": [{"productId": "p1", "name": "商品1", "price": 0.2, "qty": 3, "remark": ""}],
            "total": 0.6, "pickupNote": "", "status": "pending",
            "createdAt": "2026-10-01T00:00:00.000Z", "completedAt": "",
            "logs": [{"status": "pending", "at": "2026-10-01T00:00:00.000Z"}],
        }
        self.client.put("/api/tables/orders", json=order)
        oo = self.client.get("/api/tables/orders/o1").get_json()["data"]
        self.assertIsInstance(oo["items"], list)
        self.assertEqual(oo["items"][0]["qty"], 3)
        self.assertIsInstance(oo["logs"], list)
        self.assertEqual(oo["logs"][0]["status"], "pending")

    # ---------- 中文持久化（utf8mb4） ----------
    def test_chinese_persistence(self):
        topic = {"id": "t1", "title": "图书馆占座也太卷了吧",
                 "content": "早上八点到图书馆已经快满了，建议大家互相体谅。",
                 "authorId": "u1", "createdAt": "2026-10-01T00:00:00.000Z",
                 "updatedAt": "2026-10-01T00:00:00.000Z"}
        self.client.put("/api/tables/topics", json=topic)
        got = self.client.get("/api/tables/topics/t1").get_json()["data"]
        self.assertEqual(got["title"], topic["title"])
        self.assertEqual(got["content"], topic["content"])

    # ---------- 导出 / 清空 ----------
    def test_export_and_clear(self):
        self.client.put("/api/tables/memos", json={
            "id": "m1", "userId": "u1", "content": "x", "done": 0,
            "createdAt": "2026-10-01T00:00:00.000Z", "completedAt": ""})
        data = self.client.get("/api/export").get_json()["data"]
        self.assertEqual(set(data.keys()), set(STORE_ORDER))
        self.assertEqual(len(data["memos"]), 1)

        self.client.post("/api/tables/memos/clear")
        self.assertEqual(len(self.client.get("/api/tables/memos").get_json()["data"]), 0)

    # ---------- 整库替换：前置校验失败不写入 ----------
    def test_replace_rejects_bad_shape(self):
        # 先放一条旧商家
        self.client.put("/api/tables/shops", json={"id": "shop_keep", "name": "保留店",
                                                   "category": "外卖", "minOrder": 0})
        # 含缺少主键的记录
        bad = {"data": {"shops": [{"name": "无主键"}], "memos": []}}
        r = self.client.post("/api/replace", json=bad)
        self.assertEqual(r.status_code, 400)
        # 旧数据未受影响
        shops = self.client.get("/api/tables/shops").get_json()["data"]
        self.assertTrue(any(s["id"] == "shop_keep" for s in shops))
        # 请求体形状错误
        r = self.client.post("/api/replace", json={"nope": 1})
        self.assertEqual(r.status_code, 400)

    # ---------- 整库替换：正常写入 ----------
    def test_replace_success(self):
        payload = {"data": {
            "memos": [{"id": "m1", "userId": "u1", "content": "迁移备忘", "done": 0,
                       "createdAt": "2026-10-01T00:00:00.000Z", "completedAt": ""}],
            "shops": [{"id": "shop_a", "name": "迁移店", "category": "超市", "minOrder": 5}],
        }}
        r = self.client.post("/api/replace", json=payload)
        self.assertEqual(r.status_code, 200, r.get_data(as_text=True))
        self.assertEqual(len(self.client.get("/api/tables/memos").get_json()["data"]), 1)
        self.assertEqual(len(self.client.get("/api/tables/shops").get_json()["data"]), 1)

    # ---------- 错误处理 ----------
    def test_errors(self):
        self.assertEqual(self.client.get("/api/tables/not_a_store").status_code, 404)
        r = self.client.put("/api/tables/shops", json=["not", "object"])
        self.assertEqual(r.status_code, 400)
        r = self.client.put("/api/tables/shops", json={"name": "缺主键"})
        self.assertEqual(r.status_code, 400)
        r = self.client.post("/api/tables/shops/bulk", json={"not": "list"})
        self.assertEqual(r.status_code, 400)

    # ---------- 静态前端托管 ----------
    def test_static_serving(self):
        r = self.client.get("/")
        self.assertEqual(r.status_code, 200)
        self.assertIn(b"<html", r.data.lower())
        r.close()
        r = self.client.get("/js/core.js")
        self.assertEqual(r.status_code, 200)
        self.assertIn(b"AppCore", r.data)
        r.close()
        r = self.client.get("/vendor/xlsx.full.min.js")
        self.assertEqual(r.status_code, 200)
        r.close()


class RepoTransactionTest(unittest.TestCase):
    """白盒：验证 replace_all 中途失败时事务整体回滚。"""

    def setUp(self):
        conn = _admin_conn()
        _empty_all(conn)
        self.conn = conn
        self.repo = Repo(conn)

    def tearDown(self):
        self.conn.close()

    def test_replace_rolls_back_on_mid_failure(self):
        self.repo.put("shops", {"id": "shop_old", "name": "旧店", "category": "外卖",
                                "minOrder": 10, "icon": "x", "color": "#000000",
                                "notice": "", "deliveryDesc": ""})
        data = {
            "memos": [{"id": "m1", "userId": "u1", "content": "a", "done": 0,
                       "createdAt": "t", "completedAt": ""}],
            "shops": [{"id": "shop_new", "name": "新店", "category": "超市", "minOrder": 0}],
        }
        calls = {"n": 0}
        original = Repo._upsert

        def boom(self, cur, spec, row):
            calls["n"] += 1
            if calls["n"] >= 2:
                raise RuntimeError("模拟写入中途失败")
            return original(self, cur, spec, row)

        Repo._upsert = boom
        try:
            with self.assertRaises(RuntimeError):
                self.repo.replace_all(data)
        finally:
            Repo._upsert = original

        # 回滚后：旧店仍在；memos 的清空/插入也被撤销（回到空）
        shops = self.repo.all("shops")
        self.assertTrue(any(s["id"] == "shop_old" for s in shops))
        self.assertEqual(self.repo.all("memos"), [])


if __name__ == "__main__":
    unittest.main(verbosity=2)
