# -*- coding: utf-8 -*-
"""
db.py —— 完美诚毅 App 后端数据访问层
职责：
  1. 读取本机 MySQL 连接配置；
  2. 维护前端 IndexedDB store 名 -> MySQL 表名/列类型的映射；
  3. 在「前端整条记录(JSON 对象)」与「MySQL 强类型列」之间做转换；
  4. 提供与前端仓储层一致的通用 CRUD，以及事务式整库替换（备份恢复原子性）。
仅依赖 PyMySQL，不依赖 Web 框架，便于单元测试。
"""
import configparser
import json
from pathlib import Path

import pymysql
from pymysql.cursors import DictCursor

BASE_DIR = Path(__file__).resolve().parent
DEFAULT_CONFIG = BASE_DIR / "config.ini"

# 列类型标记：
#   str      普通文本（VARCHAR/TEXT/LONGTEXT），原样存取
#   int      整型（qty / weekday / done / notices.createdAt）
#   decimal  金额（DECIMAL），读出转 float，金额取整仍由前端 round2 负责
#   json     原生 JSON 列（settings/meta.value、orders.items、orders.logs）
#   jsontext LONGTEXT 存整段 JSON（snapshots.data），读写均做 JSON 编解码
TABLES = {
    "meta": {
        "table": "meta", "pk": "key",
        "cols": {"key": "str", "value": "json"},
    },
    "settings": {
        "table": "settings", "pk": "key",
        "cols": {"key": "str", "value": "json"},
    },
    "session": {
        "table": "session", "pk": "key",
        "cols": {"key": "str", "userId": "str", "at": "str"},
    },
    "users": {
        "table": "users", "pk": "id",
        "cols": {
            "id": "str", "username": "str", "passwordHash": "str", "salt": "str",
            "nickname": "str", "school": "str", "studentNo": "str", "avatar": "str",
            "avatarColor": "str", "signature": "str", "createdAt": "str", "lastLoginAt": "str",
        },
    },
    "courses": {
        "table": "courses", "pk": "id",
        "cols": {
            "id": "str", "userId": "str", "name": "str", "teacher": "str", "location": "str",
            "startTime": "str", "endTime": "str", "weekday": "int", "startDate": "str",
            "endDate": "str", "repeat": "str", "color": "str", "note": "str",
            "createdAt": "str", "updatedAt": "str",
        },
    },
    "memos": {
        "table": "memos", "pk": "id",
        "cols": {
            "id": "str", "userId": "str", "content": "str", "done": "int",
            "createdAt": "str", "completedAt": "str",
        },
    },
    "shops": {
        "table": "shops", "pk": "id",
        "cols": {
            "id": "str", "name": "str", "category": "str", "deliveryDesc": "str",
            "minOrder": "decimal", "icon": "str", "color": "str", "notice": "str",
        },
    },
    "products": {
        "table": "products", "pk": "id",
        "cols": {
            "id": "str", "shopId": "str", "name": "str", "price": "decimal", "unit": "str",
            "category": "str", "icon": "str", "stock": "str", "desc": "str",
        },
    },
    "cart": {
        "table": "cart", "pk": "id",
        "cols": {
            "id": "str", "userId": "str", "shopId": "str", "productId": "str",
            "name": "str", "price": "decimal", "qty": "int", "remark": "str",
        },
    },
    "orders": {
        "table": "orders", "pk": "id",
        "cols": {
            "id": "str", "orderNo": "str", "userId": "str", "shopId": "str", "shopName": "str",
            "items": "json", "total": "decimal", "pickupNote": "str", "status": "str",
            "createdAt": "str", "completedAt": "str", "logs": "json",
        },
    },
    "topics": {
        "table": "topics", "pk": "id",
        "cols": {
            "id": "str", "title": "str", "content": "str", "authorId": "str",
            "createdAt": "str", "updatedAt": "str",
        },
    },
    "replies": {
        "table": "replies", "pk": "id",
        "cols": {
            "id": "str", "topicId": "str", "content": "str", "authorId": "str", "createdAt": "str",
        },
    },
    "notices": {
        "table": "notices", "pk": "id",
        "cols": {
            "id": "str", "iconType": "str", "content": "str", "timeText": "str", "createdAt": "int",
        },
    },
    "noticeDismiss": {
        "table": "notice_dismiss", "pk": "id",
        "cols": {"id": "str", "userId": "str", "noticeId": "str", "at": "str"},
    },
    "snapshots": {
        "table": "snapshots", "pk": "id",
        "cols": {"id": "str", "createdAt": "str", "reason": "str", "data": "jsontext"},
    },
}

# 与前端 db.js 的 STORES 顺序保持一致
STORE_ORDER = [
    "meta", "settings", "users", "session", "courses", "memos", "shops", "products",
    "cart", "orders", "topics", "replies", "notices", "noticeDismiss", "snapshots",
]


class ApiError(Exception):
    """业务错误，携带 HTTP 状态码。"""

    def __init__(self, message, status=400):
        super().__init__(message)
        self.message = message
        self.status = status


def load_config(path=None):
    """读取 config.ini；path 为 None 时读取 backend/config.ini。"""
    cfg_path = Path(path) if path else DEFAULT_CONFIG
    cp = configparser.ConfigParser()
    if not cfg_path.exists():
        raise ApiError("找不到配置文件：%s" % cfg_path, 500)
    cp.read(cfg_path, encoding="utf-8")
    return {"mysql": dict(cp["mysql"]), "server": dict(cp["server"])}


def connect(mysql_cfg, database=None):
    """建立一个 PyMySQL 连接（autocommit=False，写操作需显式 commit）。"""
    cfg = dict(mysql_cfg)
    cfg["port"] = int(cfg.get("port", 3306))
    if database:
        cfg["database"] = database
    cfg.setdefault("charset", "utf8mb4")
    cfg["cursorclass"] = DictCursor
    cfg["autocommit"] = False
    return pymysql.connect(**cfg)


def spec(store):
    s = TABLES.get(store)
    if not s:
        raise ApiError("未知的数据表：%s" % store, 404)
    return s


def to_db(col_type, value):
    """前端 JSON 值 -> 写入 MySQL 的 Python 值。"""
    if value is None:
        return None
    if col_type in ("json", "jsontext"):
        return json.dumps(value, ensure_ascii=False)
    if col_type == "int":
        if value == "":
            return None
        try:
            return int(value)
        except (TypeError, ValueError):
            return None
    if col_type == "decimal":
        if value == "":
            return None
        try:
            return float(value)
        except (TypeError, ValueError):
            return None
    # str
    if isinstance(value, str):
        return value
    return str(value)


def from_db(col_type, value):
    """MySQL 读出的 Python 值 -> 前端 JSON 值。"""
    if value is None:
        return None
    if col_type == "int":
        return int(value)
    if col_type == "decimal":
        return float(value)
    if col_type in ("json", "jsontext"):
        if isinstance(value, (dict, list)):
            return value
        if isinstance(value, (bytes, bytearray)):
            value = value.decode("utf-8")
        if isinstance(value, str):
            if value == "":
                return None
            return json.loads(value)
        return value
    if isinstance(value, (bytes, bytearray)):
        return value.decode("utf-8")
    return value


class Repo:
    """通用仓储：方法集合与前端 IDBRepo/MemRepo 对齐。"""

    def __init__(self, conn):
        self.conn = conn

    def _cursor(self):
        # 每个 HTTP 请求使用新建连接（请求结束即关闭），无需 ping 重连
        return self.conn.cursor()

    @staticmethod
    def _to_obj(s, row):
        if row is None:
            return None
        out = {}
        for col, col_type in s["cols"].items():
            out[col] = from_db(col_type, row.get(col))
        return out

    def all(self, store):
        s = spec(store)
        with self._cursor() as cur:
            cur.execute("SELECT * FROM `%s`" % s["table"])
            rows = cur.fetchall()
        return [self._to_obj(s, r) for r in rows]

    def get(self, store, key):
        s = spec(store)
        with self._cursor() as cur:
            cur.execute("SELECT * FROM `%s` WHERE `%s`=%%s" % (s["table"], s["pk"]), (key,))
            row = cur.fetchone()
        return self._to_obj(s, row)

    def _upsert(self, cur, s, row):
        pk = s["pk"]
        if not isinstance(row, dict):
            raise ApiError("记录必须是 JSON 对象")
        if row.get(pk) in (None, ""):
            raise ApiError("记录缺少主键：%s" % pk)
        cols = [c for c in s["cols"] if c in row]
        if pk not in cols:
            cols.insert(0, pk)
        vals = [to_db(s["cols"][c], row.get(c)) for c in cols]
        sql = "INSERT INTO `%s` (%s) VALUES (%s)" % (
            s["table"], ",".join("`%s`" % c for c in cols), ",".join(["%s"] * len(cols)))
        upd = [c for c in cols if c != pk]
        if upd:
            sql += " ON DUPLICATE KEY UPDATE " + \
                   ",".join("`%s`=VALUES(`%s`)" % (c, c) for c in upd)
        cur.execute(sql, vals)

    def put(self, store, row):
        s = spec(store)
        try:
            with self._cursor() as cur:
                self._upsert(cur, s, row)
            self.conn.commit()
        except Exception:
            self.conn.rollback()
            raise
        return self.get(store, row[s["pk"]])

    def bulk_put(self, store, rows):
        if not isinstance(rows, list):
            raise ApiError("批量写入数据必须是数组")
        s = spec(store)
        try:
            with self._cursor() as cur:
                for row in rows:
                    self._upsert(cur, s, row)
            self.conn.commit()
        except Exception:
            self.conn.rollback()
            raise
        return len(rows)

    def delete(self, store, key):
        s = spec(store)
        try:
            with self._cursor() as cur:
                cur.execute("DELETE FROM `%s` WHERE `%s`=%%s" % (s["table"], s["pk"]), (key,))
            self.conn.commit()
        except Exception:
            self.conn.rollback()
            raise
        return True

    def clear(self, store):
        s = spec(store)
        try:
            with self._cursor() as cur:
                cur.execute("DELETE FROM `%s`" % s["table"])
            self.conn.commit()
        except Exception:
            self.conn.rollback()
            raise
        return True

    def export_all(self):
        return {store: self.all(store) for store in STORE_ORDER}

    def replace_all(self, data):
        """整库替换：单事务内逐表 清空->重写；任一步失败整体回滚，旧数据保留。"""
        if not isinstance(data, dict):
            raise ApiError("恢复数据必须是 {表名: [记录]} 的对象")
        names = list(data.keys())
        for n in names:  # 未知表立即报错
            spec(n)
        # 先做全部静态校验，失败则在开启写事务前中止
        for n in names:
            s = spec(n)
            rows = data[n]
            if not isinstance(rows, list):
                raise ApiError("数据表内容不是数组：%s" % n)
            for row in rows:
                if not isinstance(row, dict) or row.get(s["pk"]) in (None, ""):
                    raise ApiError("数据表 %s 存在缺少主键的记录" % n)
        try:
            with self._cursor() as cur:
                for n in names:
                    s = spec(n)
                    cur.execute("DELETE FROM `%s`" % s["table"])
                    for row in data[n]:
                        self._upsert(cur, s, row)
            self.conn.commit()
        except Exception:
            self.conn.rollback()
            raise
        return True
