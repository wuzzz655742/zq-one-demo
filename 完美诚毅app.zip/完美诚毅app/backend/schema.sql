-- ============================================================
-- 完美诚毅校园 App · MySQL 建表脚本（第二阶段）
-- 库: chengyi_campus   字符集: utf8mb4   引擎: InnoDB
-- 幂等：可重复执行（CREATE TABLE IF NOT EXISTS / CREATE DATABASE IF NOT EXISTS）
--
-- 设计约定：
--   1. 主键沿用前端字符串 ID（u_ / c_ / m_ / cart_ / o_ / t_ / r_ / snap_ 等）；
--   2. 主字段全部建成独立列，便于在 Navicat 中直接可视化增删改查；
--   3. 嵌套数组（orders.items / orders.logs）用原生 JSON 列；
--   4. 键值表 meta/settings 的 value 类型不固定（数字/字符串），用 JSON 列保真；
--   5. 头像 dataURL、整库快照体积较大，用 LONGTEXT；
--   6. 时间沿用前端 ISO 字符串存 VARCHAR，避免时区转换（后续可升级 DATETIME）。
-- ============================================================

CREATE DATABASE IF NOT EXISTS chengyi_campus
  CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;
USE chengyi_campus;

-- ---------- 键值表 ----------
CREATE TABLE IF NOT EXISTS meta (
  `key`   VARCHAR(64) NOT NULL,
  `value` JSON NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS settings (
  `key`   VARCHAR(64) NOT NULL,
  `value` JSON NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ---------- 会话（当前登录） ----------
CREATE TABLE IF NOT EXISTS session (
  `key`    VARCHAR(32) NOT NULL,
  `userId` VARCHAR(40) NULL,
  `at`     VARCHAR(40) NULL,
  PRIMARY KEY (`key`),
  KEY idx_session_user (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ---------- 用户 ----------
CREATE TABLE IF NOT EXISTS users (
  id            VARCHAR(40) NOT NULL,
  username      VARCHAR(64) NOT NULL,
  passwordHash  VARCHAR(128) NULL,
  salt          VARCHAR(64) NULL,
  nickname      VARCHAR(64) NULL,
  school        VARCHAR(128) NULL,
  studentNo     VARCHAR(32) NULL,
  avatar        LONGTEXT NULL,
  avatarColor   VARCHAR(20) NULL,
  signature     VARCHAR(128) NULL,
  createdAt     VARCHAR(40) NULL,
  lastLoginAt   VARCHAR(40) NULL,
  PRIMARY KEY (id),
  UNIQUE KEY ux_users_username (username)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ---------- 课程 ----------
CREATE TABLE IF NOT EXISTS courses (
  id         VARCHAR(40) NOT NULL,
  userId     VARCHAR(40) NOT NULL,
  name       VARCHAR(128) NOT NULL,
  teacher    VARCHAR(64) NULL,
  location   VARCHAR(128) NOT NULL,
  startTime  VARCHAR(8) NULL,
  endTime    VARCHAR(8) NULL,
  weekday    TINYINT NULL,
  startDate  VARCHAR(12) NULL,
  endDate    VARCHAR(12) NULL,
  `repeat`   VARCHAR(10) NULL,
  color      VARCHAR(20) NULL,
  note       VARCHAR(500) NULL,
  createdAt  VARCHAR(40) NULL,
  updatedAt  VARCHAR(40) NULL,
  PRIMARY KEY (id),
  KEY idx_courses_user_week (`userId`, `weekday`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ---------- 备忘 ----------
CREATE TABLE IF NOT EXISTS memos (
  id           VARCHAR(40) NOT NULL,
  userId       VARCHAR(40) NOT NULL,
  content      TEXT NULL,
  done         TINYINT NOT NULL DEFAULT 0,
  createdAt    VARCHAR(40) NULL,
  completedAt  VARCHAR(40) NULL,
  PRIMARY KEY (id),
  KEY idx_memos_user_done (`userId`, `done`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ---------- 商家 ----------
CREATE TABLE IF NOT EXISTS shops (
  id            VARCHAR(40) NOT NULL,
  name          VARCHAR(128) NULL,
  category      VARCHAR(20) NULL,
  deliveryDesc  VARCHAR(128) NULL,
  minOrder      DECIMAL(10,2) NULL DEFAULT 0,
  icon          VARCHAR(40) NULL,
  color         VARCHAR(20) NULL,
  notice        VARCHAR(255) NULL,
  PRIMARY KEY (id),
  KEY idx_shops_category (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ---------- 商品 ----------
CREATE TABLE IF NOT EXISTS products (
  id        VARCHAR(40) NOT NULL,
  shopId    VARCHAR(40) NOT NULL,
  name      VARCHAR(128) NULL,
  price     DECIMAL(10,2) NULL DEFAULT 0,
  unit      VARCHAR(12) NULL,
  category  VARCHAR(20) NULL,
  icon      VARCHAR(40) NULL,
  stock     VARCHAR(12) NULL,
  `desc`    VARCHAR(500) NULL,
  PRIMARY KEY (id),
  KEY idx_products_shop (`shopId`),
  KEY idx_products_category (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ---------- 购物车 ----------
CREATE TABLE IF NOT EXISTS cart (
  id         VARCHAR(40) NOT NULL,
  userId     VARCHAR(40) NOT NULL,
  shopId     VARCHAR(40) NULL,
  productId  VARCHAR(40) NULL,
  name       VARCHAR(128) NULL,
  price      DECIMAL(10,2) NULL DEFAULT 0,
  qty        INT NOT NULL DEFAULT 1,
  remark     VARCHAR(128) NULL,
  PRIMARY KEY (id),
  KEY idx_cart_user (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ---------- 订单（明细 items / 状态日志 logs 为 JSON） ----------
CREATE TABLE IF NOT EXISTS orders (
  id           VARCHAR(40) NOT NULL,
  orderNo      VARCHAR(32) NULL,
  userId       VARCHAR(40) NOT NULL,
  shopId       VARCHAR(40) NULL,
  shopName     VARCHAR(128) NULL,
  items        JSON NULL,
  total        DECIMAL(10,2) NULL DEFAULT 0,
  pickupNote   VARCHAR(200) NULL,
  status       VARCHAR(12) NULL,
  createdAt    VARCHAR(40) NULL,
  completedAt  VARCHAR(40) NULL,
  logs         JSON NULL,
  PRIMARY KEY (id),
  KEY idx_orders_user_status (`userId`, `status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ---------- 论坛话题 ----------
CREATE TABLE IF NOT EXISTS topics (
  id         VARCHAR(40) NOT NULL,
  title      VARCHAR(128) NULL,
  content    MEDIUMTEXT NULL,
  authorId   VARCHAR(40) NULL,
  createdAt  VARCHAR(40) NULL,
  updatedAt  VARCHAR(40) NULL,
  PRIMARY KEY (id),
  KEY idx_topics_author (`authorId`),
  KEY idx_topics_created (`createdAt`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ---------- 论坛评论 ----------
CREATE TABLE IF NOT EXISTS replies (
  id         VARCHAR(40) NOT NULL,
  topicId    VARCHAR(40) NOT NULL,
  content    TEXT NULL,
  authorId   VARCHAR(40) NULL,
  createdAt  VARCHAR(40) NULL,
  PRIMARY KEY (id),
  KEY idx_replies_topic (`topicId`),
  KEY idx_replies_author (`authorId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ---------- 通知（createdAt 为前端数字序号 0/1/2） ----------
CREATE TABLE IF NOT EXISTS notices (
  id         VARCHAR(40) NOT NULL,
  iconType   VARCHAR(20) NULL,
  content    VARCHAR(500) NULL,
  timeText   VARCHAR(20) NULL,
  createdAt  INT NULL DEFAULT 0,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ---------- 通知关闭记录（id = userId__noticeId） ----------
CREATE TABLE IF NOT EXISTS notice_dismiss (
  id        VARCHAR(80) NOT NULL,
  userId    VARCHAR(40) NULL,
  noticeId  VARCHAR(40) NULL,
  `at`      VARCHAR(40) NULL,
  PRIMARY KEY (id),
  KEY idx_noticedismiss_user (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ---------- 本地快照（data 为整库 JSON，体积可能较大） ----------
CREATE TABLE IF NOT EXISTS snapshots (
  id         VARCHAR(40) NOT NULL,
  createdAt  VARCHAR(40) NULL,
  reason     VARCHAR(40) NULL,
  data       LONGTEXT NULL,
  PRIMARY KEY (id),
  KEY idx_snapshots_created (`createdAt`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
