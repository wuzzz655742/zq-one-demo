@echo off
rem ============================================================
rem  Wanmei Chengyi Campus App - MySQL / Flask backend launcher
rem  Double-click this file to:
rem    1. make sure the MySQL84 service is running
rem    2. start the Flask backend with the bundled .venv
rem    3. open the app in your browser automatically
rem  Keep this window open while using the app; close it to stop.
rem ============================================================
setlocal
cd /d "%~dp0"

echo ==================================================
echo   Wanmei Chengyi Campus  ( MySQL edition )
echo ==================================================

rem ---- 1) Ensure the MySQL service (MySQL84) is running ----
set "MYSQL_SVC=MySQL84"
sc query "%MYSQL_SVC%" | find /I "RUNNING" >nul 2>&1
if errorlevel 1 (
  echo [1/3] MySQL service "%MYSQL_SVC%" is stopped, starting it ...
  net start "%MYSQL_SVC%" >nul 2>&1
  sc query "%MYSQL_SVC%" | find /I "RUNNING" >nul 2>&1
  if errorlevel 1 (
    echo.
    echo [ERROR] MySQL service "%MYSQL_SVC%" is not running and could not be started.
    echo         Start it manually, or right-click this file and "Run as administrator",
    echo         then double-click it again.
    echo.
    pause
    exit /b 1
  )
) else (
  echo [1/3] MySQL service "%MYSQL_SVC%" is running.
)

rem ---- 2) Prefer the bundled virtual environment ----
set "PYEXE=.venv\Scripts\python.exe"
if exist "%PYEXE%" (
  echo [2/3] Using virtual environment .venv
) else (
  echo [2/3] .venv not found, falling back to system python.
  echo       If it fails to start, install deps first:
  echo       python -m pip install -r backend\requirements.txt
  set "PYEXE=python"
)

rem ---- 3) Start the backend (it opens the browser itself) ----
echo [3/3] Starting backend, the browser will open automatically ...
echo       Address: http://127.0.0.1:8000/index.html
echo       Keep THIS window open. Close it to stop the server.
echo.
"%PYEXE%" backend\app.py

echo.
echo Backend has stopped.
pause
