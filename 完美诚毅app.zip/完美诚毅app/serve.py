# -*- coding: utf-8 -*-
"""完美诚毅 本地启动器：探测空闲端口 -> 启动静态服务 -> 自动打开浏览器。
仅使用 Python 标准库，无需联网。"""
import http.server
import socketserver
import webbrowser
import socket
import os
import sys


def find_port(start=8000, end=8020):
    for port in range(start, end + 1):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            try:
                s.bind(("127.0.0.1", port))
                return port
            except OSError:
                continue
    return None


class NoCacheHandler(http.server.SimpleHTTPRequestHandler):
    def end_headers(self):
        self.send_header("Cache-Control", "no-store, must-revalidate")
        super().end_headers()

    def log_message(self, *args):
        pass


def main():
    os.chdir(os.path.dirname(os.path.abspath(__file__)))
    port = find_port()
    if port is None:
        print("8000-8020 ports are all in use. Please close other programs and retry.")
        sys.exit(1)
    url = "http://127.0.0.1:%d/index.html" % port
    print("=" * 52)
    print("  Wanmei Chengyi Campus App is running at:")
    print("  " + url)
    print("  Keep this window open while using the app.")
    print("  Close this window to stop the local server.")
    print("=" * 52)
    try:
        webbrowser.open(url)
    except Exception:
        pass
    with socketserver.TCPServer(("127.0.0.1", port), NoCacheHandler) as httpd:
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("\nServer stopped.")


if __name__ == "__main__":
    main()
