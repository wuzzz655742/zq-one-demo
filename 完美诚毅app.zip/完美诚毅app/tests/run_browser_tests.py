﻿# -*- coding: utf-8 -*-
"""
Edge 无头浏览器端到端测试（CDP 直接驱动真实 index.html，真实 IndexedDB + 真实时间）：
  1) 全新 profile：注入主世界测试流程，跑完 M2 账户体系 16 项断言
  2) 流程结束停在「我的」页，截图
  3) 同 profile 重开 index.html，验证刷新/重启后自动登录（IndexedDB 持久化）
  4) 另一个全新 profile：验证未登录显示登录门并截图
用法：python tests/run_browser_tests.py
"""
import functools
import http.server
import os
import shutil
import socketserver
import sys
import tempfile
import threading

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from cdp import Browser

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SHOT_DIR = os.path.join(ROOT, 'tests', '_browser_shots')
EDGE_CANDIDATES = [
    r'C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe',
    r'C:\Program Files\Microsoft\Edge\Application\msedge.exe',
]

# 在页面主世界执行的账户流程测试（async 表达式，returnByValue + awaitPromise）
FLOW_JS = r"""
(async function () {
  var results = [];
  function ok(c, msg) { results.push({ pass: !!c, msg: msg + (c ? '  PASS' : '  FAIL') }); }
  function sleep(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }
  async function waitFor(fn, n) {
    for (var i = 0; i < (n || 120); i++) { try { if (fn()) return true; } catch (e) {} await sleep(100); }
    return false;
  }
  var W = window, D = document;
  await waitFor(function () { return W.App && W.App.svc; });
  ok(!!W.App.svc, '应用启动并完成种子初始化');
  var gate = D.getElementById('login-gate');
  ok(!!gate && gate.style.display !== 'none', '未登录时显示登录门');

  /* 注册校验：空表单 */
  W.App.Gate.mode = 'register'; W.App.Gate.render();
  var form = D.getElementById('gate-form');
  await W.App.Gate.submit({ username: '', nickname: '', password: '', confirm: '', studentNo: '' }, form);
  await sleep(120);
  ok(!W.App.user && !!form.querySelector('[data-k=username].invalid'), '注册空表单显示字段错误且未登录');

  /* 正常注册并自动登录 */
  await W.App.Gate.submit({ username: 'wuzhenqin', nickname: '吴振钦', password: '123456', confirm: '123456', studentNo: '202642051157' }, form);
  ok(!!W.App.user, '注册成功并自动登录');
  ok(gate.style.display === 'none', '登录后登录门隐藏');
  await sleep(150);
  ok(D.querySelector('#view-home').classList.contains('active'), '登录后落在首页');

  /* 重复注册被拒 */
  W.App.Gate.mode = 'register'; W.App.Gate.render();
  form = D.getElementById('gate-form');
  await W.App.Gate.submit({ username: 'wuzhenqin', nickname: '二', password: '123456', confirm: '123456', studentNo: '' }, form);
  await sleep(120);
  ok(!!form.querySelector('[data-k=username].invalid') && W.App.user && W.App.user.username === 'wuzhenqin', '重复用户名注册被拒绝并保持当前登录');

  /* 我的页渲染 */
  W.App.Router.go('profile');
  await waitFor(function () { var n = D.querySelector('.pf-name'); return n && /吴振钦/.test(n.textContent); });
  ok(/202642051157/.test(D.querySelector('.pf-school').textContent), '我的页展示学校与学号');
  ok(/¥\s*14\.18/.test(D.querySelector('.pf-balance').textContent), '我的页展示校园卡余额 14.18');

  /* 头部「编辑」按钮可打开资料编辑（回归：点击委托须覆盖 #pf-head） */
  var headEdit = D.querySelector('#pf-head .pf-edit-btn');
  ok(!!headEdit, '我的页头部存在编辑按钮');
  if (headEdit) headEdit.click();
  await waitFor(function () { return D.getElementById('pf-form'); });
  ok(!!D.getElementById('pf-form'), '点击头部编辑按钮能打开资料编辑');
  W.App.Router.clearGuard(); W.App.Router.back();
  await sleep(150);

  /* 编辑资料：保存 */
  W.App.Router.openSub(W.App.Subs.profileEdit());
  await waitFor(function () { return D.getElementById('pf-form'); });
  var pf = D.getElementById('pf-form');
  pf.nickname.value = '钦钦子';
  pf.signature.value = '诚毅计科 2026 级';
  var sub = W.App.Router.stack[W.App.Router.stack.length - 1];
  ok(!!sub.view.guard, '资料编辑存在未保存离开守卫');
  pf.querySelector('button[type=submit]').click();
  await waitFor(function () { return W.App.user && W.App.user.nickname === '钦钦子'; });
  ok(W.App.user.nickname === '钦钦子', '昵称修改已保存');
  await waitFor(function () { var n = D.querySelector('.pf-name'); return n && /钦钦子/.test(n.textContent); });
  ok(/诚毅计科/.test(D.querySelector('.pf-sign').textContent), '我的页刷新后显示新签名');

  /* 编辑资料：守卫拦截未保存修改 */
  W.App.Router.openSub(W.App.Subs.profileEdit());
  await waitFor(function () { return D.getElementById('pf-form'); });
  D.getElementById('pf-form').nickname.value = '没保存的名字';
  var entry = W.App.Router.stack[W.App.Router.stack.length - 1];
  ok(!!entry.view.guard(), '未保存修改时守卫给出提示');
  W.App.Router.clearGuard(); W.App.Router.back();
  await sleep(150);

  /* 退出登录 */
  D.getElementById('pf-logout').click();
  await sleep(150);
  var confirmBtn = D.querySelector('.modal-mask .btn-primary');
  ok(!!confirmBtn, '退出登录弹出确认框');
  confirmBtn.click();
  await waitFor(function () { return !W.App.user; });
  ok(!W.App.user && gate.style.display !== 'none', '退出后回到登录门');

  /* 重新登录 */
  W.App.Gate.mode = 'login'; W.App.Gate.render();
  var lf = D.getElementById('gate-form');
  await W.App.Gate.submit({ username: 'wuzhenqin', password: 'wrongpw' }, lf);
  await sleep(120);
  ok(!W.App.user && !!lf.querySelector('[data-k=password].invalid'), '错误密码登录被拒绝');
  await W.App.Gate.submit({ username: 'wuzhenqin', password: '123456' }, lf);
  await waitFor(function () { return W.App.user && W.App.user.nickname === '钦钦子'; });
  ok(!!W.App.user && W.App.user.nickname === '钦钦子', '正确密码登录成功且资料持久');

  W.App.Router.go('profile');
  await sleep(400);

  var failed = results.filter(function (r) { return !r.pass; });
  return {
    passed: results.length - failed.length, total: results.length,
    lines: results.map(function (r) { return r.msg; })
  };
})()
"""

# 首页 M3 流程（在账户流程之后运行，此时已登录）。全部走真实 DOM 点击。
HOME_JS = r"""
(async function () {
  var results = [];
  function ok(c, msg) { results.push({ pass: !!c, msg: msg + (c ? '  PASS' : '  FAIL') }); }
  function sleep(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }
  async function waitFor(fn, n) {
    for (var i = 0; i < (n || 120); i++) { try { if (fn()) return true; } catch (e) {} await sleep(100); }
    return false;
  }
  var D = document;
  function confirmModal() { var b = D.querySelector('.modal-mask .modal-actions button:last-child'); if (b) b.click(); }
  function sumNum(go) {
    var el = D.querySelector('.sum-item[data-go="' + go + '"] .sum-num');
    return el ? parseInt((el.textContent || '').replace(/[^0-9]/g, ''), 10) : -1;
  }

  W = window;
  W.App.Router.go('home');
  await waitFor(function () { return D.querySelector('#view-home.active .serv-grid'); });

  /* 结构 */
  ok(!!D.querySelector('.qb-scan [data-act], .qb-scan') && /扫一扫/.test(D.querySelector('.qb-scan').textContent), '快捷栏有扫一扫');
  ok(/去充值/.test(D.querySelector('[data-act="recharge"]').textContent), '快捷栏有去充值');
  ok(/校园码/.test(D.querySelector('[data-act="qr"]').textContent), '快捷栏有校园码');
  ok(/诚毅学院/.test(D.getElementById('cc-school').textContent), '校园卡显示学校');
  ok(/202642051157/.test(D.getElementById('cc-user').textContent), '校园卡显示昵称与学号');
  ok(/14\.18/.test(D.getElementById('cc-balance').textContent), '校园卡显示余额 14.18');
  ok(/Oct/.test(D.getElementById('cc2-month').textContent) && /周四/.test(D.getElementById('cc2-wd').textContent), '课表卡显示英文月份与周四');
  ok(/第\s*4\s*周/.test(D.getElementById('cc2-week').textContent), '课表卡显示第 4 周');
  ok(D.querySelectorAll('.serv-grid .serv-item').length === 10, '两行五列共 10 个服务入口');
  ok(D.querySelectorAll('#home-notices .notice-row').length === 3, '展示三条校园通知');
  ok(D.querySelectorAll('#home-summary .sum-item').length === 4, '今日摘要有四个数据项');
  ok(!!D.querySelector('#memo-list .memo-empty'), '新用户快速备忘显示空态');

  /* 快速备忘：新增 */
  D.querySelector('[data-act="memo-add"]').click();
  await waitFor(function () { return !!D.getElementById('mf-input'); });
  D.getElementById('mf-input').value = '下午三点去图书馆';
  confirmModal();
  await waitFor(function () { return D.querySelectorAll('#memo-list .memo-item').length === 1; });
  ok(D.querySelectorAll('#memo-list .memo-item').length === 1, '记一条后首页出现该备忘');
  await waitFor(function () { return sumNum('memo') === 1; });
  ok(sumNum('memo') === 1, '摘要未完成备忘数变为 1');
  var memoBadge = D.querySelector('[data-badge="memo"]');
  ok(memoBadge && memoBadge.style.display !== 'none' && memoBadge.textContent === '1', '备忘入口显示角标 1');

  /* 勾选完成 */
  D.querySelector('#memo-list .memo-check').click();
  await waitFor(function () { return !!D.querySelector('#memo-list .memo-empty'); });
  ok(!!D.querySelector('#memo-list .memo-empty'), '勾选后回到空态');
  await waitFor(function () { return sumNum('memo') === 0; });
  ok(sumNum('memo') === 0, '勾选完成后摘要未完成数归 0');

  /* 模拟充值 */
  D.querySelector('.qb-pill.accent').click();
  await waitFor(function () { return !!D.getElementById('rc-bal'); });
  ok(/14\.18/.test(D.getElementById('rc-bal').textContent), '充值弹窗显示当前余额 14.18');
  D.querySelector('[data-amt="10"]').click();
  await waitFor(function () { return /24\.18/.test(D.getElementById('cc-balance').textContent); });
  ok(/24\.18/.test(D.getElementById('rc-bal').textContent) && /24\.18/.test(D.getElementById('cc-balance').textContent), '模拟充值 +10 后余额变 24.18');
  confirmModal();
  await sleep(150);

  /* 通知关闭 */
  var before = D.querySelectorAll('#home-notices .notice-row').length;
  D.querySelector('#home-notices .notice-x').click();
  await waitFor(function () { return D.querySelectorAll('#home-notices .notice-row').length === before - 1; });
  ok(D.querySelectorAll('#home-notices .notice-row').length === before - 1, '关闭一条通知后剩余 ' + (before - 1) + ' 条');

  /* 课表卡 / 入口跳转 */
  D.querySelector('.course-card').click();
  await waitFor(function () { return D.getElementById('view-schedule').classList.contains('active'); });
  ok(D.getElementById('view-schedule').classList.contains('active'), '点今日课表卡进入课程表');
  W.App.Router.go('home');
  await waitFor(function () { return D.getElementById('view-home').classList.contains('active'); });

  D.querySelector('.serv-item[data-srv="forum"]').click();
  await waitFor(function () { return D.getElementById('view-forum').classList.contains('active'); });
  ok(D.getElementById('view-forum').classList.contains('active'), '点学生论坛入口进入论坛');
  W.App.Router.go('home');
  await waitFor(function () { return D.getElementById('view-home').classList.contains('active'); });

  /* 待处理订单为 0 时给提示而非僵尸跳转 */
  D.querySelector('.sum-item[data-go="order"]').click();
  await waitFor(function () { return !!D.querySelector('.toast'); });
  ok(!!D.querySelector('.toast'), '无待处理订单时点摘要给出提示');

  /* 全部应用面板 + 演示项 */
  D.querySelector('.serv-item[data-srv="apps"]').click();
  await waitFor(function () { return !!D.querySelector('.subview.show .apps-grid'); });
  ok(D.querySelectorAll('.subview.show [data-demo]').length === 4, '全部应用含 4 个生活便民演示项');
  D.querySelector('.subview.show [data-demo]').click();
  await waitFor(function () { return !!D.querySelector('.modal-mask'); });
  ok(!!D.querySelector('.modal-mask'), '点演示项弹出本地演示说明（无僵尸按钮）');
  confirmModal();
  await sleep(200);
  D.querySelector('.subview.show .back').click();
  await waitFor(function () { return !D.querySelector('.subview.show'); });
  ok(!D.querySelector('.subview.show'), '全部应用面板可返回');

  /* 首页演示入口（缴费）也有反馈 */
  D.querySelector('.serv-item[data-srv="pay"]').click();
  await waitFor(function () { return !!D.querySelector('.modal-mask'); });
  ok(!!D.querySelector('.modal-mask'), '缴费演示入口弹出说明');
  confirmModal();
  await sleep(200);

  var failed = results.filter(function (r) { return !r.pass; });
  return {
    passed: results.length - failed.length, total: results.length,
    lines: results.map(function (r) { return r.msg; })
  };
})()
"""

# 课程表 M5 流程（在备忘流程之后：此时无课程数据）
COURSE_JS = r"""
(async function () {
  var results = [];
  function ok(c, msg) { results.push({ pass: !!c, msg: msg + (c ? '  PASS' : '  FAIL') }); }
  function sleep(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }
  async function waitFor(fn, n) {
    for (var i = 0; i < (n || 150); i++) { try { if (fn()) return true; } catch (e) {} await sleep(100); }
    return false;
  }
  var D = document, W = window;
  function confirmModal() { var b = D.querySelector('.modal-mask .modal-actions button:last-child'); if (b) b.click(); }
  function cancelModal() { var b = D.querySelector('.modal-mask .modal-actions button:first-child'); if (b) b.click(); }
  function subOpen(sel) { return !!D.querySelector('.subview.show ' + sel); }
  function subClosed() { return !D.querySelector('.subview.show'); }
  function todayBlocks() { return D.querySelectorAll('.sch-col.today .sch-course').length; }
  var wd = ((new Date().getDay() + 6) % 7) + 1; // 周一=1

  W.App.Router.go('schedule');
  await waitFor(function () { return !!D.querySelector('#view-schedule.active .sch-cols'); });
  ok(todayBlocks() === 0, '新课表本周今天无课程块');

  /* 打开添加：空表单应被拒绝 */
  D.querySelector('.sch-toolbar [data-act="add"]').click();
  await waitFor(function () { return subOpen('#cf-name'); });
  ok(!!D.querySelector('.chip[data-wd="' + wd + '"].on'), '新增表单默认选中今天星期');
  D.getElementById('cf-save').click();
  await sleep(200);
  ok(D.getElementById('cf-name').classList.contains('invalid'), '空课程名被标记错误');
  ok(!subClosed(), '校验未通过时停留在表单页');

  /* 正确填写：名称/教师/地点 + 第5节 */
  D.getElementById('cf-name').value = '高等数学';
  D.getElementById('cf-teacher').value = '张老师';
  D.getElementById('cf-location').value = '景祺楼A301';
  D.querySelector('.period-chip[data-period="4"]').click();
  await sleep(50);
  ok(D.getElementById('cf-start').value === '14:00' && D.getElementById('cf-end').value === '14:45', '点第5节自动填入 14:00-14:45');
  D.getElementById('cf-save').click();
  await waitFor(function () { return subClosed() && todayBlocks() === 1; });
  ok(subClosed() && todayBlocks() === 1, '保存后今天列出现 1 个课程块');

  /* 首页今日课程联动 */
  W.App.Router.go('home');
  await waitFor(function () {
    var el = D.querySelector('.sum-item[data-go="schedule"] .sum-num');
    return el && parseInt((el.textContent || '').replace(/[^0-9]/g, ''), 10) === 1;
  });
  var cs = D.querySelector('.sum-item[data-go="schedule"] .sum-num');
  ok(cs && parseInt((cs.textContent || '').replace(/[^0-9]/g, ''), 10) === 1, '首页今日课程摘要变为 1');

  /* 编辑改名 */
  W.App.Router.go('schedule');
  await waitFor(function () { return !!D.querySelector('#view-schedule.active .sch-cols'); });
  D.querySelector('.sch-col.today .sch-course').click();
  await waitFor(function () { return subOpen('#cf-name'); });
  D.getElementById('cf-name').value = '高等数学A';
  D.getElementById('cf-save').click();
  await waitFor(function () { var el = D.querySelector('.sch-col.today .sc-name'); return subClosed() && el && /高等数学A/.test(el.textContent); });
  ok(/高等数学A/.test(D.querySelector('.sch-col.today .sc-name').textContent), '编辑后课程名立即更新');

  /* 添加时间冲突课程（同星期同节次），应提示但不阻止 */
  D.querySelector('.sch-toolbar [data-act="add"]').click();
  await waitFor(function () { return subOpen('#cf-name'); });
  D.getElementById('cf-name').value = '线性代数';
  D.getElementById('cf-location').value = '景祺楼A302';
  D.querySelector('.period-chip[data-period="4"]').click();
  await sleep(80);
  D.getElementById('cf-save').click();
  await waitFor(function () { return !!D.querySelector('.modal-mask') && /重叠/.test(D.querySelector('.modal-mask').textContent); });
  ok(/重叠/.test(D.querySelector('.modal-mask').textContent), '时间重叠弹出冲突提示');
  confirmModal(); // 仍要保存
  await waitFor(function () { return subClosed() && todayBlocks() === 2; });
  ok(todayBlocks() === 2, '确认后冲突课程仍被保存，今天列 2 块');

  /* 删除其中一门 */
  D.querySelector('.sch-col.today .sch-course').click();
  await waitFor(function () { return subOpen('#cf-delete'); });
  var delName = D.getElementById('cf-name').value;
  D.getElementById('cf-delete').click();
  await waitFor(function () { return !!D.querySelector('.modal-mask'); });
  confirmModal();
  await waitFor(function () { return subClosed() && todayBlocks() === 1; });
  ok(todayBlocks() === 1, '删除「' + delName + '」后今天剩 1 块');

  /* Excel 导入：3 门，其中 1 门与现存线性代数同星期同节次冲突 */
  D.querySelector('.sch-toolbar [data-act="import"]').click();
  await waitFor(function () { return subOpen('#ie-tpl'); });
  ok(!!D.querySelector('.subview.show #ie-tpl'), '导入向导提供模板下载按钮');
  var HEAD = ['课程名称', '任课教师', '上课地点', '星期(1-7,1=周一)', '开始时间', '结束时间', '开始日期', '结束日期', '重复规则', '颜色', '备注'];
  var rows = [
    ['大学英语', '李老师', '教学楼B202', wd, '14:00', '14:45', '2026-09-07', '2026-12-28', '每周', '绿', ''],
    ['计算机基础', '王老师', '实验楼C105', wd, '08:00', '08:45', '2026-09-07', '2026-12-28', '每周', '蓝', ''],
    ['体育', '赵老师', '田径场', 6, '10:00', '11:40', '2026-09-07', '2026-12-28', '每周', '橙', '']
  ];
  var ws = XLSX.utils.aoa_to_sheet([HEAD].concat(rows));
  var u8 = XLSX.write({ SheetNames: ['课程导入'], Sheets: { '课程导入': ws } }, { type: 'array', bookType: 'xlsx' });
  var file = new File([u8], 'courses.xlsx', { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
  var dt = new DataTransfer(); dt.items.add(file);
  var fi = D.getElementById('ie-file'); fi.files = dt.files; fi.dispatchEvent(new Event('change', { bubbles: true }));
  await waitFor(function () { return D.querySelectorAll('.subview.show .ie-table tbody tr').length === 3; });
  ok(D.querySelectorAll('.subview.show .ie-table tbody tr').length === 3, '导入预览列出 3 行');
  ok(D.querySelectorAll('.subview.show .row-warn').length >= 1, '与现有课程冲突的行被标黄');
  ok(D.querySelectorAll('.subview.show input[data-row]').length === 3, '3 个有效行均可勾选');
  D.getElementById('ie-confirm').click();
  await waitFor(function () { return subClosed() && todayBlocks() === 3; });
  ok(todayBlocks() === 3, '确认导入后今天列共 3 块（线性代数+大学英语+计算机基础）');
  ok(D.querySelectorAll('.sch-col').length === 7 && D.querySelectorAll('.sch-week .sch-course').length === 4, '本周网格共 4 块（含周六体育）');

  /* 日视图 */
  D.querySelector('#sch-seg [data-view="day"]').click();
  await waitFor(function () { return D.querySelector('#sch-day-view').style.display !== 'none' && D.querySelectorAll('.sch-daycard').length === 3; });
  ok(D.querySelectorAll('.sch-daycard').length === 3, '日视图今天列出 3 张大课程卡');
  /* 点周视图列头可跳到该天日视图 */
  D.querySelector('#sch-seg [data-view="week"]').click();
  await waitFor(function () { return D.querySelector('#sch-week-view').style.display !== 'none'; });
  D.querySelector('.sch-col:not(.today) .sch-col-head').click();
  await waitFor(function () { return D.querySelector('#sch-day-view').style.display !== 'none'; });
  ok(D.querySelector('#sch-day-view').style.display !== 'none', '点周视图列头切换到日视图对应日期');

  /* 周切换不报错且可回到本周 */
  W.App.Router.go('schedule');
  var r0 = D.getElementById('sch-range').textContent;
  D.querySelector('.sch-toolbar [data-act="add"]'); // no-op 确保在课表页
  D.querySelector('.sch-weeknav [data-act="next"]').click();
  await sleep(200);
  var r1 = D.getElementById('sch-range').textContent;
  ok(r1 !== r0, '下一周标题变化');
  D.querySelector('.sch-weeknav [data-act="thisweek"]').click();
  await sleep(200);
  ok(D.getElementById('sch-range').textContent === r0, '回到本周标题复原');

  var failed = results.filter(function (r) { return !r.pass; });
  return {
    passed: results.length - failed.length, total: results.length,
    lines: results.map(function (r) { return r.msg; })
  };
})().catch(function (e) {
  return { passed: 0, total: 1, lines: ['COURSE_FATAL: ' + (e && e.message) + ' @step=' + (window.__cstep || '?') + '\n' + (e && e.stack)] };
})
"""

# 生活购物 M6 流程（A-09 购物车 / A-10 模拟下单 / A-11 订单状态）
SHOP_JS = r"""
(async function () {
  var results = [];
  function ok(c, msg) { results.push({ pass: !!c, msg: msg + (c ? '  PASS' : '  FAIL') }); }
  function sleep(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }
  async function waitFor(fn, n) {
    for (var i = 0; i < (n || 150); i++) { try { if (fn()) return true; } catch (e) {} await sleep(100); }
    return false;
  }
  var D = document, W = window;
  function confirmModal() { var b = D.querySelector('.modal-mask .modal-actions button:last-child'); if (b) b.click(); }
  function subView() { return D.querySelector('.subview.show'); }
  function barTotal() { var el = D.querySelector('.subview.show .cart-bar .cb-total'); return el ? el.textContent.replace(/[^0-9.]/g, '') : ''; }
  function barBadge() { var el = D.querySelector('.subview.show .cart-bar .cb-badge'); return el ? el.textContent : ''; }
  function cartRow(name) {
    var rows = D.querySelectorAll('.subview.show .cart-item');
    for (var i = 0; i < rows.length; i++) { if (rows[i].textContent.indexOf(name) >= 0) return rows[i]; }
    return null;
  }
  function setVal(el, val) { el.value = val; el.dispatchEvent(new Event('input', { bubbles: true })); el.dispatchEvent(new Event('change', { bubbles: true })); }

  /* 生活首页：分类筛选 + 商家数 */
  W.App.Router.go('life');
  await waitFor(function () { return D.querySelectorAll('#view-life.active .shop-card').length === 6; });
  ok(D.querySelectorAll('#view-life.active .shop-card').length === 6, '生活首页展示 6 家内置商家');
  ok(!D.querySelector('#life-cartmini .cart-mini'), '空购物车时不显示购物车迷你条');
  D.querySelector('#life-cats [data-cat="外卖"]').click();
  await waitFor(function () { return D.querySelectorAll('#view-life.active .shop-card').length === 3; });
  ok(D.querySelectorAll('#view-life.active .shop-card').length === 3, '按「外卖」筛选出 3 家店');
  D.querySelector('#life-cats [data-cat="全部"]').click();
  await waitFor(function () { return D.querySelectorAll('#view-life.active .shop-card').length === 6; });

  /* 我的订单空态 */
  D.querySelector('#view-life [data-act="orders"]').click();
  await waitFor(function () { return !!D.querySelector('.subview.show .life-empty'); });
  ok(!!D.querySelector('.subview.show .life-empty'), '新用户我的订单显示空态');
  D.querySelector('.subview.show .back').click();
  await waitFor(function () { return !subView(); });

  /* 进入景祺楼餐厅，加 2 件商品（A-09 前置） */
  D.querySelector('[data-shop="shop_canteen"]').click();
  await waitFor(function () { return D.querySelectorAll('.subview.show .prod-row').length >= 7; });
  ok(D.querySelectorAll('.subview.show .prod-group-title').length >= 1, '商家详情按品类分组展示商品');
  ok(!!D.querySelector('.subview.show [data-add="shop_canteen_p5"]') && !!D.querySelector('.subview.show .prod-badge.limited'), '限量商品显示限量角标且可加购');
  D.querySelector('.subview.show [data-add="shop_canteen_p3"]').click(); // 番茄鸡蛋盖饭 12
  await waitFor(function () { return barBadge() === '1'; });
  D.querySelector('.subview.show [data-add="shop_canteen_p1"]').click(); // 飘香拌面 7
  await waitFor(function () { return barBadge() === '2' && barTotal() === '19.00'; });
  ok(barBadge() === '2' && barTotal() === '19.00', '加 2 件后购物车条显示 2 件合计 19.00');

  /* 购物车（结算页）：改数量 + 删除（A-09） */
  D.querySelector('.subview.show [data-act="checkout"]').click();
  await waitFor(function () { return D.querySelectorAll('.subview.show .cart-item').length === 2; });
  var noodle = cartRow('飘香拌面');
  noodle.querySelector('[data-plus]').click(); // 拌面 7x2
  await waitFor(function () { var el = D.querySelector('.subview.show .ct-row.grand b'); return el && el.textContent.indexOf('26.00') >= 0; });
  ok((D.querySelector('.subview.show .ct-row.grand b').textContent || '').indexOf('26.00') >= 0, '拌面数量 +1 后合计变为 26.00');
  var tomato = cartRow('番茄鸡蛋盖饭');
  tomato.querySelector('[data-del]').click(); // 删除番茄
  await waitFor(function () { return D.querySelectorAll('.subview.show .cart-item').length === 1; });
  ok(D.querySelectorAll('.subview.show .cart-item').length === 1, '删除后购物车仅剩 1 件商品');
  await waitFor(function () { var el = D.querySelector('.subview.show .ct-row.grand b'); return el && el.textContent.indexOf('14.00') >= 0; });
  ok((D.querySelector('.subview.show .ct-row.grand b').textContent || '').indexOf('14.00') >= 0, '删除后合计正确更新为 14.00（拌面 x2）');
  D.querySelector('.subview.show .back').click(); // 回商家详情
  await waitFor(function () { return !!D.querySelector('.subview.show .cart-bar'); });
  D.querySelector('.subview.show .back').click(); // 回生活首页
  await waitFor(function () { return !subView(); });
  await waitFor(function () { return !!D.querySelector('#life-cartmini .cart-mini'); });
  ok(!!D.querySelector('#life-cartmini .cart-mini'), '生活首页出现购物车迷你条（2 件 14.00）');

  /* 跨店拦截：进川香园加购应提示清空 */
  D.querySelector('[data-shop="shop_spicy"]').click();
  await waitFor(function () { return !!D.querySelector('.subview.show [data-add="shop_spicy_p1"]'); });
  ok(!!D.querySelector('.subview.show .prod-row.is-soldout') && !D.querySelector('.subview.show .prod-row.is-soldout [data-add]'), '售罄商品（酸梅汤）置灰且无加购按钮');
  D.querySelector('.subview.show [data-add="shop_spicy_p1"]').click(); // 素菜拼盘 10
  await waitFor(function () { return !!D.querySelector('.modal-mask') && /清空/.test(D.querySelector('.modal-mask').textContent); });
  ok(/清空/.test(D.querySelector('.modal-mask').textContent), '跨店加购弹出清空购物车确认');
  confirmModal();
  await waitFor(function () { return barBadge() === '1' && barTotal() === '10.00'; });
  ok(barBadge() === '1' && barTotal() === '10.00', '确认后清空旧购物车并加入素菜拼盘 10.00');
  ok(D.querySelector('.subview.show .cb-go').classList.contains('disabled'), '未达 15 元起送时结算按钮禁用');
  D.querySelector('.subview.show [data-add="shop_spicy_p2"]').click(); // 麻辣香锅小 18
  await waitFor(function () { return barBadge() === '2' && barTotal() === '28.00'; });
  ok(barBadge() === '2' && barTotal() === '28.00', '再加香锅后合计 28.00 满足起送');

  /* 结算 + 模拟下单（A-10） */
  D.querySelector('.subview.show [data-act="checkout"]').click();
  await waitFor(function () { return !!D.querySelector('.subview.show .checkout-btn'); });
  ok(D.querySelectorAll('.subview.show .cart-item').length === 2, '结算页显示 2 件商品');
  var veg = cartRow('素菜拼盘');
  setVal(veg.querySelector('.ci-remark'), '微辣');
  setVal(D.querySelector('.subview.show #co-pickup'), '12 点半到店自取');
  await sleep(200);
  ok((D.querySelector('.subview.show .ct-row.grand b').textContent || '').indexOf('28.00') >= 0, '结算页合计 28.00');
  D.querySelector('.subview.show [data-act="submit"]').click();
  await waitFor(function () { return !!D.querySelector('.subview.show .status-timeline'); });
  var od1 = subView().textContent;
  ok(/CY\d{14,}/.test(od1), '生成 CY 开头的订单号');
  ok(/待取餐/.test(od1) && !!D.querySelector('.subview.show .status-pill.pending'), '订单初始状态为待取餐');
  ok(/素菜拼盘/.test(od1) && /麻辣香锅/.test(od1) && /28\.00/.test(od1), '订单详情含商品明细与金额');
  ok(/12 点半到店自取/.test(od1), '订单详情含取货说明');
  ok(/微辣/.test(od1), '订单详情保留单品备注');

  /* 订单状态推进（A-11） */
  D.querySelector('.subview.show [data-act="advance"]').click();
  await waitFor(function () { return !!D.querySelector('.subview.show .status-pill.doing'); });
  ok(!!D.querySelector('.subview.show .status-pill.doing'), '推进后状态变为进行中');
  D.querySelector('.subview.show [data-act="advance"]').click();
  await waitFor(function () { return !!D.querySelector('.subview.show .status-pill.done'); });
  ok(!!D.querySelector('.subview.show .status-pill.done'), '再次推进后状态变为已完成');
  var adv = D.querySelector('.subview.show .advance-btn');
  ok(adv && adv.disabled && /已完成/.test(adv.textContent), '已完成订单按钮禁用');
  D.querySelector('.subview.show .back').click();
  await waitFor(function () { return !subView(); });

  /* 再下一单（保持待取餐），用于首页摘要与持久化 */
  D.querySelector('[data-shop="shop_canteen"]').click();
  await waitFor(function () { return !!D.querySelector('.subview.show [data-add="shop_canteen_p3"]'); });
  D.querySelector('.subview.show [data-add="shop_canteen_p3"]').click(); // 12 元，满足起送
  await waitFor(function () { return barBadge() === '1'; });
  D.querySelector('.subview.show [data-act="checkout"]').click();
  await waitFor(function () { return !!D.querySelector('.subview.show [data-act="submit"]'); });
  D.querySelector('.subview.show [data-act="submit"]').click();
  await waitFor(function () { return !!D.querySelector('.subview.show .status-pill.pending'); });
  ok(!!D.querySelector('.subview.show .status-pill.pending'), '第二单创建成功，状态待取餐');
  D.querySelector('.subview.show .back').click();
  await waitFor(function () { return !subView(); });

  /* 首页订单摘要联动 */
  W.App.Router.go('home');
  await waitFor(function () {
    var el = D.querySelector('.sum-item[data-go="order"] .sum-num');
    return el && (el.textContent || '').replace(/[^0-9]/g, '') === '1';
  });
  var on = D.querySelector('.sum-item[data-go="order"] .sum-num');
  ok(on && on.textContent.replace(/[^0-9]/g, '') === '1', '首页待处理订单摘要联动为 1（已完成的不计）');

  /* 打开订单列表停留（截图）：共 2 单 */
  W.App.Router.go('life');
  W.App.Router.openSub(W.App.Subs.ordersList());
  await waitFor(function () { return D.querySelectorAll('.subview.show .order-card').length === 2; });
  ok(D.querySelectorAll('.subview.show .order-card').length === 2, '订单列表展示 2 笔订单');
  ok(!!D.querySelector('.subview.show .status-pill.pending') && !!D.querySelector('.subview.show .status-pill.done'), '列表同时显示待取餐与已完成状态');

  var failed = results.filter(function (r) { return !r.pass; });
  return {
    passed: results.length - failed.length, total: results.length,
    lines: results.map(function (r) { return r.msg; })
  };
})().catch(function (e) {
  return { passed: 0, total: 1, lines: ['SHOP_FATAL: ' + (e && e.message) + '\n' + (e && e.stack)] };
})
"""

# 学生论坛 M7 流程（A-12 话题 / A-13 评论）
FORUM_JS = r"""
(async function () {
  var results = [];
  function ok(c, msg) { results.push({ pass: !!c, msg: msg + (c ? '  PASS' : '  FAIL') }); }
  function sleep(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }
  async function waitFor(fn, n) {
    for (var i = 0; i < (n || 150); i++) { try { if (fn()) return true; } catch (e) {} await sleep(100); }
    return false;
  }
  var D = document, W = window;
  function subView() { return D.querySelector('.subview.show'); }
  function setVal(el, val) { el.value = val; el.dispatchEvent(new Event('input', { bubbles: true })); el.dispatchEvent(new Event('change', { bubbles: true })); }
  function modalMask() { var ms = D.querySelectorAll('.modal-mask'); return ms.length ? ms[ms.length - 1] : null; }
  function modalLast() { var m = modalMask(); return m ? m.querySelector('.modal-actions button:last-child') : null; }
  function modalFirst() { var m = modalMask(); return m ? m.querySelector('.modal-actions button:first-child') : null; }
  function cardByText(txt) {
    var cards = D.querySelectorAll('#forum-list .topic-card');
    for (var i = 0; i < cards.length; i++) { if (cards[i].textContent.indexOf(txt) >= 0) return cards[i]; }
    return null;
  }

  /* 广场：6 个种子话题 + 最新排序 */
  W.App.Router.go('forum');
  await waitFor(function () { return D.querySelectorAll('#forum-list .topic-card').length === 6; });
  ok(D.querySelectorAll('#forum-list .topic-card').length === 6, '话题广场展示 6 个内置话题');
  ok(D.querySelector('#forum-list .topic-card .tc-title').textContent.indexOf('周末在厦门') >= 0, '话题按最新发布排在最前');

  /* 发起话题：空表单校验 */
  D.querySelector('#forum-new').click();
  await waitFor(function () { return !!D.querySelector('.subview.show #tf-title'); });
  D.querySelector('.subview.show #tf-submit').click();
  await sleep(150);
  ok(!!D.querySelector('.subview.show #fg-title.field-invalid') && !!D.querySelector('.subview.show #fg-content.field-invalid'), '标题或正文为空时给出错误提示且不发布');
  ok(!!D.querySelector('.subview.show #tf-title'), '校验失败时停留在发帖页');

  /* 填写与字数统计 */
  var title = '找自习搭子';
  var content = '每天晚上图书馆三楼自习，想找个互相监督的同学，一起坚持到期末。';
  setVal(D.querySelector('.subview.show #tf-title'), title);
  setVal(D.querySelector('.subview.show #tf-content'), content);
  await sleep(100);
  ok(D.querySelector('.subview.show #cc-title').textContent === title.length + '/30', '标题字数统计正确（' + title.length + '/30）');
  ok(D.querySelector('.subview.show #cc-content').textContent === content.length + '/5000', '正文字数统计正确（' + content.length + '/5000）');
  D.querySelector('.subview.show #tf-submit').click();
  await waitFor(function () { return !!D.querySelector('.subview.show .td-title'); });
  ok(D.querySelector('.subview.show .td-title').textContent.indexOf(title) >= 0, '发布成功并进入话题详情');
  ok(D.querySelector('.subview.show .td-content').textContent.indexOf('图书馆三楼') >= 0, '话题详情展示正文');

  /* 返回广场：新话题置顶，共 7 条 */
  D.querySelector('.subview.show .back').click();
  await waitFor(function () { return !subView(); });
  await waitFor(function () { return D.querySelectorAll('#forum-list .topic-card').length === 7; });
  ok(D.querySelectorAll('#forum-list .topic-card').length === 7, '发布后广场共 7 个话题');
  ok(D.querySelector('#forum-list .topic-card .tc-title').textContent.indexOf(title) >= 0, '新发布话题排在广场最前');

  /* 进入种子话题 topic_1（2 条评论，均为他人） */
  cardByText('公选课').click();
  await waitFor(function () { return D.querySelectorAll('.subview.show .reply-item').length === 2; });
  ok(D.querySelectorAll('.subview.show .reply-item').length === 2, '话题详情展示 2 条已有评论');
  ok(!D.querySelector('.subview.show .rp-del'), '他人的评论不显示删除按钮');

  /* 发表评论 */
  setVal(D.querySelector('.subview.show #rd-input'), '帮顶，我也在找自习伙伴。');
  D.querySelector('.subview.show #rd-send').click();
  await waitFor(function () { return D.querySelectorAll('.subview.show .reply-item').length === 3; });
  ok(D.querySelectorAll('.subview.show .reply-item').length === 3, '发表后评论数变为 3');
  ok(!!D.querySelector('.subview.show .rp-del'), '自己的评论显示删除按钮');

  /* 删除自己的评论（danger 确认） */
  D.querySelector('.subview.show .rp-del').click();
  await waitFor(function () { return !!D.querySelector('.modal-mask') && /删除评论/.test(D.querySelector('.modal-mask').textContent); });
  ok(/不可恢复|删除你发表/.test(D.querySelector('.modal-mask').textContent), '删除评论弹出二次确认');
  modalLast().click();
  await waitFor(function () { return D.querySelectorAll('.subview.show .reply-item').length === 2; });
  ok(D.querySelectorAll('.subview.show .reply-item').length === 2 && !D.querySelector('.subview.show .rp-del'), '确认后删除本人评论，剩 2 条且无删除按钮');

  /* 再发一条保留评论 */
  setVal(D.querySelector('.subview.show #rd-input'), '码住，同求推荐公选课。');
  D.querySelector('.subview.show #rd-send').click();
  await waitFor(function () { return D.querySelectorAll('.subview.show .reply-item').length === 3; });
  ok(D.querySelectorAll('.subview.show .reply-item').length === 3, '再次发表后评论数为 3');
  D.querySelector('.subview.show .back').click();
  await waitFor(function () { return !subView(); });

  /* 我的论坛：我的话题 / 我的评论 */
  D.querySelector('#forum-mine').click();
  await waitFor(function () { return !!D.querySelector('.subview.show .seg'); });
  await waitFor(function () { return D.querySelectorAll('.subview.show .my-item').length === 1; });
  ok(D.querySelectorAll('.subview.show .my-item').length === 1 && D.querySelector('.subview.show .my-item-title').textContent.indexOf(title) >= 0, '我的话题列出自己发布的 1 个话题');
  D.querySelector('.subview.show [data-seg="replies"]').click();
  await waitFor(function () { return D.querySelectorAll('.subview.show .my-item').length === 1 && /同求推荐公选课/.test(D.querySelector('.subview.show .my-item').textContent); });
  ok(/同求推荐公选课/.test(D.querySelector('.subview.show .my-item').textContent) && /来自话题/.test(D.querySelector('.subview.show .my-item').textContent), '我的评论列出评论内容与所属话题');
  D.querySelector('.subview.show .my-item').click();
  await waitFor(function () { return !!D.querySelector('.subview.show .td-title') && D.querySelectorAll('.subview.show .reply-item').length === 3; });
  ok(D.querySelectorAll('.subview.show .reply-item').length === 3, '从我的评论可进入对应话题详情');
  D.querySelector('.subview.show .back').click();
  await waitFor(function () { return !!D.querySelector('.subview.show .seg'); });
  D.querySelector('.subview.show .back').click();
  await waitFor(function () { return !subView(); });

  /* 首页论坛摘要联动：6 个种子近 7 天话题 + 自己 1 个 = 7 */
  W.App.Router.go('home');
  await waitFor(function () {
    var el = D.querySelector('.sum-item[data-go="forum"] .sum-num');
    return el && el.textContent.replace(/[^0-9]/g, '') === '7';
  });
  var fn = D.querySelector('.sum-item[data-go="forum"] .sum-num');
  ok(fn && fn.textContent.replace(/[^0-9]/g, '') === '7', '首页近 7 天话题摘要联动为 7');

  /* 未保存守卫：写了内容不发布，返回时提示；取消留下、确认离开 */
  W.App.Router.go('forum');
  D.querySelector('#forum-new').click();
  await waitFor(function () { return !!D.querySelector('.subview.show #tf-title'); });
  setVal(D.querySelector('.subview.show #tf-title'), '还没想好的话题');
  D.querySelector('.subview.show .back').click();
  await waitFor(function () { return !!modalMask(); });
  ok(/还没有发布|确定/.test(modalMask().textContent), '未发布内容离开时弹出守卫提示');
  modalFirst().click(); // 取消
  await sleep(260);      // 等弹窗退场动画（180ms）完全结束
  ok(!!D.querySelector('.subview.show #tf-title'), '取消后留在发帖页');
  D.querySelector('.subview.show .back').click();
  await waitFor(function () { return !!modalMask(); });
  modalLast().click(); // 确认离开
  await waitFor(function () { return !subView(); });
  ok(!subView() && D.querySelectorAll('#forum-list .topic-card').length === 7, '确认离开后回到广场，草稿未发布（仍 7 个话题）');

  var failed = results.filter(function (r) { return !r.pass; });
  return { passed: results.length - failed.length, total: results.length, lines: results.map(function (r) { return r.msg; }) };
})().catch(function (e) {
  return { passed: 0, total: 1, lines: ['FORUM_FATAL: ' + (e && e.message) + '\n' + (e && e.stack)] };
})
"""

# 我的与数据管理 M8 流程（A-17 导出 / A-18 恢复 / A-19 异常 / A-20 风险提示）
DATA_JS = r"""
(async function () {
  var results = [];
  function ok(c, msg) { results.push({ pass: !!c, msg: msg + (c ? '  PASS' : '  FAIL') }); }
  function sleep(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }
  async function waitFor(fn, n) {
    for (var i = 0; i < (n || 150); i++) { try { if (fn()) return true; } catch (e) {} await sleep(100); }
    return false;
  }
  var D = document, W = window, svc = W.App.svc, uid = W.App.user.id;
  function modalMask() { var ms = D.querySelectorAll('.modal-mask'); return ms.length ? ms[ms.length - 1] : null; }
  function modalLast() { var m = modalMask(); return m ? m.querySelector('.modal-actions button:last-child') : null; }
  function modalFirst() { var m = modalMask(); return m ? m.querySelector('.modal-actions button:first-child') : null; }
  function errBox() { return D.querySelector('.subview.show #dm-restore-err'); }
  async function counts() {
    return {
      courses: (await svc.course.list(uid)).length,
      orders: (await svc.order.list(uid)).length,
      topics: (await svc.forum.topics()).length,
      memos: (await svc.memo.list(uid)).length
    };
  }
  async function pick(text, name) {
    var dt = new DataTransfer();
    dt.items.add(new File([text], name || 'backup.json', { type: 'application/json' }));
    var inp = D.querySelector('.subview.show #dm-file');
    inp.files = dt.files;
    inp.dispatchEvent(new Event('change', { bubbles: true }));
  }
  // 确认危险操作（恢复/回滚）→ 第二个弹窗选「稍后」不重载页面
  async function confirmAndStay(kw) {
    await waitFor(function () { var m = modalMask(); return m && new RegExp(kw).test(m.textContent); });
    modalLast().click();
    await waitFor(function () { var m = modalMask(); return m && /重新加载/.test(m.textContent); });
    await sleep(220);
    modalFirst().click(); // 稍后
    await sleep(300);
  }

  /* 我的页菜单入口 */
  W.App.Router.go('profile');
  await waitFor(function () { return !!D.querySelector('#pf-menu [data-act="orders"]'); });
  ok(!!D.querySelector('[data-act="mytopics"]') && !!D.querySelector('[data-act="myreplies"]'), '我的页含我的话题 / 我的评论入口');
  ok(!!D.querySelector('[data-act="data"]'), '我的页含数据管理入口');
  D.querySelector('[data-act="data"]').click();
  await waitFor(function () { return !!D.querySelector('.subview.show .dm-card'); });
  ok(D.querySelectorAll('.subview.show .dm-card').length >= 3, '数据管理展示备份、快照、学期等分区');

  /* A-20 清除站点数据风险提示 + 导出入口 */
  var warn = D.querySelector('.subview.show .dm-warn');
  ok(!!warn && /无法|不能/.test(warn.textContent) && !!warn.querySelector('[data-act="export"]'), '风险卡明确告知清数据后果并提供导出入口');

  /* A-17 导出备份内容校验 + 最近导出时间 */
  var b = await svc.backup.export();
  ok(b.app === 'chengyi-campus' && typeof b.version === 'number' && !!b.exportedAt && Array.isArray(b.data.users) && b.data.users.length >= 1, '导出 JSON 含产品标识、版本号、导出时间与用户数据');
  D.querySelector('.subview.show #dm-export').click();
  await waitFor(function () { return /最近导出/.test(D.querySelector('.subview.show #dm-last-export').textContent); });
  ok(/最近导出/.test(D.querySelector('.subview.show #dm-last-export').textContent), '导出后显示最近备份时间');

  /* 开学日期设置与还原 */
  var sem = D.querySelector('.subview.show #dm-semester');
  ok(sem.value === '2026-09-07', '开学日期默认是 2026-09-07');
  sem.value = '2026-08-24'; sem.dispatchEvent(new Event('input', { bubbles: true }));
  D.querySelector('.subview.show #dm-save-sem').click();
  await waitFor(function () { return true; }); await sleep(200);
  ok((await svc.settings.semesterStart()) === '2026-08-24' && W.App.sem === '2026-08-24', '修改开学日期后立即写入并更新教学周基准');
  sem.value = '2026-09-07'; sem.dispatchEvent(new Event('input', { bubbles: true }));
  D.querySelector('.subview.show #dm-save-sem').click();
  await sleep(200);

  /* A-18 恢复备份：先取备份 A，新增备忘后恢复，备忘应消失，且自动建快照 */
  var cleanMemos = (await svc.memo.list(uid)).length; // 操作前真实备忘基线（含已完成）
  var backupA = JSON.stringify(await svc.backup.export());
  await svc.memo.add(uid, '恢复测试备忘XYZ');
  await waitFor(function () { return true; });
  ok((await svc.memo.list(uid)).some(function (m) { return /XYZ/.test(m.content); }), '恢复前已新增测试备忘');
  await pick(backupA, 'chengyi-campus-backup-a.json');
  await confirmAndStay('确认恢复');
  await sleep(200);
  var afterRestore = await svc.memo.list(uid);
  ok(!afterRestore.some(function (m) { return /XYZ/.test(m.content); }), '恢复备份后新增的备忘不再存在');
  ok(afterRestore.length === cleanMemos, '恢复后备忘数与备份 A 一致（' + cleanMemos + ' 条）');
  await waitFor(function () { return /恢复前自动快照/.test(D.querySelector('.subview.show #dm-snaps').textContent); });
  ok(/恢复前自动快照/.test(D.querySelector('.subview.show #dm-snaps').textContent), '恢复前自动创建了本地快照');

  /* A-19 异常备份：损坏 JSON / 高版本 / 错误标识，数据不被改动 */
  var base = await counts();
  await pick('{这不是合法的JSON,,,');
  await waitFor(function () { var e = errBox(); return e && e.style.display !== 'none' && /JSON|损坏/.test(e.textContent); });
  ok(/JSON|损坏/.test(errBox().textContent), '损坏 JSON 给出可理解错误');
  await pick(JSON.stringify({ app: 'chengyi-campus', version: 99, data: { users: [] } }));
  await waitFor(function () { var e = errBox(); return e && /版本/.test(e.textContent); });
  ok(/版本/.test(errBox().textContent), '不兼容版本给出错误提示');
  await pick(JSON.stringify({ app: 'some-other-app', version: 1, data: { users: [] } }));
  await waitFor(function () { var e = errBox(); return e && /标识|不是本应用/.test(e.textContent); });
  ok(/标识|不是本应用/.test(errBox().textContent), '非本应用备份给出标识错误');
  var afterBad = await counts();
  ok(afterBad.courses === base.courses && afterBad.orders === base.orders && afterBad.topics === base.topics && afterBad.memos === base.memos, '异常备份未部分覆盖任何数据（课程 ' + base.courses + '/订单 ' + base.orders + '/话题 ' + base.topics + '/备忘 ' + base.memos + ' 保持）');

  /* 快照回滚：回到「恢复前」状态，测试备忘重新出现 */
  var rollbackBtn = D.querySelector('.subview.show .snap-rollback');
  ok(!!rollbackBtn, '快照列表提供回滚按钮');
  rollbackBtn.click();
  await confirmAndStay('确认回滚');
  await sleep(200);
  ok((await svc.memo.list(uid)).some(function (m) { return /XYZ/.test(m.content); }), '回滚到恢复前快照后，测试备忘恢复存在');

  /* 清理测试备忘，使最终数据回到干净基线（memo=1），不污染持久化断言 */
  var xyz = (await svc.memo.list(uid)).filter(function (m) { return /XYZ/.test(m.content); });
  for (var i = 0; i < xyz.length; i++) await svc.memo.remove(xyz[i].id, uid);
  ok((await svc.memo.list(uid)).length === cleanMemos, '测试备忘已清理，备忘数回到操作前基线（' + cleanMemos + ' 条）');

  var failed = results.filter(function (r) { return !r.pass; });
  return { passed: results.length - failed.length, total: results.length, lines: results.map(function (r) { return r.msg; }) };
})().catch(function (e) {
  return { passed: 0, total: 1, lines: ['DATA_FATAL: ' + (e && e.message) + '\n' + (e && e.stack)] };
})
"""

# 联动与僵尸按钮巡检 M9（A-15 昵称头像跨页同步 + 守卫 + 死按钮审计）
LINK_JS = r"""
(async function () {
  var results = [];
  function ok(c, msg) { results.push({ pass: !!c, msg: msg + (c ? '  PASS' : '  FAIL') }); }
  function sleep(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }
  async function waitFor(fn, n) {
    for (var i = 0; i < (n || 150); i++) { try { if (fn()) return true; } catch (e) {} await sleep(100); }
    return false;
  }
  var D = document, W = window;

  /* 未保存表单守卫存在 */
  ok(typeof W.App.Subs.profileEdit().guard === 'function', '编辑资料页具备未保存离开守卫');
  ok(typeof W.App.Subs.topicCreate().guard === 'function', '发起话题页具备未保存离开守卫');

  /* A-15 昵称修改后我的页 / 首页校园卡 / 论坛作者同步 */
  W.App.Router.go('profile');
  var gotProfile = await waitFor(function () { return !!D.querySelector('.pf-name'); });
  if (!gotProfile) {
    var act = D.querySelector('.page.active'), head = D.querySelector('#pf-head');
    throw new Error('DIAG .pf-name missing: active=' + (act && act.id) +
      ' tab=' + W.App.Router.tab + ' subs=' + D.querySelectorAll('#subview-layer .subview').length +
      ' head=' + (head ? ('YES len=' + head.innerHTML.length) : 'NO') +
      ' profileHTML=' + (D.querySelector('#view-profile') ? D.querySelector('#view-profile').innerHTML.length : 'NO_SECTION'));
  }
  var oldName = D.querySelector('.pf-name').textContent.trim();
  var NEW = '联动测试昵称';
  D.querySelector('[data-act="edit"]').click();
  await waitFor(function () { return !!D.querySelector('.subview.show #pf-form'); });
  var ni = D.querySelector('.subview.show #pf-form input[name="nickname"]');
  ni.value = NEW; ni.dispatchEvent(new Event('input', { bubbles: true }));
  // 上传一张本地生成的 PNG 头像
  var cv = D.createElement('canvas'); cv.width = 64; cv.height = 64;
  var cx = cv.getContext('2d'); cx.fillStyle = '#d9534d'; cx.fillRect(0, 0, 64, 64); cx.fillStyle = '#fff'; cx.fillRect(16, 16, 32, 32);
  var blob = await new Promise(function (r) { cv.toBlob(r, 'image/png'); });
  var adt = new DataTransfer();
  adt.items.add(new File([blob], 'avatar.png', { type: 'image/png' }));
  var afi = D.querySelector('.subview.show #av-file');
  afi.files = adt.files; afi.dispatchEvent(new Event('change', { bubbles: true }));
  await waitFor(function () { var im = D.querySelector('.subview.show #av-img img'); return im && /image\/jpeg/.test(im.src); });
  ok(/image\/jpeg/.test(((D.querySelector('.subview.show #av-img img') || {}).src) || ''), '选择本地图片后生成压缩头像预览');
  D.querySelector('.subview.show #pf-form').dispatchEvent(new Event('submit', { bubbles: true, cancelable: true }));
  await waitFor(function () { return !D.querySelector('.subview.show') && D.querySelector('.pf-name') && D.querySelector('.pf-name').textContent.trim() === NEW; });
  ok(D.querySelector('.pf-name').textContent.trim() === NEW, '保存后我的页立即显示新昵称');
  await waitFor(function () { var im = D.querySelector('#pf-head img.pf-avatar'); return im && /image\/jpeg/.test(im.src); });
  ok(/image\/jpeg/.test(((D.querySelector('#pf-head img.pf-avatar') || {}).src) || '') && /^data:image/.test(W.App.user.avatar), '我的页头像更新并保存为本地数据');
  W.App.Router.go('home');
  await waitFor(function () { var el = D.querySelector('#cc-user'); return el && el.textContent.indexOf(NEW) >= 0; });
  ok(D.querySelector('#cc-user').textContent.indexOf(NEW) >= 0, '首页校园卡姓名同步为新昵称');
  W.App.Router.go('forum');
  await waitFor(function () {
    var card = null, cards = D.querySelectorAll('#forum-list .topic-card');
    for (var i = 0; i < cards.length; i++) { if (cards[i].textContent.indexOf('找自习搭子') >= 0) { card = cards[i]; break; } }
    return card && card.querySelector('.tc-name').textContent.trim() === NEW;
  });
  var mineCard = null;
  Array.prototype.forEach.call(D.querySelectorAll('#forum-list .topic-card'), function (c) { if (c.textContent.indexOf('找自习搭子') >= 0) mineCard = c; });
  ok(!!mineCard && mineCard.querySelector('.tc-name').textContent.trim() === NEW, '论坛中我的话题作者名同步更新');
  var mineAv = mineCard && mineCard.querySelector('img.av');
  ok(!!mineAv && /image\/jpeg/.test(mineAv.src), '论坛中我的话题作者头像同步更新');

  /* 改回原昵称并恢复默认头像 */
  W.App.Router.go('profile');
  await waitFor(function () { return !!D.querySelector('[data-act="edit"]'); });
  D.querySelector('[data-act="edit"]').click();
  await waitFor(function () { return !!D.querySelector('.subview.show #pf-form'); });
  var ni2 = D.querySelector('.subview.show #pf-form input[name="nickname"]');
  ni2.value = oldName; ni2.dispatchEvent(new Event('input', { bubbles: true }));
  D.querySelector('.subview.show #av-reset').click();
  await waitFor(function () { var im = D.querySelector('.subview.show #av-img img'); return im && /image\/svg/.test(im.src); });
  D.querySelector('.subview.show #pf-form').dispatchEvent(new Event('submit', { bubbles: true, cancelable: true }));
  await waitFor(function () { return !D.querySelector('.subview.show') && D.querySelector('.pf-name') && D.querySelector('.pf-name').textContent.trim() === oldName; });
  ok(D.querySelector('.pf-name').textContent.trim() === oldName && /image\/svg/.test(W.App.user.avatar), '昵称与头像均已还原为原值');

  /* 僵尸按钮审计：遍历五个主页，任何 <button> 必须带 id / data-* / 已知委托 class */
  var hookClass = /(^|\s)(back|add-btn|st-minus|st-plus|cb-go|checkout-btn|advance-btn|forum-new-btn|reply-send|snap-rollback|dm-btn|dm-btn-primary|dm-btn-outline|seg-item|pf-edit-btn|rp-del|ci-del|cat-chip|serv-item|sum-item|tab-item|menu-row|topic-submit|cm-go|stepper)(\s|$)/;
  var tabs = ['home', 'schedule', 'life', 'forum', 'profile'];
  var suspicious = [];
  for (var t = 0; t < tabs.length; t++) {
    W.App.Router.go(tabs[t]);
    await sleep(280);
    var page = D.querySelector('#view-' + tabs[t]);
    if (!page) { suspicious.push(tabs[t] + ': 页面缺失'); continue; }
    var btns = page.querySelectorAll('button');
    btns.forEach(function (b) {
      var hasData = false;
      for (var i = 0; i < b.attributes.length; i++) { if (b.attributes[i].name.indexOf('data-') === 0) hasData = true; }
      var hooked = !!b.id || hasData || !!b.onclick || hookClass.test(b.className);
      if (!hooked) suspicious.push(tabs[t] + ' <button class="' + b.className + '">' + (b.textContent || '').trim().slice(0, 12) + '</button>');
    });
  }
  ok(suspicious.length === 0, '五个主页无僵尸按钮（实际可疑：' + suspicious.length + (suspicious.length ? '；' + suspicious.slice(0, 5).join(' | ') : '') + '）');

  /* 所有服务入口均可达：10 个服务入口都带 data-srv 且有点击行为（HOME 已覆盖弹窗/跳转，这里校验数量与属性） */
  W.App.Router.go('home');
  await waitFor(function () { return D.querySelectorAll('.serv-item').length === 10; });
  var servNoHook = Array.prototype.filter.call(D.querySelectorAll('.serv-item'), function (s) { return !s.getAttribute('data-srv'); });
  ok(D.querySelectorAll('.serv-item').length === 10 && servNoHook.length === 0, '10 个服务入口均带可识别的 data-srv 行为钩子');

  var failed = results.filter(function (r) { return !r.pass; });
  return { passed: results.length - failed.length, total: results.length, lines: results.map(function (r) { return r.msg; }) };
})().catch(function (e) {
  return { passed: 0, total: 1, lines: ['LINK_FATAL: ' + (e && e.message) + '\n' + (e && e.stack)] };
})
"""

# 备忘 M4 流程（在首页流程之后：此时已有 1 条已完成备忘、0 条待办）
MEMO_JS = r"""
(async function () {
  var results = [];
  function ok(c, msg) { results.push({ pass: !!c, msg: msg + (c ? '  PASS' : '  FAIL') }); }
  function sleep(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }
  async function waitFor(fn, n) {
    for (var i = 0; i < (n || 120); i++) { try { if (fn()) return true; } catch (e) {} await sleep(100); }
    return false;
  }
  var D = document;
  function confirmModal() { var b = D.querySelector('.modal-mask .modal-actions button:last-child'); if (b) b.click(); }
  function titleNum(sel) { var el = D.querySelector(sel); return el ? parseInt((el.textContent || '').replace(/[^0-9]/g, ''), 10) : -1; }
  function openRows() { return D.querySelectorAll('#ml-open .memo-item'); }
  function doneRows() { return D.querySelectorAll('#ml-done .memo-item'); }

  W = window;
  W.App.Router.go('home');
  await waitFor(function () { return D.querySelector('#view-home.active .serv-grid'); });
  D.querySelector('.serv-item[data-srv="memo"]').click();
  await waitFor(function () { return !!D.querySelector('.subview.show #ml-open'); });
  ok(!!D.querySelector('#ml-open .memo-empty'), '进入全部备忘：待办为空态');
  ok(doneRows().length === 1, '首页流程勾选的 1 条归入已完成分区');
  ok(titleNum('#ml-done-title') === 1, '已完成分区标题计数为 1');

  /* 新增两条 */
  function addMemo(txt) {
    D.getElementById('ml-input').value = txt;
    D.getElementById('ml-add').click();
  }
  addMemo('买牛奶');
  await waitFor(function () { return openRows().length === 1; });
  addMemo('复习行测');
  await waitFor(function () { return openRows().length === 2; });
  ok(openRows().length === 2 && titleNum('#ml-open-title') === 2, '新增两条后待办计数为 2');

  /* 勾选第一条（买牛奶）完成 */
  D.querySelector('#ml-open .memo-check').click();
  await waitFor(function () { return openRows().length === 1 && doneRows().length === 2; });
  ok(openRows().length === 1 && doneRows().length === 2, '勾选后待办 1、已完成 2');

  /* 编辑剩余待办 */
  D.querySelector('#ml-open [data-act="edit"]').click();
  await waitFor(function () { return !!D.getElementById('me-input'); });
  ok(/复习行测/.test(D.getElementById('me-input').value), '编辑弹窗预填原内容');
  D.getElementById('me-input').value = '复习行测第二章';
  confirmModal();
  await waitFor(function () { return /第二章/.test(D.querySelector('#ml-open').textContent); });
  ok(/复习行测第二章/.test(D.querySelector('#ml-open .memo-text').textContent), '编辑后文本更新');

  /* 编辑为空应被拒绝（保留原值） */
  D.querySelector('#ml-open [data-act="edit"]').click();
  await waitFor(function () { return !!D.getElementById('me-input'); });
  D.getElementById('me-input').value = '   ';
  confirmModal();
  await sleep(300);
  ok(/复习行测第二章/.test(D.querySelector('#ml-open .memo-text').textContent), '清空内容保存不会覆盖原备忘');
  if (D.querySelector('.modal-mask')) confirmModal();

  /* 删除一条已完成 */
  D.querySelector('#ml-done [data-act="del"]').click();
  await waitFor(function () { return !!D.querySelector('.modal-mask'); });
  confirmModal();
  await waitFor(function () { return doneRows().length === 1; });
  ok(doneRows().length === 1 && titleNum('#ml-done-title') === 1, '删除一条已完成后计数为 1');

  /* 返回首页联动 */
  D.querySelector('.subview.show .back').click();
  await waitFor(function () { return !D.querySelector('.subview.show'); });
  await waitFor(function () {
    var el = D.querySelector('.sum-item[data-go="memo"] .sum-num');
    return el && parseInt((el.textContent || '').replace(/[^0-9]/g, ''), 10) === 1;
  });
  var sumEl = D.querySelector('.sum-item[data-go="memo"] .sum-num');
  ok(sumEl && parseInt((sumEl.textContent || '').replace(/[^0-9]/g, ''), 10) === 1, '首页摘要未完成备忘联动为 1');
  ok(D.querySelectorAll('#memo-list .memo-item').length === 1 &&
     /第二章/.test(D.querySelector('#memo-list .memo-text').textContent), '首页快速备忘卡显示最新待办');

  var failed = results.filter(function (r) { return !r.pass; });
  return {
    passed: results.length - failed.length, total: results.length,
    lines: results.map(function (r) { return r.msg; })
  };
})()
"""


class _Quiet(http.server.SimpleHTTPRequestHandler):
    def end_headers(self):
        self.send_header('Cache-Control', 'no-store, must-revalidate')
        super().end_headers()

    def log_message(self, *a):
        pass


class _Server(socketserver.ThreadingTCPServer):
    allow_reuse_address = True
    daemon_threads = True

    def handle_error(self, request, client_address):
        pass


def start_server():
    handler = functools.partial(_Quiet, directory=ROOT)
    for port in range(8000, 8021):
        try:
            httpd = _Server(('127.0.0.1', port), handler)
            threading.Thread(target=httpd.serve_forever, daemon=True).start()
            return httpd, 'http://127.0.0.1:%d' % port
        except OSError:
            continue
    raise RuntimeError('8000-8020 端口均被占用')


def wait_until(page, expression, timeout=40):
    import time
    deadline = time.time() + timeout
    last = None
    while time.time() < deadline:
        try:
            v = page.eval(expression, timeout=10)
            if v:
                return v
            last = v
        except Exception as e:
            last = str(e)
        time.sleep(0.8)
    raise RuntimeError('等待条件超时: %s (last=%s)' % (expression, last))


def main():
    edge = next((p for p in EDGE_CANDIDATES if os.path.exists(p)), None)
    if not edge:
        print('EDGE_NOT_FOUND')
        return 2
    httpd, base = start_server()
    os.makedirs(SHOT_DIR, exist_ok=True)
    profile_a = tempfile.mkdtemp(prefix='cy_e2e_a_')
    profile_b = tempfile.mkdtemp(prefix='cy_e2e_b_')
    failures = []
    b = Browser(edge, 9222, profile_a)
    b2 = None
    try:
        # 1) 全新 profile：注册/登录/资料/守卫/退出/重登全流程
        page = b.new_page(base + '/index.html')
        wait_until(page, '!!(window.App && window.App.svc)')
        result = page.eval(FLOW_JS, await_promise=True, timeout=60)
        print('FLOW: %s/%s 通过' % (result['passed'], result['total']))
        for line in result['lines']:
            print('  ' + line)
        if result['passed'] != result['total']:
            failures.append('账户流程存在 %d 个失败用例' % (result['total'] - result['passed']))

        # 2) 我的页截图（流程结束停在我的页、登录态）
        pf_png = os.path.join(SHOT_DIR, 'm2-profile.png')
        page.screenshot(pf_png)
        print('PROFILE_SHOT:', os.path.getsize(pf_png))

        # 2.5) 首页 M3 流程（真实 DOM 点击），结束停在首页并截图
        home = page.eval(HOME_JS, await_promise=True, timeout=90)
        print('HOME: %s/%s 通过' % (home['passed'], home['total']))
        for line in home['lines']:
            print('  ' + line)
        if home['passed'] != home['total']:
            failures.append('首页流程存在 %d 个失败用例' % (home['total'] - home['passed']))
        home_png = os.path.join(SHOT_DIR, 'm3-home.png')
        page.screenshot(home_png)
        print('HOME_SHOT:', os.path.getsize(home_png))

        # 2.6) 备忘 M4 流程（分区 / 勾选 / 编辑 / 删除 / 首页联动）
        memo = page.eval(MEMO_JS, await_promise=True, timeout=90)
        print('MEMO: %s/%s 通过' % (memo['passed'], memo['total']))
        for line in memo['lines']:
            print('  ' + line)
        if memo['passed'] != memo['total']:
            failures.append('备忘流程存在 %d 个失败用例' % (memo['total'] - memo['passed']))
        # 打开全部备忘页截图
        page.eval("window.App.Router.openSub(window.App.Subs.memoList())")
        wait_until(page, "!!document.querySelector('.subview.show #ml-open')")
        memo_png = os.path.join(SHOT_DIR, 'm4-memo.png')
        page.screenshot(memo_png)
        print('MEMO_SHOT:', os.path.getsize(memo_png))
        # 关闭备忘二级页，进入课程 M5 流程
        page.eval("window.App.Router.back()")
        wait_until(page, "!document.querySelector('.subview.show')")

        # 2.7) 课程表 M5 流程（周/日视图、表单、冲突、Excel 导入、联动）
        course = page.eval(COURSE_JS, await_promise=True, timeout=120)
        print('COURSE: %s/%s 通过' % (course['passed'], course['total']))
        for line in course['lines']:
            print('  ' + line)
        if course['passed'] != course['total']:
            failures.append('课程流程存在 %d 个失败用例' % (course['total'] - course['passed']))
        # 切到周视图截图
        page.eval("(function(){var b=document.querySelector('#sch-seg [data-view=\"week\"]');if(b)b.click();})()")
        wait_until(page, "!!document.querySelector('#view-schedule.active .sch-cols')")
        sch_png = os.path.join(SHOT_DIR, 'm5-schedule.png')
        page.screenshot(sch_png)
        print('SCHEDULE_SHOT:', os.path.getsize(sch_png))

        # 生活首页截图（M6）
        page.eval("window.App.Router.go('life')")
        wait_until(page, "!!document.querySelector('#view-life.active .shop-card')")
        life_png = os.path.join(SHOT_DIR, 'm6-life.png')
        page.screenshot(life_png)
        print('LIFE_SHOT:', os.path.getsize(life_png))

        # 2.8) 生活购物 M6 流程（购物车 / 跨店 / 模拟下单 / 订单状态）
        shop = page.eval(SHOP_JS, await_promise=True, timeout=120)
        print('SHOP: %s/%s 通过' % (shop['passed'], shop['total']))
        for line in shop['lines']:
            print('  ' + line)
        if shop['passed'] != shop['total']:
            failures.append('生活购物流程存在 %d 个失败用例' % (shop['total'] - shop['passed']))
        wait_until(page, "!!document.querySelector('.subview.show .order-card')")
        orders_png = os.path.join(SHOT_DIR, 'm6-orders.png')
        page.screenshot(orders_png)
        print('ORDERS_SHOT:', os.path.getsize(orders_png))

        # 2.9) 学生论坛 M7 流程（发帖校验 / 评论 / 删除 / 我的论坛 / 守卫）
        forum = page.eval(FORUM_JS, await_promise=True, timeout=120)
        print('FORUM: %s/%s 通过' % (forum['passed'], forum['total']))
        for line in forum['lines']:
            print('  ' + line)
        if forum['passed'] != forum['total']:
            failures.append('学生论坛流程存在 %d 个失败用例' % (forum['total'] - forum['passed']))
        # 等守卫确认后的发帖页退场动画结束、浮层提示消失，再截干净的广场
        wait_until(page, "document.querySelectorAll('#subview-layer .subview').length === 0")
        page.eval("new Promise(function(r){setTimeout(r,2200);})", await_promise=True, timeout=10)
        forum_png = os.path.join(SHOT_DIR, 'm7-forum.png')
        page.screenshot(forum_png)
        print('FORUM_SHOT:', os.path.getsize(forum_png))

        # 2.10) 我的与数据管理 M8（导出 / 恢复 / 异常备份 / 快照回滚 / 学期设置）
        data_res = page.eval(DATA_JS, await_promise=True, timeout=120)
        print('DATA: %s/%s 通过' % (data_res['passed'], data_res['total']))
        for line in data_res['lines']:
            print('  ' + line)
        if data_res['passed'] != data_res['total']:
            failures.append('数据管理流程存在 %d 个失败用例' % (data_res['total'] - data_res['passed']))
        wait_until(page, "!!document.querySelector('.subview.show #dm-snaps')")
        page.eval("new Promise(function(r){setTimeout(r,600);})", await_promise=True, timeout=10)
        data_png = os.path.join(SHOT_DIR, 'm8-data.png')
        page.screenshot(data_png)
        print('DATA_SHOT:', os.path.getsize(data_png))

        # 2.11) M9 联动与僵尸按钮巡检（昵称跨页同步 / 守卫 / 死按钮审计）
        link = page.eval(LINK_JS, await_promise=True, timeout=120)
        print('LINK: %s/%s 通过' % (link['passed'], link['total']))
        for line in link['lines']:
            print('  ' + line)
        if link['passed'] != link['total']:
            failures.append('联动巡检存在 %d 个失败用例' % (link['total'] - link['passed']))
        page.close()

        # 3) 同 profile 重开 index.html，验证刷新后自动登录（IndexedDB 持久化）
        p2 = b.new_page(base + '/index.html')
        auto = wait_until(
            p2,
            "!!window.App.user && document.getElementById('login-gate').style.display === 'none'",
            timeout=30)
        print('PERSIST_AUTO_LOGIN:', bool(auto))
        if not auto:
            failures.append('刷新后未保持登录状态')
        # 充值余额刷新后仍为 24.18（首页测试中模拟充值 +10）
        bal = wait_until(
            p2,
            "(function(){var el=document.getElementById('cc-balance');return !!(el && el.textContent.indexOf('24.18')>=0);})()",
            timeout=30)
        print('PERSIST_BALANCE:', bool(bal))
        if not bal:
            failures.append('模拟充值余额刷新后未持久化')
        # 备忘刷新后仍为 1 条未完成（M4 流程结束状态）
        mp = wait_until(
            p2,
            "(function(){var el=document.querySelector('.sum-item[data-go=\"memo\"] .sum-num');return !!(el && parseInt((el.textContent||'').replace(/[^0-9]/g,''),10)===1);})()",
            timeout=30)
        print('PERSIST_MEMO:', bool(mp))
        if not mp:
            failures.append('备忘数据刷新后未持久化')
        # 课程刷新后仍为 4 门（M5 流程：线性代数+大学英语+计算机基础+体育）
        cn = p2.eval(
            "(async function(){if(!window.App.user)return -1;return (await window.App.svc.course.list(window.App.user.id)).length;})()",
            await_promise=True, timeout=30)
        print('PERSIST_COURSE:', cn)
        if cn != 4:
            failures.append('课程数据刷新后未持久化（应为4门，实际%s）' % cn)
        # 订单与购物车刷新后保持：2 笔订单（1 待取餐 / 1 已完成）、购物车已清空
        od = p2.eval(
            "(async function(){if(!window.App.user)return null;var u=window.App.user;var os=await window.App.svc.order.list(u.id);var ct=await window.App.svc.cart.list(u.id);"
            "return {orders:os.length,cart:ct.length,pending:os.filter(function(o){return o.status==='pending';}).length,done:os.filter(function(o){return o.status==='done';}).length};"
            "})()",
            await_promise=True, timeout=30)
        print('PERSIST_ORDER:', od)
        if not (od and od['orders'] == 2 and od['cart'] == 0 and od['pending'] == 1 and od['done'] == 1):
            failures.append('订单/购物车刷新后状态不正确：%s' % od)
        # 论坛刷新后保持：7 个话题（6 种子 + 自发 1）、自己 1 话题 1 评论
        fd = p2.eval(
            "(async function(){if(!window.App.user)return null;var u=window.App.user;var ts=await window.App.svc.forum.topics();"
            "var mt=await window.App.svc.forum.myTopics(u.id);var mr=await window.App.svc.forum.myReplies(u.id);"
            "return {topics:ts.length,mineT:mt.length,mineR:mr.length};})()",
            await_promise=True, timeout=30)
        print('PERSIST_FORUM:', fd)
        if not (fd and fd['topics'] == 7 and fd['mineT'] == 1 and fd['mineR'] == 1):
            failures.append('论坛数据刷新后未持久化：%s' % fd)

        # A-09 购物车跨「关闭页面再重开」持久化：加购 2 件 → 关闭 → 重开 → 购物车仍在 → 清理
        p2.eval(
            "(async function(){var u=window.App.user;var p=await window.App.svc.shop.productById('shop_market_p1');"
            "await window.App.svc.cart.clear(u.id);await window.App.svc.cart.addItem(u.id,p,2);return true;})()",
            await_promise=True, timeout=30)
        p2.close()
        p3 = b.new_page(base + '/index.html')
        wait_until(p3, "!!window.App.user", timeout=30)
        cart = p3.eval(
            "(async function(){var u=window.App.user;var s=await window.App.svc.cart.summary(u.id);"
            "return {count:s.items.length,qty:s.items.reduce(function(a,x){return a+x.qty;},0),shop:s.shopId,total:s.total};})()",
            await_promise=True, timeout=30)
        print('PERSIST_CART:', cart)
        if not (cart and cart['count'] == 1 and cart['qty'] == 2 and cart['shop'] == 'shop_market' and cart['total'] > 0):
            failures.append('未下单购物车关闭重开后未正确持久化：%s' % cart)
        p3.eval("(async function(){await window.App.svc.cart.clear(window.App.user.id);return true;})()",
                await_promise=True, timeout=30)
        p3.close()

        # 4) 全新 profile：未登录显示登录门并截图
        b2 = Browser(edge, 9223, profile_b)
        g = b2.new_page(base + '/index.html')
        gate_ok = wait_until(
            g,
            "(function(){var el=document.getElementById('login-gate');return el && el.style.display !== 'none' && !!document.getElementById('gate-form');})()",
            timeout=30)
        print('GATE_RENDERED:', bool(gate_ok))
        if not gate_ok:
            failures.append('登录门未正常渲染')
        gate_png = os.path.join(SHOT_DIR, 'm2-login-gate.png')
        g.screenshot(gate_png)
        print('GATE_SHOT:', os.path.getsize(gate_png))
        g.close()

        # 5) A-01 file:// 直开（等价断网）：零外部请求、登录门渲染、本地库与 XLSX 就绪
        from pathlib import Path
        file_uri = Path(os.path.abspath('index.html')).as_uri()
        gf = b2.new_page(file_uri)
        wait_until(
            gf,
            "!!(window.App && window.App.svc) && document.getElementById('login-gate').style.display !== 'none'",
            timeout=30)
        off = gf.eval(
            "(async function(){"
            "var res=performance.getEntriesByType('resource').map(function(e){return e.name;});"
            "var ext=res.filter(function(n){return /^https?:\\/\\//.test(n);});"
            "return {total:res.length,external:ext,"
            "gate:document.getElementById('login-gate').style.display!=='none',"
            "app:!!(window.App&&window.App.svc&&window.AppCore&&window.AppDB),xlsx:!!window.XLSX};"
            "})()",
            await_promise=True, timeout=30)
        print('OFFLINE_FILE:', off)
        if not (off and off.get('gate') and off.get('app') and off.get('xlsx') and len(off.get('external', [])) == 0):
            failures.append('file:// 直开/断网检查失败：%s' % off)
        gf.close()
    except Exception as e:
        failures.append('测试执行异常: %s' % e)
        import traceback
        traceback.print_exc()
    finally:
        b.stop()
        if b2:
            b2.stop()
        for d in (profile_a, profile_b):
            shutil.rmtree(d, ignore_errors=True)
        httpd.shutdown()

    if failures:
        print('FAILURES:')
        print('\n'.join(failures))
        return 1
    print('BROWSER_E2E_ALL_PASS')
    return 0


if __name__ == '__main__':
    sys.exit(main())

