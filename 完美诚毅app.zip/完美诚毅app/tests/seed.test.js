/* M1 种子数据完整性测试 */
const test = require('node:test');
const assert = require('node:assert');
const path = require('node:path');
const Seed = require(path.join(__dirname, '..', 'js', 'seed.js'));
const C = require(path.join(__dirname, '..', 'js', 'core.js'));

const seed = Seed.buildSeed(new Date('2026-10-01T12:00:00'));

test('商家：6 家且覆盖四个分类', () => {
  assert.strictEqual(seed.shops.length, 6);
  C.SHOP_CATEGORIES.forEach(function (cat) {
    assert.ok(seed.shops.some(function (s) { return s.category === cat; }), '缺少分类 ' + cat);
  });
  seed.shops.forEach(function (s) {
    assert.ok(s.id && s.name && s.deliveryDesc && s.icon && s.color, '商家字段不完整: ' + s.name);
    assert.ok(s.minOrder >= 0);
  });
});

test('商品：每家 6-8 个，字段完整、价格合法', () => {
  seed.shops.forEach(function (s) {
    var items = seed.products.filter(function (p) { return p.shopId === s.id; });
    assert.ok(items.length >= 6 && items.length <= 8, s.name + ' 商品数 ' + items.length);
    items.forEach(function (p) {
      assert.ok(p.name, '商品名缺失');
      assert.ok(typeof p.price === 'number' && p.price > 0, p.name + ' 价格非法');
      assert.ok(['normal', 'limited', 'soldout'].indexOf(p.stock) !== -1, p.name + ' 库存态非法');
      assert.ok(p.icon && p.unit && p.category, p.name + ' 字段不完整');
    });
  });
  // 至少各有一个售罄与限量演示态
  assert.ok(seed.products.some(function (p) { return p.stock === 'soldout'; }));
  assert.ok(seed.products.some(function (p) { return p.stock === 'limited'; }));
});

test('论坛：至少 6 个话题，评论引用有效话题，作者均为内置虚拟用户', () => {
  assert.ok(seed.topics.length >= 6);
  var userIds = seed.users.map(function (u) { return u.id; });
  var topicIds = seed.topics.map(function (t) { return t.id; });
  seed.topics.forEach(function (t) {
    assert.ok(t.title && t.content && t.createdAt, '话题字段不完整');
    assert.ok(userIds.indexOf(t.authorId) !== -1, '话题作者不存在');
  });
  assert.ok(seed.replies.length >= 6);
  seed.replies.forEach(function (r) {
    assert.ok(topicIds.indexOf(r.topicId) !== -1, '评论引用了不存在的话题');
    assert.ok(userIds.indexOf(r.authorId) !== -1, '评论作者不存在');
    assert.ok(r.content);
  });
});

test('通知 3 条，设置与版本信息正确', () => {
  assert.strictEqual(seed.notices.length, 3);
  var settingMap = {};
  seed.settings.forEach(function (s) { settingMap[s.key] = s.value; });
  assert.strictEqual(settingMap.semesterStart, '2026-09-07');
  assert.strictEqual(settingMap.cardBalance, 14.18);
  var metaMap = {};
  seed.meta.forEach(function (m) { metaMap[m.key] = m.value; });
  assert.strictEqual(metaMap.seedVersion, Seed.SEED_VERSION);
});

test('虚拟学生账号不可被当作普通账号（用户名以 __ 开头）', () => {
  seed.users.forEach(function (u) {
    assert.ok(u.username.indexOf('__') === 0);
    assert.strictEqual(u.passwordHash, '!virtual');
  });
});
