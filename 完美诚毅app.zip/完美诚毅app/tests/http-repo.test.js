/* ============================================================
 * http-repo.test.js —— 第二阶段端到端测试
 * 自动拉起 Flask 后端（连接 chengyi_campus_test 库），
 * 用 HttpRepo 走真实 HTTP -> MySQL，验证整套业务服务与持久化。
 * 运行：npm test  或  node --test tests/http-repo.test.js
 * ============================================================ */
const { test, before, after, beforeEach } = require('node:test');
const assert = require('node:assert');
const path = require('node:path');
const net = require('node:net');
const { spawn } = require('node:child_process');

const ROOT = path.join(__dirname, '..');
const AppDB = require(path.join(ROOT, 'js', 'db.js'));
const { HttpRepo } = require(path.join(ROOT, 'js', 'http-repo.js'));

const PYTHON = path.join(ROOT, '.venv', 'Scripts', 'python.exe');
const APP_PY = path.join(ROOT, 'backend', 'app.py');
const CONFIG = path.join(ROOT, 'backend', 'config.test.ini');
const STORE_NAMES = AppDB.STORES.map(function (s) { return s.name; });

let child = null;
let base = '';
let serverLog = '';

function freePort() {
  return new Promise(function (resolve, reject) {
    const srv = net.createServer();
    srv.listen(0, '127.0.0.1', function () {
      const p = srv.address().port;
      srv.close(function () { resolve(p); });
    });
    srv.on('error', reject);
  });
}

async function waitHealthy(url, timeoutMs) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    try {
      const r = await fetch(url + '/api/health');
      if (r.ok) {
        const j = await r.json();
        if (j.ok) return;
      }
    } catch (e) { /* 尚未就绪，重试 */ }
    await new Promise(function (r) { setTimeout(r, 300); });
  }
  throw new Error('后端在限定时间内未就绪。日志：\n' + serverLog);
}

before(async function () {
  const port = await freePort();
  base = 'http://127.0.0.1:' + port;
  child = spawn(PYTHON, [APP_PY], {
    cwd: ROOT,
    env: Object.assign({}, process.env, {
      CHENGYI_CONFIG: CONFIG,
      CHENGYI_PORT: String(port),
      CHENGYI_NO_BROWSER: '1',
      PYTHONIOENCODING: 'utf-8',
    }),
  });
  child.stdout.on('data', function (d) { serverLog += d.toString(); });
  child.stderr.on('data', function (d) { serverLog += d.toString(); });
  child.on('error', function (e) { serverLog += '\nSPAWN ERROR: ' + e.message; });
  await waitHealthy(base, 25000);
});

after(function () {
  if (child) { try { child.kill(); } catch (e) { /* ignore */ } }
});

// 每个用例前清空全部表，保证相互隔离
beforeEach(async function () {
  const repo = new HttpRepo({ baseUrl: base });
  for (const name of STORE_NAMES) {
    await repo.clear(name);
  }
});

// 新建一个走 MySQL 的应用（含种子）
async function newApp() {
  const repo = new HttpRepo({ baseUrl: base });
  const svc = AppDB.createServices(repo);
  await svc.seed.ensure();
  return { repo: repo, svc: svc };
}

// 再开一个“全新连接”，等价于刷新页面 / 用 Navicat 另开会话
function freshRepo() { return new HttpRepo({ baseUrl: base }); }
function freshSvc() { return AppDB.createServices(freshRepo()); }

var SEM = '2026-09-07';
function courseForm(over) {
  return Object.assign({
    name: '高等数学', teacher: '李老师', location: '景祺楼101', weekday: 1,
    startTime: '08:00', endTime: '09:40', startDate: '2026-09-07', endDate: '2027-01-10',
    repeat: 'weekly', color: 'blue', note: ''
  }, over || {});
}

/* ---------------- 健康检查 & 种子落库 ---------------- */
test('健康检查：后端连通且返回 15 个数据表', async function () {
  const r = await fetch(base + '/api/health');
  const j = await r.json();
  assert.ok(j.ok);
  assert.strictEqual(j.db, 'chengyi_campus_test');
  assert.strictEqual(j.stores.length, 15);
});

test('种子写入 MySQL 且幂等，跨实例可读到', async function () {
  const app = await newApp();
  assert.strictEqual((await app.svc.shop.list()).length, 6);
  assert.strictEqual((await app.svc.shop.products('shop_canteen')).length, 7);
  const allProducts = await app.repo.getAll('products');
  assert.strictEqual(allProducts.length, 39);
  assert.strictEqual((await app.svc.forum.topics()).length, 6);
  // 幂等：第二次 ensure 不重复写入
  assert.strictEqual(await app.svc.seed.ensure(), false);
  assert.strictEqual((await freshSvc().shop.list()).length, 6);
});

/* ---------------- 账户 ---------------- */
test('注册/登录/会话落库，刷新后仍登录，敏感字段脱敏', async function () {
  const app = await newApp();
  const u = await app.svc.auth.register({
    username: 'wuzhenqin', nickname: '吴振钦', password: '123456',
    confirm: '123456', studentNo: '202642051157'
  });
  assert.ok(u.id);
  assert.ok(!('passwordHash' in u));
  assert.strictEqual(u.school, '集美大学诚毅学院');

  // 数据库里确实存了 hash/salt，但 current() 脱敏
  const rawUsers = await app.repo.getAll('users');
  const raw = rawUsers.filter(function (x) { return x.username === 'wuzhenqin'; })[0];
  assert.ok(raw.passwordHash && raw.passwordHash !== '123456');
  assert.ok(raw.salt);
  assert.strictEqual((await app.svc.auth.current()).username, 'wuzhenqin');

  // 重名拒绝、虚拟账号禁登、错误密码拒绝
  await assert.rejects(function () {
    return app.svc.auth.register({ username: 'wuzhenqin', nickname: '二', password: '123456', confirm: '123456' });
  }, function (e) { return !!e.errors.username; });
  await assert.rejects(function () { return app.svc.auth.login('__helper__', 'x'); },
    function (e) { return !!e.errors.username; });

  // 退出后，全新实例（模拟刷新前退出）current 为 null
  await app.svc.auth.logout();
  assert.strictEqual(await freshSvc().auth.current(), null);

  // 重新登录后，全新实例（模拟刷新/重开）仍是登录态 —— 会话已落 MySQL
  await app.svc.auth.login('wuzhenqin', '123456');
  const cur = await freshSvc().auth.current();
  assert.ok(cur && cur.username === 'wuzhenqin');
});

/* ---------------- 课程 ---------------- */
test('课程增改删落库，日期命中正确，跨实例持久', async function () {
  const app = await newApp();
  const u = await app.svc.auth.register({ username: 'stu1', nickname: '甲', password: '123456', confirm: '123456' });
  const c = await app.svc.course.add(u.id, courseForm());
  assert.ok(c.id);
  // 周一命中、周二不命中
  assert.strictEqual((await app.svc.course.onDate(u.id, '2026-09-07', SEM)).length, 1);
  assert.strictEqual((await app.svc.course.onDate(u.id, '2026-09-08', SEM)).length, 0);
  // 跨实例能读到（已落 MySQL）
  assert.strictEqual((await freshSvc().course.list(u.id)).length, 1);

  await app.svc.course.update(c.id, u.id, courseForm({ name: '线性代数', location: '景祺楼202' }));
  const got = (await freshSvc().course.list(u.id))[0];
  assert.strictEqual(got.name, '线性代数');
  assert.strictEqual(got.location, '景祺楼202');

  await app.svc.course.remove(c.id, u.id);
  assert.strictEqual((await freshSvc().course.list(u.id)).length, 0);
});

/* ---------------- 备忘 ---------------- */
test('备忘新增/完成/计数落库', async function () {
  const app = await newApp();
  const u = await app.svc.auth.register({ username: 'stu2', nickname: '乙', password: '123456', confirm: '123456' });
  await app.svc.memo.add(u.id, '买牛奶');
  const m = await app.svc.memo.add(u.id, '写作业');
  assert.strictEqual(await app.svc.memo.openCount(u.id), 2);
  await app.svc.memo.toggle(m.id, u.id);
  assert.strictEqual(await freshSvc().memo.openCount(u.id), 1);
  const toggled = (await freshSvc().memo.list(u.id)).filter(function (x) { return x.id === m.id; })[0];
  assert.strictEqual(toggled.done, 1);
  assert.ok(toggled.completedAt);
});

/* ---------------- 购物车 / 订单 ---------------- */
test('跨店拦截、下单、状态推进并持久化', async function () {
  const app = await newApp();
  const u = await app.svc.auth.register({ username: 'buyer', nickname: '买家', password: '123456', confirm: '123456' });

  const canteen = await app.svc.shop.products('shop_canteen');
  const tea = await app.svc.shop.products('shop_tea');
  const p1 = canteen.filter(function (p) { return p.stock !== 'soldout'; })[0];
  const p2 = tea.filter(function (p) { return p.stock !== 'soldout'; })[0];

  assert.deepStrictEqual(await app.svc.cart.addItem(u.id, p1, 2), { ok: true });
  // 购物车已有 A 店商品时加 B 店，未带 force -> 拦截
  const conflict = await app.svc.cart.addItem(u.id, p2, 1);
  assert.strictEqual(conflict.ok, false);
  assert.strictEqual(conflict.code, 'shop_conflict');

  const order = await app.svc.order.create(u.id, '请多放花生酱');
  assert.strictEqual(order.shopId, 'shop_canteen');
  assert.strictEqual(order.status, 'pending');
  assert.ok(Array.isArray(order.items) && order.items.length === 1);
  assert.strictEqual(order.items[0].qty, 2);
  // 下单后购物车清空
  assert.strictEqual((await app.svc.cart.list(u.id)).length, 0);

  // 状态推进 pending -> doing -> done
  const s2 = await app.svc.order.advance(order.id, u.id);
  assert.strictEqual(s2.status, 'doing');
  const s3 = await app.svc.order.advance(order.id, u.id);
  assert.strictEqual(s3.status, 'done');
  assert.ok(s3.completedAt);
  assert.strictEqual(s3.logs.length, 3);

  // 跨实例持久化校验
  const f = freshSvc();
  const list = await f.order.list(u.id);
  assert.strictEqual(list.length, 1);
  assert.strictEqual(list[0].status, 'done');
  assert.strictEqual(await f.order.pendingCount(u.id), 0);
});

/* ---------------- 论坛 ---------------- */
test('发帖/回帖/计数/删除权限并持久化', async function () {
  const app = await newApp();
  const a = await app.svc.auth.register({ username: 'poster', nickname: '发帖人', password: '123456', confirm: '123456' });
  const b = await app.svc.auth.register({ username: 'reader', nickname: '围观者', password: '123456', confirm: '123456' });

  const t = await app.svc.forum.createTopic(a.id, '求推荐公选课', '想选给分高的公选课，求学长学姐推荐。');
  const topics = await app.svc.forum.topics();
  assert.strictEqual(topics.length, 7); // 种子 6 + 新帖 1
  const mine = topics.filter(function (x) { return x.id === t.id; })[0];
  assert.strictEqual(mine.authorName, '发帖人');
  assert.strictEqual(mine.replyCount, 0);

  const r = await app.svc.forum.createReply(b.id, t.id, '推荐影视鉴赏');
  const detail = await app.svc.forum.topic(t.id);
  assert.strictEqual(detail.replies.length, 1);
  assert.strictEqual(detail.replyCount, 1);

  // 不能删除他人评论
  await assert.rejects(function () { return app.svc.forum.deleteReply(r.id, a.id); });
  // 本人可删
  await app.svc.forum.deleteReply(r.id, b.id);
  assert.strictEqual((await app.svc.forum.topic(t.id)).replyCount, 0);

  // 跨实例持久化
  assert.strictEqual((await freshSvc().forum.topics()).length, 7);
});

/* ---------------- 设置（JSON 类型保真） ---------------- */
test('校园卡充值：JSON value 数字类型保真且持久', async function () {
  const app = await newApp();
  const start = await app.svc.settings.balance();
  assert.strictEqual(start, 14.18);
  const after = await app.svc.settings.recharge(10);
  assert.strictEqual(after, 24.18);
  // 全新实例读到更新后的数字（而非字符串）
  const v = await freshSvc().settings.balance();
  assert.strictEqual(v, 24.18);
  assert.ok(typeof v === 'number');
});

/* ---------------- 备份 / 快照 / 恢复（事务 replace） ---------------- */
test('备份-改动-恢复：数据回到备份点，且恢复前自动建快照', async function () {
  const app = await newApp();
  const u = await app.svc.auth.register({ username: 'backupman', nickname: '备份君', password: '123456', confirm: '123456' });
  await app.svc.memo.add(u.id, '备忘A');
  const backup = await app.svc.backup.export();
  assert.strictEqual(backup.app, 'chengyi-campus');
  assert.ok(Array.isArray(backup.data.users));

  await app.svc.memo.add(u.id, '备忘B');
  assert.strictEqual((await app.svc.memo.list(u.id)).length, 2);

  await app.svc.backup.restore(backup);
  const mems = await app.svc.memo.list(u.id);
  assert.strictEqual(mems.length, 1);
  assert.strictEqual(mems[0].content, '备忘A');

  // 恢复前创建过快照，且快照经 MySQL 持久化
  const snaps = await app.repo.getAll('snapshots');
  assert.ok(snaps.length >= 1);
  assert.strictEqual(snaps[0].reason, 'before_restore');
  assert.ok(typeof snaps[0].data === 'object' && snaps[0].data !== null);

  // 跨实例确认恢复结果已落库
  assert.strictEqual((await freshSvc().memo.list(u.id)).length, 1);
});

/* ---------------- 一次性迁移：本机 IndexedDB(MemRepo 模拟) -> MySQL ---------------- */
const HttpMod = require(path.join(ROOT, 'js', 'http-repo.js'));
const migrateRepo = HttpMod.migrateRepo;
const summarizeMigration = HttpMod.summarizeMigration;
const hasPersonalData = HttpMod.hasPersonalData;

test('迁移：本机库的账户/课程/备忘/订单/帖子整体写入 MySQL，并替换目标原有数据', async function () {
  // 1) 模拟“旧版本地 IndexedDB”：内存仓储 + 种子 + 一批个人数据
  const srcRepo = new AppDB.MemRepo();
  const srcSvc = AppDB.createServices(srcRepo);
  await srcSvc.seed.ensure();
  const u = await srcSvc.auth.register({
    username: 'olduser', nickname: '老同学', password: '123456',
    confirm: '123456', studentNo: '20260001'
  });
  await srcSvc.course.add(u.id, courseForm());
  await srcSvc.memo.add(u.id, '旧版本地备忘');
  const canteen = await srcSvc.shop.products('shop_canteen');
  const goods = canteen.filter(function (p) { return p.stock !== 'soldout'; })[0];
  await srcSvc.cart.addItem(u.id, goods, 1);
  await srcSvc.order.create(u.id, '旧版本地下的订单');
  await srcSvc.forum.createTopic(u.id, '旧版本地话题', '迁移前在本机发的帖');

  // 2) 当前 MySQL 库已播种，再放一个“仅目标存在”的账号，迁移后应被整体替换掉
  const target = await newApp();
  await target.svc.auth.register({ username: 'targetonly', nickname: '将被替换', password: '123456', confirm: '123456' });

  // 3) 执行迁移（源是内存仓储，等价于浏览器里的 IDBRepo；目标走真实 HTTP->MySQL）
  const stats = await migrateRepo(target.repo, srcRepo);
  assert.strictEqual(stats.realUserCount, 1);
  assert.strictEqual(stats.personal.courses, 1);
  assert.strictEqual(stats.personal.memos, 1);
  assert.strictEqual(stats.personal.orders, 1);
  assert.strictEqual(stats.personal.topics, 1);
  assert.strictEqual(stats.personal.cart, 0); // 下单后购物车已清空

  // 4) 跨实例（等价于 Navicat / 刷新后的新连接）验证数据已落 MySQL
  const f = freshSvc();
  const fr = freshRepo();
  const usernames = (await fr.getAll('users')).map(function (x) { return x.username; });
  assert.ok(usernames.indexOf('olduser') >= 0, '旧账号已迁入');
  assert.ok(usernames.indexOf('targetonly') < 0, '目标独有账号应被整体替换清除');
  // 种子随源一起迁入
  assert.strictEqual((await f.shop.list()).length, 6);
  assert.strictEqual((await fr.getAll('products')).length, 39);
  // 个人数据齐全
  assert.strictEqual((await f.course.list(u.id)).length, 1);
  assert.strictEqual((await f.memo.list(u.id)).length, 1);
  assert.strictEqual((await f.order.list(u.id)).length, 1);
  const topics = await f.forum.topics();
  assert.strictEqual(topics.length, 7); // 种子 6 + 旧帖 1
  assert.ok(topics.some(function (t) { return t.title === '旧版本地话题'; }), '旧话题已迁入');
  // 会话一并迁入：全新实例刷新后自动登录旧账号，且旧账号可登录
  const cur = await f.auth.current();
  assert.ok(cur && cur.username === 'olduser', '会话应随迁移进入数据库');
  const lu = await f.auth.login('olduser', '123456');
  assert.ok(lu && lu.username === 'olduser');
});

test('迁移统计：仅种子判定为无个人数据；含真实账户/备忘才迁移；异常形状被拒绝', async function () {
  const seedOnly = new AppDB.MemRepo();
  await AppDB.createServices(seedOnly).seed.ensure();
  const stats0 = summarizeMigration(await seedOnly.exportAll());
  assert.strictEqual(stats0.realUserCount, 0);
  assert.strictEqual(hasPersonalData(stats0), false);

  const withUser = summarizeMigration({
    users: [{ id: 'x', username: 'real' }], courses: [], memos: [],
    orders: [], cart: [], topics: [], replies: []
  });
  assert.strictEqual(withUser.realUserCount, 1);
  assert.strictEqual(hasPersonalData(withUser), true);

  const withMemo = summarizeMigration({
    users: [], courses: [], memos: [{ id: 'm' }], orders: [], cart: [], topics: [], replies: []
  });
  assert.strictEqual(hasPersonalData(withMemo), true);

  // 源数据缺少 users（形状异常）必须拒绝，且不得调用目标写入
  var replaced = false;
  const badTarget = { replaceAll: async function () { replaced = true; } };
  const badSource = { exportAll: async function () { return { users: null }; } };
  await assert.rejects(migrateRepo(badTarget, badSource));
  assert.strictEqual(replaced, false, '形状异常时不得写入目标');
});
