/* M1 纯函数测试：日期周次、课程调度、冲突、校验、订单、备份、密码 */
const test = require('node:test');
const assert = require('node:assert');
const path = require('node:path');
const C = require(path.join(__dirname, '..', 'js', 'core.js'));

test('日期：星期与周一计算', () => {
  assert.strictEqual(C.weekdayOf('2026-10-01'), 4); // 周四
  assert.strictEqual(C.mondayOfWeek('2026-10-01'), '2026-09-28');
  assert.strictEqual(C.weekdayOf('2026-09-14'), 1); // 周一
});

test('教学周：开学周一为第 1 周，2026-10-01 为第 4 周', () => {
  var sem = C.DEFAULT_SEMESTER_START; // 2026-09-07 周一
  assert.strictEqual(sem, '2026-09-07');
  assert.strictEqual(C.teachingWeek('2026-09-07', sem), 1);
  assert.strictEqual(C.teachingWeek('2026-09-14', sem), 2);
  assert.strictEqual(C.teachingWeek('2026-10-01', sem), 4);
});

test('课程调度：每周课', () => {
  var c = { repeat: 'weekly', weekday: 1, startDate: '2026-09-14', endDate: '2027-01-10', startTime: '08:00', endTime: '09:40' };
  assert.strictEqual(C.courseOnDate(c, '2026-09-14', '2026-09-14'), true);
  assert.strictEqual(C.courseOnDate(c, '2026-09-15', '2026-09-14'), false);
  assert.strictEqual(C.courseOnDate(c, '2026-09-21', '2026-09-14'), true);
  assert.strictEqual(C.courseOnDate(c, '2027-02-01', '2026-09-14'), false); // 超出日期范围
});

test('课程调度：单周 / 双周课', () => {
  var odd = { repeat: 'odd', weekday: 1, startDate: '2026-09-14', endDate: '2027-01-10', startTime: '08:00', endTime: '09:40' };
  var even = Object.assign({}, odd, { repeat: 'even' });
  assert.strictEqual(C.courseOnDate(odd, '2026-09-14', '2026-09-14'), true);  // 第1周 单
  assert.strictEqual(C.courseOnDate(even, '2026-09-14', '2026-09-14'), false);
  assert.strictEqual(C.courseOnDate(odd, '2026-09-21', '2026-09-14'), false); // 第2周 双
  assert.strictEqual(C.courseOnDate(even, '2026-09-21', '2026-09-14'), true);
});

test('课程调度：仅一次', () => {
  var c = { repeat: 'once', weekday: 3, startDate: '2026-10-01', endDate: '2026-10-01', startTime: '10:00', endTime: '11:40' };
  assert.strictEqual(C.courseOnDate(c, '2026-10-01', '2026-09-14'), true);
  assert.strictEqual(C.courseOnDate(c, '2026-10-08', '2026-09-14'), false);
});

test('冲突：同星期时间重叠', () => {
  var a = { id: 'a', repeat: 'weekly', weekday: 1, startDate: '2026-09-14', endDate: '2027-01-10', startTime: '08:00', endTime: '09:40' };
  var b = { id: 'b', repeat: 'weekly', weekday: 1, startDate: '2026-09-14', endDate: '2027-01-10', startTime: '09:00', endTime: '10:40' };
  var c = { id: 'c', repeat: 'weekly', weekday: 2, startDate: '2026-09-14', endDate: '2027-01-10', startTime: '08:00', endTime: '09:40' };
  var d = { id: 'd', repeat: 'weekly', weekday: 1, startDate: '2026-09-14', endDate: '2027-01-10', startTime: '09:50', endTime: '11:30' };
  assert.strictEqual(C.coursesConflict(a, b, '2026-09-14'), true);
  assert.strictEqual(C.coursesConflict(a, c, '2026-09-14'), false); // 不同星期
  assert.strictEqual(C.coursesConflict(a, d, '2026-09-14'), false); // 时间不重叠
  assert.strictEqual(C.findConflicts(a, [b, c, d], '2026-09-14').length, 1);
});

test('冲突：单双周互不冲突；单次课与周期课', () => {
  var odd = { id: 'o', repeat: 'odd', weekday: 1, startDate: '2026-09-14', endDate: '2027-01-10', startTime: '08:00', endTime: '09:40' };
  var even = { id: 'e', repeat: 'even', weekday: 1, startDate: '2026-09-14', endDate: '2027-01-10', startTime: '08:00', endTime: '09:40' };
  assert.strictEqual(C.coursesConflict(odd, even, '2026-09-14'), false);
  var once = { id: 'x', repeat: 'once', weekday: 1, startDate: '2026-09-14', endDate: '2026-09-14', startTime: '08:30', endTime: '09:30' };
  assert.strictEqual(C.coursesConflict(once, odd, '2026-09-14'), true);
});

test('时间格式规范化与比较', () => {
  assert.strictEqual(C.normalizeHM('8:05'), '08:05');
  assert.strictEqual(C.normalizeHM('25:00'), '');
  assert.strictEqual(C.hmOverlap('08:00', '09:40', '09:40', '11:00'), false);
});

test('课程表单校验', () => {
  var bad = C.validateCourseInput({ name: '', location: '', weekday: 9, startTime: '8:00', endTime: '7:00', startDate: '2026-09-14', endDate: '2026-09-13', repeat: 'weekly' });
  assert.strictEqual(bad.ok, false);
  ['name', 'location', 'weekday', 'endTime', 'endDate'].forEach(function (k) { assert.ok(bad.errors[k], '应报 ' + k); });
  var good = C.validateCourseInput({ name: '高数', location: '景祺楼101', weekday: 1, startTime: '08:00', endTime: '09:40', startDate: '2026-09-14', endDate: '2027-01-10', repeat: 'weekly' });
  assert.strictEqual(good.ok, true);
});

test('Excel 行解析：合法行与颜色中文映射', () => {
  var row = { '课程名称': '大学英语', '任课教师': '王老师', '上课地点': '教学楼201', '星期(1-7,1=周一)': '3', '开始时间': '10:00', '结束时间': '11:40', '开始日期': '2026-09-14', '结束日期': '2027-01-10', '重复规则': '每周', '颜色': '橙', '备注': '' };
  var r = C.parseCourseRow(row, 1);
  assert.strictEqual(r.ok, true);
  assert.strictEqual(r.value.weekday, 3);
  assert.strictEqual(r.value.repeat, 'weekly');
  assert.strictEqual(r.value.color, 'orange');
});

test('Excel 行解析：错误行聚合多个错误', () => {
  var r = C.parseCourseRow({ '课程名称': '', '上课地点': '', '星期(1-7,1=周一)': '9', '开始时间': '8点', '结束时间': '', '开始日期': '2026/9/14', '重复规则': '天天' }, 2);
  assert.strictEqual(r.ok, false);
  assert.ok(r.errors.length >= 5);
});

test('购物车合计与订单号', () => {
  assert.strictEqual(C.sumCart([{ price: 0.2, qty: 3 }, { price: 14, qty: 1 }]), 14.6);
  assert.strictEqual(C.formatMoney(14.1 + 0.08), '14.18');
  assert.match(C.makeOrderNo(new Date(2026, 9, 1, 12, 5, 6)), /^CY\d{14}\d{2}$/);
  assert.strictEqual(C.nextOrderStatus('pending'), 'doing');
  assert.strictEqual(C.nextOrderStatus('doing'), 'done');
  assert.strictEqual(C.nextOrderStatus('done'), null);
});

test('论坛与注册表单校验', () => {
  assert.strictEqual(C.validateTopic('', '正文').ok, false);
  assert.strictEqual(C.validateTopic('标题', '').ok, false);
  assert.strictEqual(C.validateTopic('标题', '正文').ok, true);
  assert.strictEqual(C.validateReply('').ok, false);
  var reg = C.validateRegisterForm({ username: 'ab', nickname: '', password: '123', confirm: '456' });
  assert.strictEqual(reg.ok, false);
  assert.ok(reg.errors.username && reg.errors.nickname && reg.errors.password && reg.errors.confirm);
  assert.strictEqual(C.validateRegisterForm({ username: 'wuzhenqin', nickname: '吴振钦', password: '123456', confirm: '123456' }).ok, true);
});

test('密码哈希：同盐一致、异盐不同', async () => {
  var salt = C.randomSalt();
  assert.strictEqual(salt.length, 16);
  var h1 = await C.hashPassword('123456', salt);
  var h2 = await C.hashPassword('123456', salt);
  var h3 = await C.hashPassword('123456', C.randomSalt());
  assert.strictEqual(h1, h2);
  assert.notStrictEqual(h1, h3);
  assert.strictEqual(h1.length, 64);
});

test('备份结构校验', () => {
  assert.strictEqual(C.validateBackup(null).ok, false);
  assert.strictEqual(C.validateBackup({ app: 'other' }).ok, false);
  assert.strictEqual(C.validateBackup({ app: 'chengyi-campus', version: 99, data: {} }).ok, false);
  assert.strictEqual(C.validateBackup({ app: 'chengyi-campus', version: 1, data: {} }).ok, false); // 缺 users
  assert.strictEqual(C.validateBackup({ app: 'chengyi-campus', version: 1, data: { users: [] } }).ok, true);
  var summary = C.backupSummary({ users: [1, 2], courses: [1] });
  assert.strictEqual(summary.users, 2);
  assert.strictEqual(summary.courses, 1);
});
