/* M0 静态结构测试：文件齐全性、HTML 结构、JS 语法、启动链路 */
const test = require('node:test');
const assert = require('node:assert');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const ROOT = path.resolve(__dirname, '..');
const read = (p) => fs.readFileSync(path.join(ROOT, p), 'utf8');
const exists = (p) => fs.existsSync(path.join(ROOT, p));

test('M0-1 交付文件齐全', () => {
  ['index.html', 'js/core.js', 'js/seed.js', 'js/db.js', 'js/app.js',
   'vendor/xlsx.full.min.js', 'serve.py', '启动校园App.bat', 'package.json']
    .forEach((f) => assert.ok(exists(f), '缺少文件: ' + f));
});

test('M0-2 index.html 包含五个一级视图', () => {
  const html = read('index.html');
  ['home', 'schedule', 'life', 'forum', 'profile'].forEach((t) => {
    assert.ok(html.includes('id="view-' + t + '"'), '缺少视图 view-' + t);
  });
});

test('M0-3 底部导航包含五个 tab 且顺序正确', () => {
  const html = read('index.html');
  const order = ['home', 'schedule', 'life', 'forum', 'profile'];
  let cursor = -1;
  order.forEach((t) => {
    const idx = html.indexOf('data-tab="' + t + '"');
    assert.ok(idx > cursor, 'tab ' + t + ' 顺序不对或缺失');
    cursor = idx;
  });
});

test('M0-4 index.html 引用的本地脚本均存在', () => {
  const html = read('index.html');
  const refs = [...html.matchAll(/<script\s+src="([^"]+)"><\/script>/g)].map((m) => m[1]);
  assert.deepEqual(refs, ['vendor/xlsx.full.min.js', 'js/core.js', 'js/seed.js', 'js/db.js', 'js/http-repo.js', 'js/icons.js', 'js/app.js']);
  refs.forEach((r) => assert.ok(exists(r), '引用文件不存在: ' + r));
});

test('M0-5 SheetJS 离线库体积正常', () => {
  const stat = fs.statSync(path.join(ROOT, 'vendor/xlsx.full.min.js'));
  assert.ok(stat.size > 100 * 1024, 'xlsx 库仅 ' + stat.size + ' 字节，可能下载不完整');
});

test('M0-6 全部业务 JS 通过语法编译', () => {
  ['js/core.js', 'js/seed.js', 'js/db.js', 'js/http-repo.js', 'js/icons.js', 'js/app.js'].forEach((f) => {
    const code = read(f);
    assert.doesNotThrow(() => new vm.Script(code, { filename: f }), '语法错误: ' + f);
  });
});

test('M0-7 core.js 导出关键纯函数', () => {
  const Core = require(path.join(ROOT, 'js/core.js'));
  ['teachingWeek', 'courseOnDate', 'findConflicts', 'sumCart', 'makeOrderNo',
   'validateBackup', 'parseCourseRow', 'hashPassword', 'validateTopic', 'validateRegisterForm']
    .forEach((fn) => assert.strictEqual(typeof Core[fn], 'function', '缺少函数 ' + fn));
});

test('M0-8 seed.js / db.js 为可加载 UMD 模块', () => {
  const seed = require(path.join(ROOT, 'js/seed.js'));
  assert.ok(seed && typeof seed.buildSeed === 'function');
  const db = require(path.join(ROOT, 'js/db.js'));
  assert.strictEqual(typeof db.createServices, 'function');
  assert.strictEqual(typeof db.MemRepo, 'function');
  assert.strictEqual(typeof db.IDBRepo, 'function');
});

test('M0-9 serve.py 具备端口探测、开浏览器、静态服务逻辑', () => {
  const py = read('serve.py');
  ['find_port', 'webbrowser.open', 'serve_forever', 'SimpleHTTPRequestHandler'].forEach((s) => {
    assert.ok(py.includes(s), 'serve.py 缺少 ' + s);
  });
});

test('M0-10 启动 bat 为纯 ASCII 且调用 serve.py', () => {
  const bat = read('启动校园App.bat');
  assert.ok(/^[\x00-\x7F]*$/.test(bat), 'bat 含非 ASCII 字符，cmd 可能乱码');
  assert.ok(bat.includes('python serve.py'));
});

test('M0-11 package.json 声明测试命令', () => {
  const pkg = JSON.parse(read('package.json'));
  assert.ok(pkg.scripts && pkg.scripts.test.includes('node --test'));
});

test('M0-12 第二阶段后端与远程仓储文件齐全', () => {
  ['backend/app.py', 'backend/db.py', 'backend/schema.sql', 'backend/config.ini',
   'backend/requirements.txt', 'js/http-repo.js']
    .forEach((f) => assert.ok(exists(f), '缺少文件: ' + f));
});
