# -*- coding: utf-8 -*-
"""最小 Chrome DevTools Protocol 客户端（仅标准库），供无头浏览器测试使用。"""
import base64
import hashlib
import http.client
import json
import os
import socket
import struct
import time
import urllib.parse

_GUID = '258EAFA5-E914-47DA-95CA-C5AB0DC85B11'


class _WS:
    def __init__(self, host, port, path, timeout=15):
        self.sock = socket.create_connection((host, port), timeout=timeout)
        self.sock.settimeout(timeout)
        key = base64.b64encode(os.urandom(16)).decode()
        req = (
            'GET %s HTTP/1.1\r\nHost: %s:%d\r\nUpgrade: websocket\r\n'
            'Connection: Upgrade\r\nSec-WebSocket-Key: %s\r\nSec-WebSocket-Version: 13\r\n\r\n'
        ) % (path, host, port, key)
        self.sock.sendall(req.encode())
        buf = b''
        while b'\r\n\r\n' not in buf:
            buf += self.sock.recv(4096)
        head, _, rest = buf.partition(b'\r\n\r\n')
        if b' 101 ' not in head:
            raise RuntimeError('WebSocket 握手失败: ' + head.decode('latin1'))
        self._frag = None
        self._rb = rest  # 接收缓冲（含握手响应可能夹带的首个数据帧）

    def _send_frame(self, payload):
        mask = os.urandom(4)
        n = len(payload)
        if n < 126:
            head = struct.pack('BB', 0x81, 0x80 | n)
        elif n < 65536:
            # WebSocket 长度字段必须是网络字节序（大端）
            head = struct.pack('>BBH', 0x81, 0x80 | 126, n)
        else:
            head = struct.pack('>BBQ', 0x81, 0x80 | 127, n)
        masked = bytes(b ^ mask[i % 4] for i, b in enumerate(payload))
        self.sock.sendall(head + mask + masked)

    def _need(self, n):
        """确保接收缓冲 self._rb 至少有 n 字节。
        超时时已收到的字节保留在 self._rb 中，保证帧边界永不因超时而错位。"""
        while len(self._rb) < n:
            chunk = self.sock.recv(max(65536, n - len(self._rb)))
            if not chunk:
                raise RuntimeError('WebSocket 连接关闭')
            self._rb += chunk

    def recv(self):
        import os as _os
        dbg = _os.environ.get('CDP_DEBUG')
        while True:
            # 帧头 2 字节（缓冲不足会抛超时，字节不丢，下次可继续）
            self._need(2)
            b1, b2 = self._rb[0], self._rb[1]
            fin = b1 & 0x80
            opcode = b1 & 0x0F
            length = b2 & 0x7F
            hsize = 2
            if length == 126:
                self._need(4)
                length = struct.unpack('>H', self._rb[2:4])[0]
                hsize = 4
            elif length == 127:
                self._need(10)
                length = struct.unpack('>Q', self._rb[2:10])[0]
                hsize = 10
            mask_len = 4 if (b2 & 0x80) else 0
            total = hsize + mask_len + length
            self._need(total)
            frame = self._rb[:total]
            self._rb = self._rb[total:]
            if mask_len:
                mask = frame[hsize:hsize + 4]
                payload = frame[hsize + 4:]
                payload = bytes(b ^ mask[i % 4] for i, b in enumerate(payload))
            else:
                payload = frame[hsize:]
            if dbg:
                print('  [frame] fin=%d opcode=%d len=%d head=%r' % (bool(fin), opcode, length, payload[:80]))
            if opcode == 0x9:  # ping：回 pong，原样带回 payload
                if len(payload) < 126:
                    self.sock.sendall(b'\x8a' + bytes([len(payload)]) + payload)
                else:
                    self.sock.sendall(b'\x8a\x7e' + struct.pack('>H', len(payload)) + payload)
                continue
            if opcode == 0xA:  # pong：忽略
                continue
            if opcode == 0x8:  # close
                try:
                    self.sock.sendall(b'\x88\x00')
                except Exception:
                    pass
                raise RuntimeError('WebSocket 被关闭: ' + payload[:100].decode('latin1', 'replace'))
            if opcode not in (0x0, 0x1):
                continue
            if opcode == 0x1:
                self._frag = payload
            else:
                self._frag = (self._frag or b'') + payload
            if fin:
                msg = self._frag
                self._frag = None
                return json.loads(msg.decode('utf-8', 'replace'))

    def send(self, obj):
        self._send_frame(json.dumps(obj).encode())

    def close(self):
        try:
            self.sock.close()
        except Exception:
            pass


class Browser:
    def __init__(self, edge, port, profile, window=(430, 932)):
        import subprocess
        self.proc = subprocess.Popen([
            edge, '--headless=new',
            # 无头环境无 GPU：用 SwiftShader 软件渲染，否则同步布局/合成永久等待，
            # 表现为 document.body / getElementById / getComputedStyle 等求值静默挂起
            '--use-angle=swiftshader', '--enable-unsafe-swiftshader',
            '--no-first-run', '--no-default-browser-check',
            '--disable-extensions', '--disable-background-networking',
            '--remote-debugging-port=%d' % port,
            '--window-size=%d,%d' % window,
            '--user-data-dir=' + profile, 'about:blank'
        ], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        self.port = port
        for _ in range(60):
            try:
                self._http_get('/json/version')
                return
            except Exception:
                time.sleep(0.5)
        raise RuntimeError('Edge 远程调试端口未就绪')

    def _http(self, method, path):
        conn = http.client.HTTPConnection('127.0.0.1', self.port, timeout=10)
        conn.request(method, path, headers={'Host': '127.0.0.1'})
        r = conn.getresponse()
        data = r.read().decode('utf-8', 'replace')
        conn.close()
        return data

    def _http_get(self, path):
        return self._http('GET', path)

    def new_page(self, url, wait=True):
        enc = urllib.parse.quote(url, safe=':')
        last = None
        for method in ('PUT', 'GET'):
            try:
                data = self._http(method, '/json/new?' + enc)
                info = json.loads(data)
                page = Page(info['webSocketDebuggerUrl'], info['id'], self, self.port)
                page.cmd('Runtime.enable')
                if wait:
                    page.wait_ready()
                return page
            except Exception as e:
                last = e
                continue
        raise RuntimeError('无法创建调试页面: %s' % last)

    def close_page(self, target_id):
        try:
            self._http_get('/json/close/' + target_id)
        except Exception:
            pass

    def stop(self):
        try:
            self.proc.terminate()
            self.proc.wait(timeout=8)
        except Exception:
            try:
                self.proc.kill()
            except Exception:
                pass


class Page:
    def __init__(self, ws_url, target_id, browser, fallback_port):
        self.id = target_id
        self.browser = browser
        m = ws_url.replace('ws://', '').split('/', 1)
        if ':' in m[0]:
            host, port = m[0].split(':')
            port = int(port)
        else:
            host, port = m[0], fallback_port
        self.ws = _WS(host, port, '/' + m[1])
        self._seq = 0
        self._events = {}
        self.default_context = None

    def cmd(self, method, params=None, timeout=60):
        self._seq += 1
        mid = self._seq
        self.ws.send({'id': mid, 'method': method, 'params': params or {}})
        deadline = time.time() + timeout
        while time.time() < deadline:
            self.ws.sock.settimeout(max(0.5, deadline - time.time()))
            msg = self.ws.recv()
            if msg.get('id') == mid:
                if 'error' in msg:
                    raise RuntimeError('CDP %s 失败: %s' % (method, msg['error']))
                return msg.get('result', {})
            if msg.get('method'):
                self._events.setdefault(msg['method'], []).append(msg)
        raise TimeoutError('CDP 调用超时: ' + method)

    def reconnect(self):
        """无头 Edge 的 CDP 会话偶发静默挂起（命令发出后零响应）。
        对同一 target 重开 WebSocket 即可恢复，页面 JS 上下文与 IndexedDB 不受影响。"""
        import json as _json
        for attempt in range(6):
            try:
                info = _json.loads(self.browser._http_get('/json/list'))
                cand = [t for t in info if t.get('id') == self.id and t.get('type') == 'page']
                if not cand:
                    raise RuntimeError('目标页面已不存在')
                wsurl = cand[0]['webSocketDebuggerUrl']
                m = wsurl.replace('ws://', '').split('/', 1)
                if ':' in m[0]:
                    host, pp = m[0].split(':')
                    pp = int(pp)
                else:
                    host, pp = m[0], self.browser.port
                try:
                    self.ws.close()
                except Exception:
                    pass
                self.ws = _WS(host, pp, '/' + m[1])
                self._seq = 0
                self._events = {}
                self.cmd('Runtime.enable')
                return
            except Exception:
                time.sleep(0.5)
        raise RuntimeError('重连调试通道失败')

    def wait_event(self, method, timeout=30):
        queue = self._events.setdefault(method, [])
        deadline = time.time() + timeout
        while time.time() < deadline:
            if queue:
                return queue.pop(0)
            try:
                msg = self.ws.recv()
            except TimeoutError:
                continue
            if msg.get('method'):
                if msg['method'] == method:
                    return msg
                self._events.setdefault(msg['method'], []).append(msg)
        raise TimeoutError('等待事件超时: ' + method)

    def enable(self):
        self.cmd('Runtime.enable')
        self.cmd('Page.enable')

    def _pump(self, seconds=0.5):
        """收一轮事件并入队，不匹配 id 的事件全部缓存。"""
        old = self.ws.sock.gettimeout()
        self.ws.sock.settimeout(seconds)
        try:
            msg = self.ws.recv()
            if msg.get('id'):
                # 迟到的旧响应：忽略
                return
            if msg.get('method'):
                self._events.setdefault(msg['method'], []).append(msg)
        except TimeoutError:
            pass
        except OSError:
            pass
        finally:
            self.ws.sock.settimeout(old)

    def _scan_context(self):
        for ev in self._events.get('Runtime.executionContextCreated', []):
            c = ev.get('params', {}).get('context', {})
            aux = c.get('auxData', {})
            if aux.get('isDefault') and str(c.get('origin', '')).startswith('http'):
                self.default_context = c.get('id')

    def wait_ready(self, timeout=40, expect=None):
        """等待页面加载到可求值状态。eval 自带重连重试，可吸收 CDP 偶发挂起。"""
        time.sleep(1.2)
        deadline = time.time() + timeout
        last_err = None
        while time.time() < deadline:
            try:
                state = self.eval('document.readyState', timeout=8)
                if state in ('interactive', 'complete'):
                    if expect is None:
                        return True
                    if self.eval(expect, timeout=8):
                        return True
            except Exception as e:
                last_err = e
            time.sleep(0.6)
        raise TimeoutError('页面上下文未就绪: %s' % last_err)

    def goto(self, url):
        self._events = {}
        self.default_context = None
        self.cmd('Page.navigate', {'url': url})
        deadline = time.time() + 25
        while time.time() < deadline:
            try:
                ev = self.wait_event('Runtime.executionContextCreated', timeout=8)
            except TimeoutError:
                break
            c = ev.get('params', {}).get('context', {})
            aux = c.get('auxData', {})
            if aux.get('isDefault') and str(c.get('origin', '')).startswith('http'):
                self.default_context = c.get('id')
                break
        try:
            self.wait_event('Page.loadEventFired', timeout=15)
        except TimeoutError:
            pass
        time.sleep(0.6)

    def navigate(self, url):
        self.goto(url)

    def eval(self, expression, await_promise=False, timeout=60, retries=None):
        """对页面求值。无头 Edge 的 CDP 会话偶发静默挂起（零响应），
        非 Promise 求值在超时后重连同 target 重试；Promise 型可能有副作用，不重试。"""
        params = {'expression': expression, 'returnByValue': True}
        if await_promise:
            params['awaitPromise'] = True
            params['timeout'] = timeout * 1000
        if retries is None:
            retries = 1 if await_promise else 4
        last_err = None
        for attempt in range(retries):
            try:
                r = self.cmd('Runtime.evaluate', params, timeout=timeout + 3)
                if 'exceptionDetails' in r:
                    det = r['exceptionDetails']
                    txt = det.get('exception', {}).get('description') or json.dumps(det, ensure_ascii=False)
                    raise RuntimeError('页面脚本异常: ' + txt[:800])
                return r.get('result', {}).get('value')
            except TimeoutError as e:
                last_err = e
                if attempt < retries - 1:
                    self.reconnect()
                    continue
                raise
            except ConnectionError as e:
                last_err = e
                if attempt < retries - 1:
                    time.sleep(0.4)
                    try:
                        self.reconnect()
                    except Exception:
                        pass
                    continue
                raise
        raise last_err if last_err else RuntimeError('求值失败')

    def screenshot(self, path):
        for attempt in range(3):
            try:
                try:
                    self.cmd('Page.enable', timeout=10)
                except Exception:
                    pass
                r = self.cmd('Page.captureScreenshot', {'format': 'png'}, timeout=30)
                with open(path, 'wb') as f:
                    f.write(base64.b64decode(r['data']))
                return
            except TimeoutError:
                if attempt < 2:
                    self.reconnect()
        raise TimeoutError('截图失败')

    def close(self):
        self.ws.close()
        self.browser.close_page(self.id)
