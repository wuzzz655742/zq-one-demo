/* M1 业务服务测试：MemRepo 内存仓储上的完整数据流（账户/课程/备忘/购物/论坛/备份） */
const test = require('node:test');
const assert = require('node:assert');
const path = require('node:path');
const AppDB = require(path.join(__dirname, '..', 'js', 'db.js'));

async function newApp() {
  var repo = new AppDB.MemRepo();
  var svc = AppDB.createServices(repo);
  await svc.seed.ensure();
  return { repo: repo, svc: svc };
}

var SEM = '2026-09-14';
function courseForm(over) {
  return Object.assign({
    name: '高等数学', teacher: '李老师', location: '景祺楼101', weekday: 1,
    startTime: '08:00', endTime: '09:40', startDate: '2026-09-14', endDate: '2027-01-10',
    repeat: 'weekly', color: 'blue', note: ''
  }, over || {});
}

/* ---------------- 种子 ---------------- */
test('种子初始化且幂等', async () => {
  var app = await newApp();
  assert.strictEqual((await app.svc.shop.list()).length, 6);
  assert.strictEqual(await app.svc.seed.ensure(), false);
  assert.strictEqual((await app.svc.shop.list()).length, 6);
  assert.strictEqual((await app.svc.forum.topics()).length, 6);
});

/* ---------------- 账户 ---------------- */
test('注册：成功脱敏、重名拒绝、虚拟账号禁登', async () => {
  var app = await newApp();
  var u = await app.svc.auth.register({ username: 'wuzhenqin', nickname: '吴振钦', password: '123456', confirm: '123456', studentNo: '202642051157' });
  assert.ok(u.id && !('passwordHash' in u));
  assert.strictEqual(u.school, '集美大学诚毅学院');
  await assert.rejects(function () {
    return app.svc.auth.register({ username: 'wuzhenqin', nickname: '二号', password: '123456', confirm: '123456' });
  }, function (e) { return !!e.errors.username; });
  await assert.rejects(function () { return app.svc.auth.login('__helper__', 'x'); }, function (e) { return !!e.errors.username; });
});

test('登录 / 退出 / 自动登录会话', async () => {
  var app = await newApp();
  await app.svc.auth.register({ username: 'wzq', nickname: '小吴', password: 'secret1', confirm: 'secret1' });
  await app.svc.auth.logout();
  assert.strictEqual(await app.svc.auth.current(), null);
  await assert.rejects(function () { return app.svc.auth.login('wzq', 'wrong'); }, function (e) { return !!e.errors.password; });
  var u = await app.svc.auth.login('wzq', 'secret1');
  assert.strictEqual(u.nickname, '小吴');
  var cur = await app.svc.auth.current();
  assert.strictEqual(cur.username, 'wzq');
});

test('资料与头像更新', async () => {
  var app = await newApp();
  var u = await app.svc.auth.register({ username: 'wzq2', nickname: '小吴', password: 'secret1', confirm: 'secret1' });
  var u2 = await app.svc.auth.updateProfile(u.id, { nickname: '吴振钦', signature: '逢考必过' });
  assert.strictEqual(u2.nickname, '吴振钦');
  assert.strictEqual(u2.signature, '逢考必过');
  var u3 = await app.svc.auth.updateAvatar(u.id, 'data:image/png;base64,AAAA');
  assert.strictEqual(u3.avatar, 'data:image/png;base64,AAAA');
});

/* ---------------- 课程 ---------------- */
test('课程：增删改查、冲突提示但不阻止、日期命中', async () => {
  var app = await newApp();
  var u = await app.svc.auth.register({ username: 'stu1', nickname: '甲', password: '123456', confirm: '123456' });
  var c1 = await app.svc.course.add(u.id, courseForm());
  var c2form = courseForm({ name: '大学英语', location: '教学楼202', startTime: '09:00', endTime: '10:40' });
  var conflicts = await app.svc.course.conflicts(u.id, c2form, SEM);
  assert.strictEqual(conflicts.length, 1); // 冲突被发现
  var c2 = await app.svc.course.add(u.id, c2form); // 但不阻止保存
  assert.strictEqual((await app.svc.course.list(u.id)).length, 2);
  var monday = await app.svc.course.onDate(u.id, '2026-09-14', SEM);
  assert.strictEqual(monday.length, 2);
  assert.strictEqual(monday[0].name, '高等数学'); // 按开始时间排序
  var tuesday = await app.svc.course.onDate(u.id, '2026-09-15', SEM);
  assert.strictEqual(tuesday.length, 0);
  await app.svc.course.update(c2.id, u.id, Object.assign(c2form, { weekday: 2 }));
  assert.strictEqual((await app.svc.course.onDate(u.id, '2026-09-14', SEM)).length, 1);
  await app.svc.course.remove(c1.id, u.id);
  assert.strictEqual((await app.svc.course.list(u.id)).length, 1);
});

test('课程：数据按用户隔离，批量导入', async () => {
  var app = await newApp();
  var a = await app.svc.auth.register({ username: 'usra', nickname: 'A', password: '123456', confirm: '123456' });
  await app.svc.auth.logout();
  var b = await app.svc.auth.register({ username: 'usrb', nickname: 'B', password: '123456', confirm: '123456' });
  await app.svc.course.add(a.id, courseForm());
  assert.strictEqual((await app.svc.course.list(b.id)).length, 0);
  await assert.rejects(function () { return app.svc.course.remove('not-exist', b.id); });
  var rows = [
    courseForm({ name: '课1', weekday: 1 }), courseForm({ name: '课2', weekday: 2 }), courseForm({ name: '课3', weekday: 3 })
  ].map(function (f) { return f; });
  var imported = await app.svc.course.importMany(b.id, rows);
  assert.strictEqual(imported.length, 3);
  assert.strictEqual((await app.svc.course.list(b.id)).length, 3);
});

/* ---------------- 备忘 ---------------- */
test('备忘：新增、完成计数、编辑、删除', async () => {
  var app = await newApp();
  var u = await app.svc.auth.register({ username: 'memo1', nickname: 'M', password: '123456', confirm: '123456' });
  await app.svc.memo.add(u.id, '交英语作业');
  var m2 = await app.svc.memo.add(u.id, '取快递');
  assert.strictEqual(await app.svc.memo.openCount(u.id), 2);
  await assert.rejects(function () { return app.svc.memo.add(u.id, '  '); });
  await app.svc.memo.toggle(m2.id, u.id);
  assert.strictEqual(await app.svc.memo.openCount(u.id), 1);
  await app.svc.memo.update(m2.id, u.id, '取顺丰快递');
  var list = await app.svc.memo.list(u.id);
  assert.strictEqual(list.filter(function (x) { return x.content === '取顺丰快递'; }).length, 1);
  await app.svc.memo.remove(m2.id, u.id);
  assert.strictEqual((await app.svc.memo.list(u.id)).length, 1);
});

/* ---------------- 购物 / 订单 ---------------- */
test('购物：加购、跨店拦截、数量修改与合计', async () => {
  var app = await newApp();
  var u = await app.svc.auth.register({ username: 'buy1', nickname: '买', password: '123456', confirm: '123456' });
  var canteen = (await app.svc.shop.products('shop_canteen'));
  var tea = (await app.svc.shop.products('shop_tea'))[0];
  var r1 = await app.svc.cart.addItem(u.id, canteen[0], 1);
  assert.strictEqual(r1.ok, true);
  await app.svc.cart.addItem(u.id, canteen[1], 2);
  var conflict = await app.svc.cart.addItem(u.id, tea, 1);
  assert.strictEqual(conflict.ok, false);
  assert.strictEqual(conflict.code, 'shop_conflict');
  var forced = await app.svc.cart.addItem(u.id, tea, 1, true);
  assert.strictEqual(forced.ok, true);
  var sum = await app.svc.cart.summary(u.id);
  assert.strictEqual(sum.shopId, 'shop_tea');
  assert.strictEqual(sum.items.length, 1);
  await app.svc.cart.addItem(u.id, canteen[0], 1, true);
  var items = await app.svc.cart.list(u.id);
  await app.svc.cart.setQty(items[0].id, u.id, 3);
  await app.svc.cart.setRemark(items[0].id, u.id, '多放辣');
  var sum2 = await app.svc.cart.summary(u.id);
  assert.strictEqual(sum2.total, C2(canteen[0].price * 3));
  assert.strictEqual(sum2.items[0].remark, '多放辣');
  await app.svc.cart.setQty(items[0].id, u.id, 0); // 数量归零即删除
  assert.strictEqual((await app.svc.cart.list(u.id)).length, 0);
});
function C2(n) { return Math.round(n * 100) / 100; }

test('购物：售罄不可加；下单生成订单并清空购物车；状态流转', async () => {
  var app = await newApp();
  var u = await app.svc.auth.register({ username: 'buy2', nickname: '买2', password: '123456', confirm: '123456' });
  var soldout = (await app.svc.shop.products('shop_spicy')).filter(function (p) { return p.stock === 'soldout'; })[0];
  await assert.rejects(function () { return app.svc.cart.addItem(u.id, soldout, 1); });
  await assert.rejects(function () { return app.svc.order.create(u.id, ''); }); // 空车不能下单
  var p = (await app.svc.shop.products('shop_canteen'))[0];
  await app.svc.cart.addItem(u.id, p, 2);
  var order = await app.svc.order.create(u.id, '请放食堂门口货架');
  assert.match(order.orderNo, /^CY\d{16}$/);
  assert.strictEqual(order.status, 'pending');
  assert.strictEqual(order.pickupNote, '请放食堂门口货架');
  assert.strictEqual(order.total, C2(p.price * 2));
  assert.strictEqual((await app.svc.cart.list(u.id)).length, 0);
  assert.strictEqual(await app.svc.order.pendingCount(u.id), 1);
  order = await app.svc.order.advance(order.id, u.id);
  assert.strictEqual(order.status, 'doing');
  order = await app.svc.order.advance(order.id, u.id);
  assert.strictEqual(order.status, 'done');
  assert.ok(order.completedAt);
  var again = await app.svc.order.advance(order.id, u.id);
  assert.strictEqual(again.status, 'done'); // 终态保持
  assert.strictEqual(await app.svc.order.pendingCount(u.id), 0);
});

test('订单按用户隔离', async () => {
  var app = await newApp();
  var a = await app.svc.auth.register({ username: 'ordera', nickname: 'OA', password: '123456', confirm: '123456' });
  var p = (await app.svc.shop.products('shop_market'))[0];
  await app.svc.cart.addItem(a.id, p, 1);
  await app.svc.order.create(a.id, '');
  await app.svc.auth.logout();
  var b = await app.svc.auth.register({ username: 'orderb', nickname: 'OB', password: '123456', confirm: '123456' });
  assert.strictEqual((await app.svc.order.list(b.id)).length, 0);
});

/* ---------------- 论坛 ---------------- */
test('论坛：列表带作者与评论数、发帖校验', async () => {
  var app = await newApp();
  var u = await app.svc.auth.register({ username: 'forum1', nickname: '话痨', password: '123456', confirm: '123456' });
  var topics = await app.svc.forum.topics();
  assert.strictEqual(topics.length, 6);
  assert.ok(topics[0].authorName);
  assert.ok(typeof topics[0].replyCount === 'number');
  await assert.rejects(function () { return app.svc.forum.createTopic(u.id, '', '内容'); });
  var t = await app.svc.forum.createTopic(u.id, '新话题', '正文内容');
  assert.strictEqual((await app.svc.forum.topics()).length, 7);
  assert.ok(await app.svc.forum.recentCount(30) >= 1);
});

test('论坛：评论发布、计数、删除权限', async () => {
  var app = await newApp();
  var a = await app.svc.auth.register({ username: 'foruma', nickname: '甲', password: '123456', confirm: '123456' });
  await app.svc.auth.logout();
  var b = await app.svc.auth.register({ username: 'forumb', nickname: '乙', password: '123456', confirm: '123456' });
  var detail0 = await app.svc.forum.topic('topic_1');
  var n0 = detail0.replies.length;
  var r = await app.svc.forum.createReply(b.id, 'topic_1', '我的评论');
  var detail = await app.svc.forum.topic('topic_1');
  assert.strictEqual(detail.replies.length, n0 + 1);
  assert.strictEqual(detail.replyCount, n0 + 1);
  assert.strictEqual(detail.replies[detail.replies.length - 1].authorName, '乙');
  await assert.rejects(function () { return app.svc.forum.createReply(b.id, 'topic_1', '  '); });
  await assert.rejects(function () { return app.svc.forum.deleteReply(r.id, a.id); }); // 甲不能删乙的
  await app.svc.forum.deleteReply(r.id, b.id);
  var detail2 = await app.svc.forum.topic('topic_1');
  assert.strictEqual(detail2.replies.length, n0);
  assert.strictEqual((await app.svc.forum.myReplies(b.id)).length, 0);
  assert.strictEqual((await app.svc.forum.myTopics(b.id)).length, 0);
});

/* ---------------- 通知 / 设置 ---------------- */
test('通知关闭与模拟充值', async () => {
  var app = await newApp();
  var u = await app.svc.auth.register({ username: 'notice1', nickname: 'N', password: '123456', confirm: '123456' });
  assert.strictEqual((await app.svc.notice.list(u.id)).length, 3);
  await app.svc.notice.dismiss(u.id, 'notice_1');
  assert.strictEqual((await app.svc.notice.list(u.id)).length, 2);
  assert.strictEqual(await app.svc.settings.balance(), 14.18);
  var b = await app.svc.settings.recharge(10);
  assert.strictEqual(b, 24.18);
  await assert.rejects(function () { return app.svc.settings.recharge(-1); });
});

/* ---------------- 备份 / 恢复 / 快照 ---------------- */
test('备份导出结构完整', async () => {
  var app = await newApp();
  var bak = await app.svc.backup.export();
  assert.strictEqual(bak.app, 'chengyi-campus');
  assert.strictEqual(bak.version, 1);
  assert.ok(bak.exportedAt);
  assert.ok(Array.isArray(bak.data.users) && bak.data.users.length >= 3);
  assert.strictEqual(bak.data.shops.length, 6);
  assert.ok(!('snapshots' in bak.data));
});

test('备份文件检查：合法 / 损坏 / 标识错误', async () => {
  var app = await newApp();
  var bak = await app.svc.backup.export();
  assert.strictEqual(app.svc.backup.inspect(JSON.stringify(bak)).ok, true);
  assert.strictEqual(app.svc.backup.inspect('{bad json').ok, false);
  assert.strictEqual(app.svc.backup.inspect(JSON.stringify({ app: 'x' })).ok, false);
});

test('恢复：恢复前自动快照，恢复后数据回到备份点', async () => {
  var app = await newApp();
  var u = await app.svc.auth.register({ username: 'bk1', nickname: 'BK', password: '123456', confirm: '123456' });
  var bak = await app.svc.backup.export(); // A：此时没有备忘
  await app.svc.memo.add(u.id, '恢复后应消失的备忘');
  assert.strictEqual((await app.svc.memo.list(u.id)).length, 1);
  await app.svc.backup.restore(bak);
  assert.strictEqual((await app.svc.memo.list(u.id)).length, 0);
  var snaps = await app.svc.backup.listSnapshots();
  assert.strictEqual(snaps.length, 1);
  assert.strictEqual(snaps[0].reason, 'before_restore');
  // 回滚快照：数据回到恢复前（备忘回来）
  await app.svc.backup.rollback(snaps[0].id);
  assert.strictEqual((await app.svc.memo.list(u.id)).length, 1);
});

test('恢复：坏备份与畸形数据不得覆盖现有数据（原子性）', async () => {
  var app = await newApp();
  var u = await app.svc.auth.register({ username: 'bk2', nickname: 'BK2', password: '123456', confirm: '123456' });
  await app.svc.course.add(u.id, courseForm());
  var before = (await app.svc.course.list(u.id)).length;
  await assert.rejects(function () { return app.svc.backup.restore({ app: 'chengyi-campus', version: 1, data: {} }); }); // 无 data 区
  var malformed = { app: 'chengyi-campus', version: 1, data: { courses: [{ noKey: 1 }] } };
  await assert.rejects(function () { return app.svc.backup.restore(malformed); });
  assert.strictEqual((await app.svc.course.list(u.id)).length, before); // 原数据完好
});

test('快照最多保留 3 份', async () => {
  var app = await newApp();
  for (var i = 0; i < 5; i++) {
    // restore 内部会先快照；用合法备份连续恢复 5 次
    var bak = await app.svc.backup.export();
    await app.svc.backup.restore(bak);
  }
  var snaps = await app.svc.backup.listSnapshots();
  assert.ok(snaps.length <= 3, '快照数=' + snaps.length);
});
