/* M2 图标库完整性测试 */
const test = require('node:test');
const assert = require('node:assert');
const path = require('node:path');
const Icons = require(path.join(__dirname, '..', 'js', 'icons.js'));

test('服务入口恰好 10 个且图标均可渲染', () => {
  assert.strictEqual(Icons.SERVICE.length, 10);
  Icons.SERVICE.forEach(function (s) {
    assert.ok(s.key && s.label, '入口字段不完整');
    assert.match(s.color, /^#[0-9a-fA-F]{6}$/, '颜色非法: ' + s.label);
    assert.ok(Icons.G[s.icon], '缺少图标: ' + s.icon);
  });
  var labels = Icons.SERVICE.map(function (s) { return s.label; });
  ['缴费', '扫一扫', '用电服务', '智能水电', '课程表', '校园购物', '生活服务', '今日备忘', '学生论坛', '全部应用']
    .forEach(function (l) { assert.ok(labels.indexOf(l) !== -1, '缺少入口 ' + l); });
});

test('商家图标映射齐全', () => {
  ['canteen', 'spicy', 'tea', 'market', 'fruit', 'print'].forEach(function (k) {
    assert.ok(Icons.G[Icons.SHOP[k]], '商家图标缺失: ' + k);
  });
});

test('svg / circleIcon 输出合法 HTML', () => {
  var s = Icons.svg('calendar');
  assert.ok(s.indexOf('<svg') === 0 && s.indexOf('</svg>') > 0);
  var c = Icons.circleIcon('bag', '#46bf82', 52);
  assert.ok(c.indexOf('icon-circle') > -1 && c.indexOf('#46bf82') > -1 && c.indexOf('<svg') > -1);
});

test('所有图标坐标均落在 24x24 视图内（防止误用其它坐标系）', () => {
  function check(name, nums, lo, hi, kind) {
    nums.forEach(function (n) {
      var v = parseFloat(n);
      assert.ok(v >= lo && v <= hi, '图标 ' + name + ' ' + kind + ' 越界: ' + v);
    });
  }
  Object.keys(Icons.G).forEach(function (name) {
    var m = Icons.G[name];
    // polygon points 与几何属性都是绝对坐标，严格落在视图内
    (m.match(/points="[^"]*"/g) || []).forEach(function (seg) {
      check(name, seg.match(/-?\d+(\.\d+)?/g), -2, 26, 'points');
    });
    var attrRe = /\b(?:x|y|cx|cy|width|height|r)="(-?\d+(?:\.\d+)?)"/g, am;
    while ((am = attrRe.exec(m))) { check(name, [am[1]], -2, 26, '几何属性'); }
    // path d 中含相对位移（横跨画布时可达 ±24），放宽下界；绝对坐标仍不得超过视图
    (m.match(/ d="[^"]*"/g) || []).forEach(function (seg) {
      check(name, seg.match(/-?\d+(\.\d+)?/g), -24, 26, 'path');
    });
  });
  // logo 必须包含学士帽帽顶（菱形）与流苏，且完整居中
  var logo = Icons.svg('logo');
  assert.ok(logo.indexOf('polygon') > -1 && logo.indexOf('circle') > -1, 'logo 结构不完整');
});
