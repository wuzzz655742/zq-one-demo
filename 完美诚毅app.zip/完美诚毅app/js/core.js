/* ============================================================
 * core.js —— 完美诚毅 纯业务逻辑层（无 DOM / 无 IndexedDB 依赖）
 * UMD：浏览器挂到 window.AppCore；Node 下 module.exports，供单元测试
 * ============================================================ */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.AppCore = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  /* ---------------- 常量 ---------------- */
  var APP_NAME = '完美诚毅';
  var DATA_VERSION = 1;
  var DEFAULT_SEMESTER_START = '2026-09-07'; // 周一（第 1 周）；使 2026-10-01 为第 4 周
  var DEFAULT_BALANCE = 14.18;
  var SCHOOL_NAME = '集美大学诚毅学院';

  var WEEKDAY_SHORT = ['周一', '周二', '周三', '周四', '周五', '周六', '周日'];
  var MONTH_EN = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

  // 节次作息（演示时间，表单允许自定义起止时间覆盖）
  var PERIODS = [
    { no: 1, start: '08:00', end: '08:45' },
    { no: 2, start: '08:55', end: '09:40' },
    { no: 3, start: '10:00', end: '10:45' },
    { no: 4, start: '10:55', end: '11:40' },
    { no: 5, start: '14:00', end: '14:45' },
    { no: 6, start: '14:55', end: '15:40' },
    { no: 7, start: '16:00', end: '16:45' },
    { no: 8, start: '16:55', end: '17:40' },
    { no: 9, start: '19:00', end: '19:45' },
    { no: 10, start: '19:55', end: '20:40' }
  ];

  var COURSE_COLORS = [
    { key: 'red', value: '#d9534d' },
    { key: 'blue', value: '#4d8df7' },
    { key: 'green', value: '#46bf82' },
    { key: 'orange', value: '#ff8a3d' },
    { key: 'purple', value: '#9b7ff5' },
    { key: 'cyan', value: '#38b6e8' },
    { key: 'pink', value: '#ff6b8a' }
  ];
  var COLOR_NAME_TO_KEY = { '红': 'red', '蓝': 'blue', '绿': 'green', '橙': 'orange', '紫': 'purple', '青': 'cyan', '粉': 'pink' };

  var REPEAT_TYPES = {
    weekly: { label: '每周' },
    odd: { label: '单周' },
    even: { label: '双周' },
    once: { label: '仅一次' }
  };

  var ORDER_STATUS = {
    pending: { label: '待取餐', next: 'doing', color: '#ff8a3d' },
    doing: { label: '进行中', next: 'done', color: '#4d8df7' },
    done: { label: '已完成', next: null, color: '#9a958c' }
  };

  var SHOP_CATEGORIES = ['外卖', '超市', '水果', '文印'];

  /* ---------------- 基础工具 ---------------- */
  function pad2(n) { return (n < 10 ? '0' : '') + n; }

  function uid(prefix) {
    var t = Date.now().toString(36);
    var r;
    if (typeof crypto !== 'undefined' && crypto.getRandomValues) {
      var a = new Uint8Array(6);
      crypto.getRandomValues(a);
      r = Array.prototype.map.call(a, function (b) { return b.toString(36); }).join('');
    } else {
      r = Math.random().toString(36).slice(2, 10);
    }
    return (prefix || 'id') + '_' + t + r;
  }

  function round2(n) { return Math.round((Number(n) + Number.EPSILON) * 100) / 100; }
  function formatMoney(n) { return round2(n).toFixed(2); }

  function trim(s) { return (s == null ? '' : String(s)).trim(); }
  function clamp(n, min, max) { return Math.max(min, Math.min(max, n)); }

  /* ---------------- 日期工具（本地时区，YYYY-MM-DD） ---------------- */
  function dateToStr(d) { return d.getFullYear() + '-' + pad2(d.getMonth() + 1) + '-' + pad2(d.getDate()); }
  function todayStr() { return dateToStr(new Date()); }

  function strToDate(s) {
    var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(s);
    if (!m) return null;
    return new Date(Number(m[1]), Number(m[2]) - 1, Number(m[3]));
  }

  function addDays(dateLike, n) {
    var d = typeof dateLike === 'string' ? strToDate(dateLike) : new Date(dateLike.getTime());
    d.setDate(d.getDate() + n);
    return dateToStr(d);
  }

  // 周一=1 ... 周日=7
  function weekdayOf(dateStr) {
    var d = strToDate(dateStr);
    if (!d) return 0;
    return d.getDay() === 0 ? 7 : d.getDay();
  }

  function mondayOfWeek(dateStr) { return addDays(dateStr, 1 - weekdayOf(dateStr)); }

  function daysBetween(a, b) {
    var da = strToDate(a), db = strToDate(b);
    return Math.round((db - da) / 86400000);
  }

  function compareDate(a, b) { return a < b ? -1 : (a > b ? 1 : 0); }

  function rangesOverlap(aStart, aEnd, bStart, bEnd) {
    return compareDate(aStart, bEnd) <= 0 && compareDate(bStart, aEnd) <= 0;
  }

  // 教学周：semesterStart 所在周为第 1 周
  function teachingWeek(dateStr, semesterStart) {
    var base = mondayOfWeek(semesterStart || DEFAULT_SEMESTER_START);
    var n = Math.floor(daysBetween(base, mondayOfWeek(dateStr)) / 7) + 1;
    return n;
  }

  function formatDateCN(dateStr) {
    var d = strToDate(dateStr);
    if (!d) return dateStr;
    return (d.getMonth() + 1) + '月' + d.getDate() + '日';
  }

  function relativeTime(input) {
    var d = input instanceof Date ? input : new Date(input);
    if (isNaN(d.getTime())) return '';
    var diff = Date.now() - d.getTime();
    var min = 60000, hour = 3600000, day = 86400000;
    if (diff < min) return '刚刚';
    if (diff < hour) return Math.floor(diff / min) + '分钟前';
    if (diff < day) return Math.floor(diff / hour) + '小时前';
    if (diff < 2 * day) return '昨天';
    if (diff < 7 * day) return Math.floor(diff / day) + '天前';
    return (d.getMonth() + 1) + '月' + d.getDate() + '日';
  }

  function timeText(date) {
    var d = date || new Date();
    return pad2(d.getHours()) + ':' + pad2(d.getMinutes());
  }

  /* ---------------- 时间 / 课程调度 ---------------- */
  function hmToMinutes(hm) {
    var m = /^(\d{1,2}):(\d{2})$/.exec(trim(hm));
    return m ? Number(m[1]) * 60 + Number(m[2]) : NaN;
  }
  function normalizeHM(hm) {
    var m = /^(\d{1,2}):(\d{2})$/.exec(trim(hm));
    if (!m) return '';
    var h = Number(m[1]), mi = Number(m[2]);
    if (h < 0 || h > 23 || mi < 0 || mi > 59) return '';
    return pad2(h) + ':' + pad2(mi);
  }
  function hmOverlap(s1, e1, s2, e2) {
    var a1 = hmToMinutes(s1), a2 = hmToMinutes(e1), b1 = hmToMinutes(s2), b2 = hmToMinutes(e2);
    if ([a1, a2, b1, b2].some(isNaN)) return false;
    return a1 < b2 && b1 < a2;
  }

  function isValidDateStr(s) { return !!strToDate(s); }

  // 某门课在指定日期是否上课
  function courseOnDate(course, dateStr, semesterStart) {
    if (course.repeat === 'once') return course.startDate === dateStr;
    if (weekdayOf(dateStr) !== Number(course.weekday)) return false;
    if (compareDate(dateStr, course.startDate) < 0 || compareDate(dateStr, course.endDate) > 0) return false;
    if (course.repeat === 'odd' || course.repeat === 'even') {
      var w = teachingWeek(dateStr, semesterStart);
      var parity = w % 2 === 1 ? 'odd' : 'even';
      if (course.repeat !== parity) return false;
    }
    return true;
  }

  function coursesAt(courses, dateStr, semesterStart) {
    return courses
      .filter(function (c) { return courseOnDate(c, dateStr, semesterStart); })
      .sort(function (a, b) { return hmToMinutes(a.startTime) - hmToMinutes(b.startTime); });
  }

  // 两门课是否冲突（存在同时上课且时间重叠）
  function coursesConflict(a, b, semesterStart) {
    if (a.id && b.id && a.id === b.id) return false;
    if (!hmOverlap(a.startTime, a.endTime, b.startTime, b.endTime)) return false;
    if (a.repeat === 'once' && b.repeat === 'once') return a.startDate === b.startDate;
    if (a.repeat === 'once') return courseOnDate(b, a.startDate, semesterStart);
    if (b.repeat === 'once') return courseOnDate(a, b.startDate, semesterStart);
    // 均为周期课
    if (Number(a.weekday) !== Number(b.weekday)) return false;
    if (!rangesOverlap(a.startDate, a.endDate, b.startDate, b.endDate)) return false;
    if (a.repeat === 'odd' && b.repeat === 'even') return false;
    if (a.repeat === 'even' && b.repeat === 'odd') return false;
    return true;
  }

  function findConflicts(course, list, semesterStart) {
    return (list || []).filter(function (c) { return coursesConflict(course, c, semesterStart); });
  }

  /* ---------------- 课程表单 / 导入校验 ---------------- */
  function validateCourseInput(d) {
    var errors = {};
    if (!trim(d.name)) errors.name = '请填写课程名称';
    if (!trim(d.location)) errors.location = '请填写上课地点';
    if (!d.weekday || d.weekday < 1 || d.weekday > 7) errors.weekday = '请选择星期';
    if (!normalizeHM(d.startTime)) errors.startTime = '开始时间格式不正确';
    if (!normalizeHM(d.endTime)) errors.endTime = '结束时间格式不正确';
    if (!errors.startTime && !errors.endTime && hmToMinutes(d.endTime) <= hmToMinutes(d.startTime)) errors.endTime = '结束时间需晚于开始时间';
    if (!isValidDateStr(d.startDate)) errors.startDate = '开始日期不正确';
    if (d.repeat !== 'once') {
      if (!isValidDateStr(d.endDate)) errors.endDate = '结束日期不正确';
      else if (d.endDate < d.startDate) errors.endDate = '结束日期不能早于开始日期';
    }
    if (['weekly', 'odd', 'even', 'once'].indexOf(d.repeat) === -1) errors.repeat = '重复规则不正确';
    return { ok: Object.keys(errors).length === 0, errors: errors };
  }

  // 解析一行 Excel 模板数据；row 为中文表头的对象
  function parseCourseRow(row, index) {
    var errors = [];
    var name = trim(row['课程名称']);
    var teacher = trim(row['任课教师']);
    var location = trim(row['上课地点']);
    var weekday = Number(trim(row['星期(1-7,1=周一)']) || trim(row['星期']));
    var startTime = normalizeHM(row['开始时间']);
    var endTime = normalizeHM(row['结束时间']);
    var startDate = trim(row['开始日期']);
    var endDate = trim(row['结束日期']);
    var repeatRaw = trim(row['重复规则']);
    var colorRaw = trim(row['颜色']);
    var note = trim(row['备注']);

    if (!name) errors.push('课程名称为空');
    if (!location) errors.push('上课地点为空');
    if (!(weekday >= 1 && weekday <= 7)) errors.push('星期需为 1-7');
    if (!startTime) errors.push('开始时间格式应为 HH:MM');
    if (!endTime) errors.push('结束时间格式应为 HH:MM');
    if (startTime && endTime && hmToMinutes(endTime) <= hmToMinutes(startTime)) errors.push('结束时间需晚于开始时间');
    if (!isValidDateStr(startDate)) errors.push('开始日期格式应为 YYYY-MM-DD');
    var repeat = 'weekly';
    if (repeatRaw) {
      var found = Object.keys(REPEAT_TYPES).filter(function (k) { return REPEAT_TYPES[k].label === repeatRaw; });
      repeat = found[0];
      if (!repeat) errors.push('重复规则只能是 每周/单周/双周/仅一次');
    }
    if (repeat === 'once') endDate = startDate;
    if (repeat !== 'once') {
      if (!isValidDateStr(endDate)) errors.push('结束日期格式应为 YYYY-MM-DD');
      else if (endDate < startDate) errors.push('结束日期早于开始日期');
    }
    var colorKey = 'blue';
    if (colorRaw) colorKey = COLOR_NAME_TO_KEY[colorRaw] || colorRaw;
    if (!COURSE_COLORS.some(function (c) { return c.key === colorKey; })) colorKey = 'blue';

    if (errors.length) return { ok: false, index: index, errors: errors };
    return {
      ok: true, index: index,
      value: {
        name: name, teacher: teacher, location: location, weekday: weekday,
        startTime: startTime, endTime: endTime, startDate: startDate, endDate: endDate,
        repeat: repeat, color: colorKey, note: note
      }
    };
  }

  function parseImportRows(rows) {
    return (rows || []).map(function (r, i) { return parseCourseRow(r, i + 1); });
  }

  /* ---------------- 购物车 / 订单 ---------------- */
  function sumCart(items) {
    var total = (items || []).reduce(function (s, it) { return s + Number(it.price) * Number(it.qty); }, 0);
    return round2(total);
  }

  function makeOrderNo(date) {
    var d = date || new Date();
    var core = d.getFullYear() + pad2(d.getMonth() + 1) + pad2(d.getDate()) + pad2(d.getHours()) + pad2(d.getMinutes()) + pad2(d.getSeconds());
    var rand = pad2(Math.floor(Math.random() * 100));
    return 'CY' + core + rand;
  }

  function nextOrderStatus(status) {
    return ORDER_STATUS[status] ? ORDER_STATUS[status].next : null;
  }

  /* ---------------- 论坛校验 ---------------- */
  function validateTopic(title, content) {
    var errors = {};
    if (!trim(title)) errors.title = '标题不能为空';
    else if (trim(title).length > 30) errors.title = '标题不能超过 30 字';
    if (!trim(content)) errors.content = '正文不能为空';
    else if (trim(content).length > 5000) errors.content = '正文不能超过 5000 字';
    return { ok: Object.keys(errors).length === 0, errors: errors };
  }
  function validateReply(content) {
    if (!trim(content)) return { ok: false, error: '评论内容不能为空' };
    if (trim(content).length > 1000) return { ok: false, error: '评论不能超过 1000 字' };
    return { ok: true };
  }

  /* ---------------- 注册校验 / 密码哈希 ---------------- */
  function validateRegisterForm(d) {
    var errors = {};
    if (!/^[A-Za-z0-9_]{3,16}$/.test(trim(d.username))) errors.username = '用户名为 3-16 位字母、数字或下划线';
    if (!trim(d.nickname)) errors.nickname = '请填写昵称';
    else if (trim(d.nickname).length > 12) errors.nickname = '昵称不能超过 12 字';
    if (!d.password || d.password.length < 6) errors.password = '密码至少 6 位';
    if (d.password !== d.confirm) errors.confirm = '两次输入的密码不一致';
    if (d.studentNo && !/^[0-9A-Za-z]{0,20}$/.test(trim(d.studentNo))) errors.studentNo = '学号格式不正确';
    return { ok: Object.keys(errors).length === 0, errors: errors };
  }

  function randomSalt() {
    var a = new Uint8Array(8);
    crypto.getRandomValues(a);
    return Array.prototype.map.call(a, function (b) { return b.toString(16).padStart(2, '0'); }).join('');
  }
  function sha256Hex(text) {
    var buf = new TextEncoder().encode(text);
    return crypto.subtle.digest('SHA-256', buf).then(function (digest) {
      return Array.prototype.map.call(new Uint8Array(digest), function (b) { return b.toString(16).padStart(2, '0'); }).join('');
    });
  }
  function hashPassword(password, salt) { return sha256Hex(salt + ':' + password); }

  /* ---------------- 备份结构 ---------------- */
  var BACKUP_STORES = ['users', 'session', 'courses', 'memos', 'shops', 'products', 'cart', 'orders', 'topics', 'replies', 'notices', 'noticeDismiss', 'settings', 'meta'];

  function validateBackup(obj) {
    if (!obj || typeof obj !== 'object') return { ok: false, error: '文件内容不是有效的备份数据' };
    if (obj.app !== 'chengyi-campus') return { ok: false, error: '文件标识不正确，不是本应用的备份文件' };
    if (typeof obj.version !== 'number') return { ok: false, error: '备份缺少版本号' };
    if (obj.version > DATA_VERSION) return { ok: false, error: '备份版本高于当前应用，无法恢复（' + obj.version + '）' };
    if (!obj.data || typeof obj.data !== 'object') return { ok: false, error: '备份中没有数据区' };
    if (!Array.isArray(obj.data.users)) return { ok: false, error: '备份数据区缺少用户数据，文件可能已损坏' };
    return { ok: true };
  }

  function backupSummary(data) {
    var out = {};
    BACKUP_STORES.forEach(function (s) {
      out[s] = Array.isArray(data[s]) ? data[s].length : 0;
    });
    return out;
  }

  return {
    APP_NAME: APP_NAME, DATA_VERSION: DATA_VERSION, DEFAULT_SEMESTER_START: DEFAULT_SEMESTER_START,
    DEFAULT_BALANCE: DEFAULT_BALANCE, SCHOOL_NAME: SCHOOL_NAME,
    WEEKDAY_SHORT: WEEKDAY_SHORT, MONTH_EN: MONTH_EN, PERIODS: PERIODS,
    COURSE_COLORS: COURSE_COLORS, COLOR_NAME_TO_KEY: COLOR_NAME_TO_KEY,
    REPEAT_TYPES: REPEAT_TYPES, ORDER_STATUS: ORDER_STATUS, SHOP_CATEGORIES: SHOP_CATEGORIES,
    BACKUP_STORES: BACKUP_STORES,
    pad2: pad2, uid: uid, round2: round2, formatMoney: formatMoney, trim: trim, clamp: clamp,
    dateToStr: dateToStr, todayStr: todayStr, strToDate: strToDate, addDays: addDays,
    weekdayOf: weekdayOf, mondayOfWeek: mondayOfWeek, daysBetween: daysBetween, compareDate: compareDate,
    rangesOverlap: rangesOverlap, teachingWeek: teachingWeek, formatDateCN: formatDateCN,
    relativeTime: relativeTime, timeText: timeText,
    hmToMinutes: hmToMinutes, normalizeHM: normalizeHM, hmOverlap: hmOverlap, isValidDateStr: isValidDateStr,
    courseOnDate: courseOnDate, coursesAt: coursesAt, coursesConflict: coursesConflict, findConflicts: findConflicts,
    validateCourseInput: validateCourseInput, parseCourseRow: parseCourseRow, parseImportRows: parseImportRows,
    sumCart: sumCart, makeOrderNo: makeOrderNo, nextOrderStatus: nextOrderStatus,
    validateTopic: validateTopic, validateReply: validateReply,
    validateRegisterForm: validateRegisterForm, randomSalt: randomSalt, hashPassword: hashPassword,
    validateBackup: validateBackup, backupSummary: backupSummary
  };
});
