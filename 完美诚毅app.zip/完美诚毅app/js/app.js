/* ============================================================
 * app.js —— 完美诚毅 应用主控：启动、路由、通用 UI、登录门、我的
 * 依赖：core / seed / db / icons 先于本文件加载
 * ============================================================ */
(function () {
  'use strict';
  var Core = window.AppCore;
  var DB = window.AppDB;
  var Icons = window.AppIcons;
  var I = Icons.svg;
  var App = window.App = { Core: Core, Icons: Icons, user: null, svc: null, repo: null, sem: Core.DEFAULT_SEMESTER_START };

  /* ---------------- DOM 工具 ---------------- */
  function $(sel, root) { return (root || document).querySelector(sel); }
  function $all(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }
  function el(tag, cls, html) {
    var e = document.createElement(tag);
    if (cls) e.className = cls;
    if (html != null) e.innerHTML = html;
    return e;
  }
  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
  function avatarHtml(src, cls) {
    return '<img class="' + (cls || 'avatar') + '" src="' + src + '" alt="头像">';
  }
  App.$ = $; App.$all = $all; App.el = el; App.esc = esc; App.avatarHtml = avatarHtml;

  /* ---------------- 事件总线 ---------------- */
  var listeners = {};
  App.bus = {
    on: function (evt, fn) { (listeners[evt] = listeners[evt] || []).push(fn); },
    emit: function (evt, payload) { (listeners[evt] || []).forEach(function (fn) { try { fn(payload); } catch (e) { console.error(e); } }); }
  };

  /* ---------------- Toast / Modal ---------------- */
  App.UI = {
    toast: function (msg, ms) {
      var root = $('#toast-root');
      var t = el('div', 'toast', msg);
      root.appendChild(t);
      setTimeout(function () { t.style.opacity = '0'; t.style.transition = 'opacity .3s'; setTimeout(function () { t.remove(); }, 320); }, ms || 1800);
    },
    modal: function (opts) {
      return new Promise(function (resolve) {
        var mask = el('div', 'modal-mask');
        var box = el('div', 'modal');
        mask.appendChild(box);
        var h = opts.title ? '<h3>' + esc(opts.title) + '</h3>' : '';
        box.innerHTML = h + '<div class="modal-body">' + (typeof opts.body === 'string' ? opts.body : '') + '</div><div class="modal-actions"></div>';
        var actions = $('.modal-actions', box);
        if (opts.showCancel !== false) {
          var cancel = el('button', 'btn btn-ghost', opts.cancelText || '取消');
          cancel.onclick = function () { close(false); };
          actions.appendChild(cancel);
        }
        var ok = el('button', 'btn ' + (opts.danger ? 'btn-primary' : (opts.okClass || 'btn-blue')), opts.confirmText || '确定');
        ok.onclick = function () { close(true); };
        actions.appendChild(ok);
        if (typeof opts.body !== 'string' && opts.body) $('.modal-body', box).appendChild(opts.body);
        var closed = false;
        function close(val) {
          if (closed) return;
          closed = true;
          mask.classList.remove('show');
          setTimeout(function () { mask.remove(); resolve(val); }, 180);
        }
        $('#modal-root').appendChild(mask);
        requestAnimationFrame(function () { mask.classList.add('show'); });
      });
    },
    alert: function (opts) { return App.UI.modal(Object.assign({ showCancel: false, confirmText: '我知道了' }, opts)); }
  };

  /* ---------------- 路由 ---------------- */
  var TABS = ['home', 'schedule', 'life', 'forum', 'profile'];
  App.Router = {
    tab: 'home', stack: [], activeGuard: null, mounted: false,
    setGuard: function (fn) { this.activeGuard = fn; },
    clearGuard: function () { this.activeGuard = null; },
    tryLeave: function (next) {
      var msg = this.activeGuard && this.activeGuard();
      if (msg) {
        App.UI.modal({ title: '提示', body: esc(msg), confirmText: '离开', cancelText: '继续编辑', danger: true }).then(function (ok) { if (ok) next(); });
      } else next();
    },
    go: function (tab) {
      if (TABS.indexOf(tab) === -1) return;
      var self = this;
      this.tryLeave(function () {
        self.clearGuard();
        self.stack = [];
        $('#subview-layer').innerHTML = '';
        self.tab = tab;
        $all('.page').forEach(function (p) { p.classList.toggle('active', p.dataset.tab === tab); });
        $all('.tab-item').forEach(function (b) { b.classList.toggle('active', b.dataset.tab === tab); });
        $('#status-bar').classList.toggle('warm', tab === 'home');
        var view = $('#view-' + tab);
        if (view) view.scrollTop = 0;
        if (App.Pages[tab] && App.Pages[tab].onShow) App.Pages[tab].onShow();
      });
    },
    openSub: function (view) {
      var self = this;
      this.tryLeave(function () {
        self.clearGuard();
        var layer = $('#subview-layer');
        // 立即移除正在播放离场动画（.show 已移除但尚未 remove）的旧二级页，
        // 避免其残留 DOM 造成重复 id、点击落到旧表单闭包
        $all('#subview-layer .subview:not(.show)').forEach(function (n) { n.remove(); });
        var sub = el('div', 'subview');
        sub.innerHTML =
          '<div class="appbar"><button class="back" aria-label="返回">' + I('back') + '</button>' +
          '<div class="ab-title">' + esc(view.title || '') + '</div>' +
          (view.action ? '<button class="ab-action"></button>' : '<span style="width:34px"></span>') + '</div>' +
          '<div class="subview-body"></div>';
        $('.back', sub).onclick = function () { self.back(); };
        if (view.action) { var act = $('.ab-action', sub); act.textContent = view.action.text; act.onclick = view.action.onClick; }
        var body = $('.subview-body', sub);
        layer.appendChild(sub);
        requestAnimationFrame(function () { sub.classList.add('show'); });
        var entry = { view: view, el: sub, body: body };
        self.stack.push(entry);
        if (view.guard) self.setGuard(view.guard);
        view.mount(body, entry);
      });
    },
    back: function () {
      var self = this;
      this.tryLeave(function () {
        self.clearGuard();
        var entry = self.stack.pop();
        if (!entry) return;
        entry.el.classList.remove('show');
        setTimeout(function () { entry.el.remove(); }, 260);
        if (entry.view && entry.view.onClose) entry.view.onClose();
        var top = self.stack[self.stack.length - 1];
        if (top && top.view.guard) self.setGuard(top.view.guard);
        if (!top && App.Pages[self.tab] && App.Pages[self.tab].onShow) App.Pages[self.tab].onShow();
        else if (top && top.view.onResume) top.view.onResume();
      });
    }
  };

  /* ---------------- 演示功能统一弹窗 ---------------- */
  App.demo = function (name) {
    App.UI.alert({
      title: name + ' · 本地演示',
      body: '「' + esc(name) + '」是演示入口，第一版不接入真实学校服务、支付或摄像头。<br><br>你在本应用中创建的课程、备忘、订单和论坛内容，都保存在本机浏览器中。'
    });
  };

  /* ---------------- 状态栏时钟 ---------------- */
  App.clock = {
    timer: null,
    tick: function () { var t = $('#sb-time'); if (t) t.textContent = Core.timeText(); },
    start: function () { this.tick(); var self = this; this.timer = setInterval(function () { self.tick(); }, 10000); }
  };

  /* ---------------- 头像图片处理（居中裁剪压缩） ---------------- */
  App.fileToAvatar = function (file) {
    return new Promise(function (resolve, reject) {
      if (!file || !/^image\//.test(file.type)) { reject(new Error('请选择图片文件')); return; }
      var fr = new FileReader();
      fr.onload = function () {
        var img = new Image();
        img.onload = function () {
          var size = 256, c = document.createElement('canvas');
          c.width = c.height = size;
          var ctx = c.getContext('2d');
          var s = Math.min(img.width, img.height) || 1;
          ctx.drawImage(img, (img.width - s) / 2, (img.height - s) / 2, s, s, 0, 0, size, size);
          resolve(c.toDataURL('image/jpeg', 0.82));
        };
        img.onerror = function () { reject(new Error('图片读取失败')); };
        img.src = fr.result;
      };
      fr.onerror = function () { reject(new Error('图片读取失败')); };
      fr.readAsDataURL(file);
    });
  };

  /* ---------------- 登录门 ---------------- */
  var Gate = {
    mode: 'login',
    show: function () {
      var gate = $('#login-gate');
      gate.style.display = 'block';
      this.render();
    },
    hide: function () { $('#login-gate').style.display = 'none'; },
    render: function () {
      var self = this;
      var gate = $('#login-gate');
      var isLogin = this.mode === 'login';
      gate.innerHTML =
        '<div class="gate-wrap">' +
        '<div class="gate-brand"><span class="gate-logo">' + I('logo', '', 'width:34px;height:34px;color:#fff') + '</span>' +
        '<h1>完美诚毅</h1><p>集美大学诚毅学院 · 校园生活一站搞定</p></div>' +
        '<div class="card gate-card">' +
        '<div class="seg"><button data-m="login" class="' + (isLogin ? 'on' : '') + '">登录</button><button data-m="register" class="' + (!isLogin ? 'on' : '') + '">注册</button></div>' +
        '<form id="gate-form" autocomplete="off">' +
        '<div class="field" data-k="username"><label>用户名</label><input type="text" name="username" placeholder="3-16 位字母、数字或下划线" maxlength="16"><div class="err"></div></div>' +
        (isLogin ? '' : '<div class="field" data-k="nickname"><label>昵称</label><input type="text" name="nickname" placeholder="同学怎么称呼你" maxlength="12"><div class="err"></div></div>') +
        '<div class="field" data-k="password"><label>密码</label><input type="password" name="password" placeholder="' + (isLogin ? '请输入密码' : '至少 6 位') + '" maxlength="32"><div class="err"></div></div>' +
        (isLogin ? '' :
          '<div class="field" data-k="confirm"><label>确认密码</label><input type="password" name="confirm" maxlength="32"><div class="err"></div></div>' +
          '<div class="field" data-k="studentNo"><label>学号（选填）</label><input type="text" name="studentNo" placeholder="用于校园卡展示" maxlength="20"><div class="err"></div></div>') +
        '<button type="submit" class="btn btn-primary btn-block" style="margin-top:6px">' + (isLogin ? '登 录' : '注册并登录') + '</button>' +
        '</form></div>' +
        '<p class="gate-foot">本地账户无需联网，数据仅保存在本机浏览器；可注册多个账号模拟同学互动</p></div>';
      $('.seg', gate).onclick = function (e) {
        var b = e.target.closest('button'); if (!b) return;
        self.mode = b.dataset.m; self.render();
      };
      $('#gate-form', gate).onsubmit = function (e) {
        e.preventDefault();
        var fd = new FormData(this);
        var data = {
          username: fd.get('username'), nickname: fd.get('nickname') || fd.get('username'),
          password: fd.get('password'), confirm: fd.get('confirm') || fd.get('password'),
          studentNo: fd.get('studentNo') || ''
        };
        self.submit(data, this);
      };
    },
    setErrors: function (form, errors) {
      $all('.field', form).forEach(function (f) {
        var k = f.dataset.k, err = errors[k];
        f.classList.toggle('invalid', !!err);
        $('.err', f).textContent = err || '';
      });
    },
    submit: async function (data, form) {
      var btn = form.querySelector('button[type=submit]');
      try {
        btn.disabled = true;
        var user;
        if (this.mode === 'register') user = await App.svc.auth.register(data);
        else user = await App.svc.auth.login(data.username, data.password);
        App.enterApp(user);
      } catch (e) {
        if (e && e.errors) this.setErrors(form, e.errors);
        else App.UI.toast(e.message || '操作失败，请重试');
        btn.disabled = false;
      }
    }
  };
  App.Gate = Gate;

  // 跨模块联动总线：任一业务数据变更后统一刷新首页摘要与相关模块，
  // 不依赖每个调用点记得刷新；各 refresh 内部对未挂载节点直接跳过，幂等可重复触发。
  App.wireEvents = function () {
    if (this._wired) return;
    this._wired = true;
    this.bus.on('memo:changed', function () { App.Home.refresh(); });
    this.bus.on('course:changed', function () { App.Home.refresh(); });
    this.bus.on('order:changed', function () { App.Home.refresh(); App.Life.refresh(); });
    this.bus.on('forum:changed', function () { App.Home.refresh(); App.Forum.refresh(); });
    this.bus.on('profile:changed', function () { App.Home.refresh(); App.Forum.refresh(); });
    this.bus.on('semester:changed', function () {
      App.Home.refresh();
      if (App.Schedule && App.Schedule.node && typeof App.Schedule.onShow === 'function') App.Schedule.onShow();
    });
  };

  App.enterApp = function (user) {
    App.user = user;
    Gate.hide();
    if (!App.Router.mounted) {
      App.Pages.mountAll();
      App.Router.mounted = true;
      App.wireEvents();
      $all('.tab-item').forEach(function (btn) { btn.addEventListener('click', function () { App.Router.go(btn.dataset.tab); }); });
    }
    App.bus.emit('auth:changed', user);
    App.Router.go('home');
  };

  /* ---------------- 占位页（M3-M8 替换） ---------------- */
  function placeholder(iconName, color, name, desc) {
    return '<div class="placeholder-page"><div class="ph-hero"><div class="ph-emoji">' +
      Icons.circleIcon(iconName, color, 74).replace('icon-circle', 'icon-circle ph-circle') +
      '</div><h2>' + name + '</h2><p>' + desc + '</p></div></div>';
  }

  function courseColor(c) {
    var f = Core.COURSE_COLORS.filter(function (x) { return x.key === (c && c.color); })[0];
    return f ? f.value : '#4d8df7';
  }

  // 装饰性演示二维码（非真实可扫，仅用于校园码演示弹窗）
  function fakeQrSvg() {
    var n = 21, rects = [];
    function inFinder(r, c) {
      return (r < 7 && c < 7) || (r < 7 && c >= n - 7) || (r >= n - 7 && c < 7);
    }
    function finder(r0, c0) {
      for (var r = r0; r < r0 + 7; r++) {
        for (var c = c0; c < c0 + 7; c++) {
          var edge = r === r0 || r === r0 + 6 || c === c0 || c === c0 + 6;
          var core = r >= r0 + 2 && r <= r0 + 4 && c >= c0 + 2 && c <= c0 + 4;
          if (edge || core) rects.push('<rect x="' + c + '" y="' + r + '" width="1" height="1"/>');
        }
      }
    }
    finder(0, 0); finder(0, n - 7); finder(n - 7, 0);
    for (var rr = 0; rr < n; rr++) {
      for (var cc = 0; cc < n; cc++) {
        if (inFinder(rr, cc)) continue;
        var h = (rr * 31 + cc * 17 + 7) % 11;
        if (h < 4) rects.push('<rect x="' + cc + '" y="' + rr + '" width="1" height="1"/>');
      }
    }
    return '<svg viewBox="0 0 21 21" shape-rendering="crispEdges" fill="#232323">' + rects.join('') + '</svg>';
  }

  /* ---------------- 首页（M3） ---------------- */
  App.Home = {
    node: null, _bound: false,

    skeleton: function () {
      var grid = Icons.SERVICE.map(function (s) {
        return '<button class="serv-item" data-srv="' + s.key + '" type="button">' +
          Icons.circleIcon(s.icon, s.color, 46) +
          '<span class="serv-badge" data-badge="' + s.key + '" style="display:none"></span>' +
          '<span>' + s.label + '</span></button>';
      }).join('');
      return '<div class="home-pad">' +
        '<div class="quick-bar">' +
          '<button class="qb-scan" type="button" data-act="scan">' + I('scan') + '<span>扫一扫</span>' + I('chevronRight', '', 'width:15px;height:15px') + '</button>' +
          '<div class="qb-right">' +
            '<button class="qb-pill accent" type="button" data-act="recharge">' + I('wallet', '', 'width:15px;height:15px') + '去充值</button>' +
            '<button class="qb-pill" type="button" data-act="qr">' + I('scanDoc', '', 'width:15px;height:15px') + '校园码</button>' +
          '</div>' +
        '</div>' +
        '<div class="card-deck">' +
          '<div class="campus-card">' +
            '<div class="cc-row1"><div class="cc-badge">诚毅</div>' +
            '<div><div class="cc-school" id="cc-school"></div><div class="cc-user" id="cc-user"></div></div>' +
            '<button class="cc-customize" type="button" data-act="customize" aria-label="卡面定制">' + I('image', '', 'width:17px;height:17px;color:#fff') + '</button></div>' +
            '<button class="cc-blabel" type="button" data-act="recharge" style="background:none;color:#fff;text-align:left">' + I('wallet', '', 'width:14px;height:14px') + '校园卡余额（元）' + I('chevronRight', '', 'width:13px;height:13px') + '</button>' +
            '<div class="cc-balance" id="cc-balance"></div>' +
          '</div>' +
          '<div class="course-card" data-act="course-card" role="button">' +
            '<div class="cc2-date"><span class="cc2-month" id="cc2-month"></span><span class="cc2-day" id="cc2-day"></span>' +
            '<span class="cc2-meta"><b id="cc2-wd"></b><span id="cc2-week"></span></span></div>' +
            '<div class="cc2-list" id="cc2-list"></div>' +
            '<div class="cc2-foot">完整课表 ' + I('chevronRight', '', 'width:14px;height:14px') + '</div>' +
          '</div>' +
        '</div>' +
        '<div class="serv-grid">' + grid + '</div>' +
        '<div class="card notice-card" id="home-notices" style="display:none"></div>' +
        '<div class="block-head"><h3>今日概况</h3></div>' +
        '<div class="card summary-card" id="home-summary"></div>' +
        '<div class="card memo-card">' +
          '<div class="memo-head"><h3>快速备忘</h3>' +
          '<button class="memo-add-btn" type="button" data-act="memo-add">' + I('plus', '', 'width:14px;height:14px') + '记一条</button></div>' +
          '<div id="memo-list"></div>' +
          '<button class="memo-all" type="button" data-act="memo-all">查看全部备忘 ' + I('chevronRight', '', 'width:13px;height:13px') + '</button>' +
        '</div>' +
      '</div>';
    },

    mount: function (node) {
      var self = this;
      this.node = node;
      node.innerHTML = this.skeleton();
      if (!this._bound) {
        this._bound = true;
        node.onclick = function (e) { self.onClick(e); };
        App.bus.on('profile:changed', function () { if (App.user) self.renderCard(); });
      }
      this.refresh();
    },

    labelOf: function (key) {
      var s = Icons.SERVICE.filter(function (x) { return x.key === key; })[0];
      return s ? s.label : key;
    },

    onClick: function (e) {
      var srvEl = e.target.closest('[data-srv]');
      if (srvEl) { this.runService(srvEl.dataset.srv); return; }
      var actEl = e.target.closest('[data-act]');
      if (actEl) {
        var act = actEl.dataset.act;
        if (act === 'scan') this.openScan();
        else if (act === 'recharge') this.openRecharge();
        else if (act === 'qr') this.openQr();
        else if (act === 'customize') App.demo('卡面定制');
        else if (act === 'course-card') App.Router.go('schedule');
        else if (act === 'memo-add') this.addMemo();
        else if (act === 'memo-all') App.Router.openSub(App.Subs.memoList());
        return;
      }
      var nEl = e.target.closest('[data-nid]');
      if (nEl) { this.dismissNotice(nEl.dataset.nid); return; }
      var mEl = e.target.closest('[data-mid]');
      if (mEl) {
        if (mEl.classList.contains('memo-check')) this.toggleMemo(mEl.dataset.mid);
        else if (mEl.classList.contains('memo-del')) this.removeMemo(mEl.dataset.mid);
        return;
      }
      var gEl = e.target.closest('[data-go]');
      if (gEl) { this.goSummary(gEl.dataset.go); }
    },

    runService: function (key) {
      if (key === 'schedule') App.Router.go('schedule');
      else if (key === 'shop') App.Router.go('life');
      else if (key === 'forum') App.Router.go('forum');
      else if (key === 'memo') App.Router.openSub(App.Subs.memoList());
      else if (key === 'apps' || key === 'life') App.Router.openSub(App.Subs.appsPanel());
      else if (key === 'scan') this.openScan();
      else App.demo(this.labelOf(key));
    },

    goSummary: function (go) {
      if (go === 'schedule') App.Router.go('schedule');
      else if (go === 'memo') App.Router.openSub(App.Subs.memoList());
      else if (go === 'forum') App.Router.go('forum');
      else if (go === 'order') {
        var n = this._pending || 0;
        if (n > 0) { App.Router.go('life'); App.Router.openSub(App.Subs.ordersList()); }
        else App.UI.toast('暂无待处理订单');
      }
    },

    onShow: function () { if (App.user) this.refresh(); },

    refresh: async function () {
      if (!App.user || !this.node) return;
      var uid = App.user.id, self = this;
      var today = Core.todayStr();
      try {
        var res = await Promise.all([
          App.svc.settings.balance(),
          App.svc.course.onDate(uid, today, App.sem),
          App.svc.memo.list(uid),
          App.svc.notice.list(uid),
          App.svc.order.pendingCount(uid),
          App.svc.forum.recentCount(7)
        ]);
        var balance = res[0], courses = res[1], memos = res[2], notices = res[3];
        this._pending = res[4];
        var weekTopics = res[5];
        var openMemos = memos.filter(function (m) { return !m.done; });
        this.renderCard(balance);
        this.renderCourseCard(courses);
        this.renderNotices(notices);
        this.renderSummary(courses.length, openMemos.length, this._pending, weekTopics);
        this.renderMemos(openMemos.slice(0, 3));
        this.renderBadges(openMemos.length, weekTopics);
      } catch (err) {
        console.error('首页刷新失败', err);
      }
    },

    renderCard: function (balance) {
      if (!this.node) return;
      var u = App.user;
      if (!u) return;
      var school = $('#cc-school', this.node), user = $('#cc-user', this.node), bal = $('#cc-balance', this.node);
      if (school) school.textContent = u.school || Core.SCHOOL_NAME;
      if (user) user.textContent = u.nickname + (u.studentNo ? ' · ' + u.studentNo : '');
      if (bal) {
        var b = (balance != null ? balance : (this._balance != null ? this._balance : Core.DEFAULT_BALANCE));
        this._balance = b;
        bal.innerHTML = '<span class="yen">¥</span>' + Core.formatMoney(b);
      }
    },

    renderCourseCard: function (courses) {
      var d = new Date(), today = Core.todayStr();
      setText('#cc2-month', Core.MONTH_EN[d.getMonth()] + '.');
      setText('#cc2-day', d.getDate());
      setText('#cc2-wd', Core.WEEKDAY_SHORT[Core.weekdayOf(today) - 1]);
      setText('#cc2-week', '第 ' + Core.teachingWeek(today, App.sem) + ' 周');
      var list = $('#cc2-list', this.node);
      if (!list) return;
      if (!courses.length) {
        list.innerHTML = '<div class="cc2-empty">今天没有课程<br>享受课余时光，或点右上角添加新课</div>';
        return;
      }
      list.innerHTML = courses.slice(0, 3).map(function (c) {
        return '<div class="cc2-item"><span class="cc2-dot" style="background:' + courseColor(c) + '"></span>' +
          '<span class="cc2-time">' + c.startTime + '-' + c.endTime + '</span>' +
          '<span class="cc2-name">' + esc(c.name) + '</span>' +
          '<span class="cc2-loc">' + esc(c.location || '') + '</span></div>';
      }).join('');
    },

    renderNotices: function (notices) {
      var box = $('#home-notices', this.node);
      if (!box) return;
      if (!notices.length) { box.style.display = 'none'; box.innerHTML = ''; return; }
      box.style.display = '';
      box.innerHTML = notices.map(function (n) {
        var isRainbow = n.iconType === 'rainbow';
        var bg = isRainbow ? 'background:#eef4ff;color:#4d8df7' : 'background:#fdeee2;color:#ff8a3d';
        var icon = isRainbow ? I('rainbow', '', 'width:21px;height:21px') : I('horn', '', 'width:19px;height:19px');
        return '<div class="notice-row"><span class="notice-ic" style="' + bg + '">' + icon + '</span>' +
          '<div class="notice-main"><div class="notice-txt">' + esc(n.content) + '</div>' +
          (n.timeText ? '<div class="notice-time">' + esc(n.timeText) + '</div>' : '') + '</div>' +
          '<button class="notice-x" type="button" data-nid="' + n.id + '" aria-label="关闭通知">' + I('close', '', 'width:14px;height:14px') + '</button></div>';
      }).join('');
    },

    renderSummary: function (courseN, memoN, orderN, topicN) {
      var box = $('#home-summary', this.node);
      if (!box) return;
      function item(go, num, unit, label) {
        return '<button class="sum-item" type="button" data-go="' + go + '"><span class="sum-num">' + num +
          '<span class="unit">' + unit + '</span></span><span class="sum-label">' + label + '</span></button>';
      }
      box.innerHTML = item('schedule', courseN, '节', '今日课程') +
        item('memo', memoN, '条', '未完成备忘') +
        item('order', orderN, '单', '待处理订单') +
        item('forum', topicN, '条', '近7天话题');
    },

    renderMemos: function (openMemos) {
      var box = $('#memo-list', this.node);
      if (!box) return;
      if (!openMemos.length) {
        box.innerHTML = '<div class="memo-empty">' + I('emptyBox', '', 'width:56px;height:56px') +
          '<p>还没有待办，点右上角「记一条」</p></div>';
        return;
      }
      box.innerHTML = openMemos.map(function (m) {
        return '<div class="memo-item"><button class="memo-check" type="button" data-mid="' + m.id + '" aria-label="完成">' +
          I('check', '', 'width:12px;height:12px') + '</button><span class="memo-text">' + esc(m.content) + '</span></div>';
      }).join('');
    },

    renderBadges: function (memoN, topicN) {
      function set(key, n) {
        var b = document.querySelector('[data-badge="' + key + '"]');
        if (!b) return;
        if (n > 0) { b.textContent = n > 99 ? '99+' : String(n); b.style.display = ''; }
        else b.style.display = 'none';
      }
      set('memo', memoN);
      set('forum', topicN);
    },

    /* ---- 演示弹窗 ---- */
    openScan: function () {
      var body = '<div style="width:150px;height:150px;margin:4px auto 12px;border-radius:16px;background:#1f2430;position:relative;overflow:hidden">' +
        '<div style="position:absolute;inset:18px;border:1.5px solid rgba(255,255,255,.55);border-radius:10px"></div>' +
        '<div style="position:absolute;left:18px;right:18px;height:2px;background:#5be08f;box-shadow:0 0 12px #5be08f;top:50%;animation:scanline 1.6s ease-in-out infinite"></div>' +
        '<div style="position:absolute;top:16px;left:16px;width:18px;height:18px;border-top:3px solid #5be08f;border-left:3px solid #5be08f;border-top-left-radius:6px"></div>' +
        '<div style="position:absolute;top:16px;right:16px;width:18px;height:18px;border-top:3px solid #5be08f;border-right:3px solid #5be08f;border-top-right-radius:6px"></div>' +
        '<div style="position:absolute;bottom:16px;left:16px;width:18px;height:18px;border-bottom:3px solid #5be08f;border-left:3px solid #5be08f;border-bottom-left-radius:6px"></div>' +
        '<div style="position:absolute;bottom:16px;right:16px;width:18px;height:18px;border-bottom:3px solid #5be08f;border-right:3px solid #5be08f;border-bottom-right-radius:6px"></div>' +
        '</div><div style="text-align:center;font-size:12.5px;color:var(--ink-sub)">扫一扫为本地演示，不会调用摄像头</div>';
      App.UI.alert({ title: '扫一扫 · 本地演示', body: body, confirmText: '我知道了' });
    },

    openQr: function () {
      var u = App.user || {};
      var body = '<div class="qr-box">' + fakeQrSvg() + '</div>' +
        '<div style="text-align:center;font-size:14px;font-weight:700">' + esc(u.nickname || '') + '</div>' +
        '<div style="text-align:center;font-size:12px;color:var(--ink-sub);margin-top:3px">' + esc(u.studentNo || '') + '</div>' +
        '<div style="text-align:center;font-size:11.5px;color:var(--ink-sub);margin-top:8px">校园码为本地演示图案，不连接学校门禁或消费系统</div>';
      App.UI.alert({ title: '校园码 · 本地演示', body: body, confirmText: '关闭' });
    },

    openRecharge: function () {
      var self = this;
      var box = el('div');
      box.innerHTML = '<div style="text-align:center;font-size:13px;color:var(--ink-2)">当前校园卡余额（模拟）</div>' +
        '<div id="rc-bal" style="text-align:center;font-size:30px;font-weight:800;margin:6px 0 14px;color:var(--red)">¥ ' + Core.formatMoney(self._balance == null ? Core.DEFAULT_BALANCE : self._balance) + '</div>' +
        '<div class="recharge-amt"><button type="button" data-amt="10">+10</button><button type="button" data-amt="50">+50</button><button type="button" data-amt="100">+100</button></div>' +
        '<div class="recharge-note">模拟数据，不发生真实支付；金额仅保存在本机浏览器</div>';
      $all('[data-amt]', box).forEach(function (btn) {
        btn.onclick = async function () {
          var b = await App.svc.settings.recharge(Number(btn.dataset.amt));
          self._balance = b;
          $('#rc-bal', box).textContent = '¥ ' + Core.formatMoney(b);
          self.renderCard(b);
          App.UI.toast('已模拟充值 +' + btn.dataset.amt + ' 元');
        };
      });
      App.UI.modal({ title: '校园卡充值', body: box, showCancel: false, confirmText: '完成' });
    },

    addMemo: function () {
      var self = this;
      var wrap = el('div');
      wrap.innerHTML = '<textarea id="mf-input" rows="3" maxlength="100" placeholder="记一条今天要做的事…" style="width:100%;border:1px solid var(--line);background:#fbfaf8;border-radius:12px;padding:10px;font-size:14px;resize:none;outline:none"></textarea>';
      App.UI.modal({ title: '快速备忘', body: wrap, confirmText: '保存', cancelText: '取消' }).then(async function (ok) {
        if (!ok) return;
        var txt = $('#mf-input', wrap).value;
        if (!txt.trim()) { App.UI.toast('备忘内容不能为空'); return; }
        await App.svc.memo.add(App.user.id, txt);
        App.UI.toast('已添加备忘');
        App.bus.emit('memo:changed');
      });
    },

    toggleMemo: async function (mid) {
      await App.svc.memo.toggle(mid, App.user.id);
      App.bus.emit('memo:changed');
    },

    removeMemo: function (mid) {
      var self = this;
      App.UI.modal({ title: '删除备忘', body: '确定删除这条备忘吗？此操作不可撤销。', confirmText: '删除', danger: true }).then(async function (ok) {
        if (!ok) return;
        await App.svc.memo.remove(mid, App.user.id);
        App.UI.toast('已删除');
        App.bus.emit('memo:changed');
      });
    },

    dismissNotice: async function (nid) {
      await App.svc.notice.dismiss(App.user.id, nid);
      var notices = await App.svc.notice.list(App.user.id);
      this.renderNotices(notices);
    }
  };

  function setText(sel, txt) {
    var node = $(sel, App.Home.node);
    if (node) node.textContent = txt;
  }

  function hexA(hex, a) {
    var m = /^#?([0-9a-f]{6})$/i.exec(hex || '');
    if (!m) return 'rgba(77,141,247,' + a + ')';
    var n = parseInt(m[1], 16);
    return 'rgba(' + ((n >> 16) & 255) + ',' + ((n >> 8) & 255) + ',' + (n & 255) + ',' + a + ')';
  }

  // 论坛相对时间：刚刚 / x 分钟前 / x 小时前 / x 天前 / M月D日
  function forumTime(iso) {
    var t = new Date(iso).getTime();
    if (isNaN(t)) return '';
    var d = Date.now() - t;
    if (d < 0) d = 0;
    var m = Math.floor(d / 60000);
    if (m < 1) return '刚刚';
    if (m < 60) return m + ' 分钟前';
    var h = Math.floor(m / 60);
    if (h < 24) return h + ' 小时前';
    var day = Math.floor(h / 24);
    if (day < 7) return day + ' 天前';
    var dt = new Date(t);
    return (dt.getMonth() + 1) + '月' + dt.getDate() + '日';
  }

  // 课程块在 10 节网格中的起始行与跨行数
  function locateCourse(c) {
    var P = Core.PERIODS, m = Core.hmToMinutes;
    var s = m(c.startTime), e = m(c.endTime), si = -1, i, j;
    for (i = 0; i < P.length; i++) { if (s >= m(P[i].start) && s < m(P[i].end)) { si = i; break; } }
    if (si < 0) { for (i = 0; i < P.length; i++) { if (m(P[i].start) <= s) si = i; } if (si < 0) si = 0; }
    var ei = si;
    for (j = si; j < P.length; j++) { if (e <= m(P[j].end)) { ei = j; break; } ei = j; }
    return { si: si, span: Math.max(1, ei - si + 1) };
  }
  var SCH_ROW_H = 58;

  /* ---------------- 课程表一级页（M5） ---------------- */
  App.Schedule = {
    node: null, _bound: false, view: 'week', monday: '', selected: '', days: [], byId: {},

    mount: function (node) {
      this.node = node;
      this.monday = Core.mondayOfWeek(Core.todayStr());
      this.selected = Core.todayStr();
      this.view = 'week';
      node.innerHTML =
        '<div class="sch-toolbar"><div class="sch-title">课程表<small id="sch-sub"></small></div>' +
        '<div class="seg" id="sch-seg"><button type="button" data-view="week" class="on">周视图</button><button type="button" data-view="day">日视图</button></div>' +
        '<button class="icon-btn" type="button" data-act="import" aria-label="导入课程">' + I('download', '', 'width:19px;height:19px') + '</button>' +
        '<button class="icon-btn" type="button" data-act="add" aria-label="添加课程">' + I('plus', '', 'width:20px;height:20px') + '</button></div>' +
        '<div class="sch-weeknav"><button type="button" data-act="prev">上一周</button>' +
        '<button class="weekrange" type="button" data-act="thisweek" id="sch-range"></button>' +
        '<button type="button" data-act="next">下一周</button></div>' +
        '<div id="sch-week-view" class="sch-pad"></div>' +
        '<div id="sch-day-view" style="display:none"></div>';
      if (!this._bound) {
        this._bound = true;
        var self = this;
        node.onclick = function (e) { self.onClick(e); };
      }
      this.refresh();
    },

    onClick: function (e) {
      var viewBtn = e.target.closest('[data-view]');
      if (viewBtn) { this.switchView(viewBtn.dataset.view); return; }
      var actEl = e.target.closest('[data-act]');
      if (actEl) {
        var a = actEl.dataset.act;
        if (a === 'prev') { this.monday = Core.addDays(this.monday, -7); this.refresh(); }
        else if (a === 'next') { this.monday = Core.addDays(this.monday, 7); this.refresh(); }
        else if (a === 'thisweek') { this.monday = Core.mondayOfWeek(Core.todayStr()); this.selected = Core.todayStr(); this.refresh(); }
        else if (a === 'add') {
          var wd = this.view === 'day' ? Core.weekdayOf(this.selected) : Core.weekdayOf(Core.todayStr());
          var dt = this.view === 'day' ? this.selected : Core.todayStr();
          App.Router.openSub(App.Subs.courseForm(null, { weekday: wd, date: dt }));
        } else if (a === 'import') { App.Router.openSub(App.Subs.courseImport()); }
        return;
      }
      var pick = e.target.closest('[data-pick]');
      if (pick) { this.selected = pick.dataset.pick; this.switchView('day'); return; }
      var cEl = e.target.closest('[data-course]');
      if (cEl) { var c = this.byId[cEl.dataset.course]; if (c) App.Router.openSub(App.Subs.courseForm(c)); }
    },

    switchView: function (v) {
      this.view = v;
      $all('#sch-seg button', this.node).forEach(function (b) { b.classList.toggle('on', b.dataset.view === v); });
      $('#sch-week-view', this.node).style.display = v === 'week' ? '' : 'none';
      $('#sch-day-view', this.node).style.display = v === 'day' ? '' : 'none';
      this.refresh();
    },

    onShow: function () { if (App.user) this.refresh(); },

    refresh: async function () {
      if (!App.user || !this.node) return;
      try {
        this.days = await App.svc.course.week(App.user.id, this.monday, App.sem);
        this.byId = {};
        this.days.forEach(function (d) { d.courses.forEach(function (c) { App.Schedule.byId[c.id] = c; }); });
        var sunday = Core.addDays(this.monday, 6);
        var wk = Core.teachingWeek(this.monday, App.sem);
        var range = $('#sch-range', this.node);
        if (range) range.innerHTML = '第 ' + wk + ' 周<small>' + this.md(this.monday) + ' - ' + this.md(sunday) + '</small>';
        var sub = $('#sch-sub', this.node);
        if (sub) sub.textContent = '共 ' + this.days.reduce(function (s, d) { return s + d.courses.length; }, 0) + ' 节';
        this.renderWeek();
        this.renderDay();
      } catch (err) { console.error('课表刷新失败', err); }
    },

    md: function (dateStr) { var d = Core.strToDate(dateStr); return (d.getMonth() + 1) + '月' + d.getDate() + '日'; },

    renderWeek: function () {
      var box = $('#sch-week-view', this.node);
      if (!box) return;
      var today = Core.todayStr(), self = this;
      var axis = '<div class="sch-axis"><div class="sch-corner"></div>' + Core.PERIODS.map(function (p) {
        return '<div class="ax-cell"><b>' + p.no + '</b><span>' + p.start + '</span></div>';
      }).join('') + '</div>';
      var cols = this.days.map(function (d, i) {
        var date = Core.strToDate(d.date);
        var isToday = d.date === today;
        var head = Core.WEEKDAY_SHORT[i] + '<b>' + (isToday ? '<span class="day-dot">' + date.getDate() + '</span>' : date.getDate()) + '</b>';
        var lines = Core.PERIODS.map(function (_, k) { return '<div class="cell-line" style="top:' + (k * SCH_ROW_H) + 'px"></div>'; }).join('');
        var blocks = d.courses.map(function (c) {
          var loc = locateCourse(c), color = courseColor(c);
          return '<div class="sch-course" data-course="' + c.id + '" style="top:' + (loc.si * SCH_ROW_H + 2) +
            'px;height:' + (loc.span * SCH_ROW_H - 4) + 'px;--c:' + color + ';background:' + hexA(color, 0.15) + '">' +
            '<span class="sc-name">' + esc(c.name) + '</span><span class="sc-loc">' + esc(c.location || '') + '</span></div>';
        }).join('');
        return '<div class="sch-col' + (isToday ? ' today' : '') + '">' +
          '<div class="sch-col-head" data-pick="' + d.date + '">' + head + '</div>' +
          '<div class="sch-col-body">' + lines + blocks + '</div></div>';
      }).join('');
      box.innerHTML = '<div class="sch-week"><div class="sch-grid">' + axis + '<div class="sch-cols">' + cols + '</div></div></div>';
    },

    renderDay: function () {
      var box = $('#sch-day-view', this.node);
      if (!box) return;
      var today = Core.todayStr(), self = this;
      var chips = this.days.map(function (d, i) {
        var date = Core.strToDate(d.date);
        return '<button class="sch-daychip' + (d.date === self.selected ? ' on' : '') + '" type="button" data-pick="' + d.date + '">' +
          Core.WEEKDAY_SHORT[i] + '<b>' + date.getDate() + '</b></button>';
      }).join('');
      var day = this.days.filter(function (d) { return d.date === self.selected; })[0];
      var body;
      if (!day) { body = ''; }
      else if (!day.courses.length) {
        body = '<div class="sch-empty">' + I('emptyBox', '', 'width:64px;height:64px') +
          '<p>' + this.md(day.date) + ' 没有安排课程</p>' +
          '<button class="btn btn-primary" type="button" data-act="add-day">添加这一天的课程</button></div>';
      } else {
        body = day.courses.map(function (c) {
          var color = courseColor(c);
          var loc = locateCourse(c);
          var periodText = loc.span > 1 ? ('第' + (loc.si + 1) + '-' + (loc.si + loc.span) + '节') : ('第' + (loc.si + 1) + '节');
          return '<div class="sch-daycard" data-course="' + c.id + '" style="--c:' + color + '">' +
            '<div class="sdc-period"><b>' + (loc.si + 1) + '</b><span>' + periodText + '</span></div>' +
            '<div class="sdc-main"><div class="sdc-name">' + esc(c.name) + '</div>' +
            '<div class="sdc-meta">' + I('clock', '', 'width:12px;height:12px;vertical-align:-1px') + ' ' + c.startTime + '-' + c.endTime +
            (c.teacher ? '　' + I('user', '', 'width:12px;height:12px;vertical-align:-1px') + ' ' + esc(c.teacher) : '') + '<br>' +
            I('location', '', 'width:12px;height:12px;vertical-align:-1px') + ' ' + esc(c.location || '未填地点') +
            '　<span style="color:' + color + ';font-weight:700">' + (Core.REPEAT_TYPES[c.repeat] ? Core.REPEAT_TYPES[c.repeat].label : '') + '</span></div>' +
            (c.note ? '<div class="sdc-note">' + esc(c.note) + '</div>' : '') + '</div></div>';
        }).join('');
      }
      box.innerHTML = '<div class="sch-daystrip">' + chips + '</div><div class="sch-day-list">' + body + '</div>';
      var addDay = $('[data-act="add-day"]', box);
      if (addDay) addDay.onclick = function () {
        App.Router.openSub(App.Subs.courseForm(null, { weekday: Core.weekdayOf(self.selected), date: self.selected }));
      };
    }
  };

  /* ---------------- 生活购物（M6） ---------------- */
  var PRODUCT_ICON_MAP = { noodles: 'bowl', soup: 'cup', drink: 'cup', juice: 'cup', tea: 'cup', spicy: 'lightning', veg: 'veg', water: 'bottle', snack: 'snack', paper: 'tissue', fruit: 'apple', print: 'printer', scan: 'scanDoc' };
  function productIcon(p) { var k = p.icon; return AppIcons.G[k] ? k : (PRODUCT_ICON_MAP[k] || 'bag'); }
  function shopIcon(s) { return AppIcons.SHOP[s.icon] || 'bag'; }
  function pad2n(n) { return (n < 10 ? '0' : '') + n; }
  function fmtTime(iso) { var d = new Date(iso); return (d.getMonth() + 1) + '月' + d.getDate() + '日 ' + pad2n(d.getHours()) + ':' + pad2n(d.getMinutes()); }
  function orderItemText(o) { return o.items.map(function (i) { return i.name + ' ×' + i.qty; }).join('、'); }
  function statusPill(status) { var st = Core.ORDER_STATUS[status]; return '<span class="status-pill ' + status + '">' + st.label + '</span>'; }

  App.Life = {
    node: null, state: { category: '全部' }, cart: { items: [], shopId: null, total: 0 },
    mount: function (node) {
      this.node = node;
      node.innerHTML =
        '<div class="life-pad">' +
        '<div class="life-head"><h2>校园生活</h2>' +
        '<button class="orders-entry" type="button" data-act="orders">' + I('order', '', 'width:16px;height:16px') + '我的订单<span class="od-badge" id="life-od-badge" style="display:none">0</span></button></div>' +
        '<div class="cat-bar" id="life-cats"></div>' +
        '<div id="life-cartmini"></div>' +
        '<div id="life-shops"></div></div>';
      if (!this._bound) { this._bound = true; var self = this; node.onclick = function (e) { self.onClick(e); }; }
      this.renderCats(); this.refresh();
    },
    renderCats: function () {
      var cur = this.state.category;
      var cats = ['全部'].concat(Core.SHOP_CATEGORIES);
      $('#life-cats', this.node).innerHTML = cats.map(function (c) {
        return '<button class="cat-chip' + (c === cur ? ' on' : '') + '" type="button" data-cat="' + c + '">' + c + '</button>';
      }).join('');
    },
    onClick: function (e) {
      var cat = e.target.closest('[data-cat]');
      if (cat) { this.state.category = cat.dataset.cat; this.renderCats(); this.renderShops(); return; }
      if (e.target.closest('[data-act="orders"]')) { App.Router.openSub(App.Subs.ordersList()); return; }
      var cm = e.target.closest('[data-act="cartmini"]');
      if (cm) { if (cm.dataset.shop) App.Router.openSub(App.Subs.cartCheckout(cm.dataset.shop)); return; }
      var sc = e.target.closest('[data-shop]');
      if (sc) { App.Router.openSub(App.Subs.shopDetail(sc.dataset.shop)); }
    },
    onShow: function () { if (App.user) this.refresh(); },
    refresh: async function () {
      if (!App.user || !this.node) return;
      try {
        var res = await Promise.all([
          App.svc.shop.list(), App.svc.cart.summary(App.user.id), App.svc.order.pendingCount(App.user.id)
        ]);
        this.state.shops = res[0]; this.cart = res[1];
        this.renderShops(); this.renderCartMini();
        var badge = $('#life-od-badge', this.node);
        if (badge) { badge.textContent = res[2]; badge.style.display = res[2] ? '' : 'none'; }
      } catch (err) { console.error('生活页刷新失败', err); }
    },
    renderShops: function () {
      var cat = this.state.category, box = $('#life-shops', this.node); if (!box) return;
      var list = (this.state.shops || []).filter(function (s) { return cat === '全部' || s.category === cat; });
      if (!list.length) { box.innerHTML = '<div class="life-empty"><p>该分类下暂无商家</p></div>'; return; }
      box.innerHTML = list.map(function (s) {
        var min = s.minOrder > 0 ? ('¥' + Core.formatMoney(s.minOrder) + ' 起送') : '无起送门槛';
        return '<div class="shop-card" data-shop="' + s.id + '">' +
          '<div class="shop-logo">' + AppIcons.circleIcon(shopIcon(s), s.color, 50) + '</div>' +
          '<div class="shop-info"><div class="shop-name">' + esc(s.name) + '<span class="shop-cat">' + s.category + '</span></div>' +
          '<div class="shop-meta">' + esc(s.deliveryDesc) + '<span class="dot">·</span>' + min + '</div>' +
          (s.notice ? '<div class="shop-notice">' + I('horn', '', 'width:12px;height:12px;vertical-align:-1px') + ' ' + esc(s.notice) + '</div>' : '') +
          '</div></div>';
      }).join('');
    },
    renderCartMini: function () {
      var box = $('#life-cartmini', this.node); if (!box) return; var c = this.cart;
      if (!c.items.length) { box.innerHTML = ''; return; }
      var qty = c.items.reduce(function (s, i) { return s + i.qty; }, 0);
      box.innerHTML = '<div class="cart-mini" data-act="cartmini" data-shop="' + c.shopId + '">' +
        '<div class="cm-ico">' + I('bag', '', 'width:21px;height:21px') + '<span class="cm-badge">' + qty + '</span></div>' +
        '<div class="cm-main"><div class="cm-shop">购物车 · ' + qty + ' 件</div><div class="cm-total">¥' + Core.formatMoney(c.total) + '</div></div>' +
        '<span class="cm-go">去结算</span></div>';
    }
  };

  /* ================= 学生论坛广场（M7） ================= */
  App.Forum = {
    node: null,
    mount: function (node) {
      this.node = node;
      var n = el('div');
      n.innerHTML =
        '<div class="forum-head"><h2>学生论坛</h2>' +
        '<div style="display:flex;gap:8px">' +
        '<button class="btn btn-outline" id="forum-mine" style="border-radius:20px;padding:8px 13px;font-size:12.5px">' + I('user', '', 'width:14px;height:14px;vertical-align:-2px') + ' 我的</button>' +
        '<button class="forum-new-btn" id="forum-new">' + I('plus', '', 'width:15px;height:15px') + '发起话题</button>' +
        '</div></div><div id="forum-list"><div class="forum-pad">加载中…</div></div>';
      node.innerHTML = '';
      node.appendChild(n);
      n.onclick = function (e) {
        if (e.target.closest('#forum-new')) { App.Router.openSub(App.Subs.topicCreate()); return; }
        if (e.target.closest('#forum-mine')) { App.Router.openSub(App.Subs.myForum('topics')); return; }
        var empty = e.target.closest('#forum-empty-new');
        if (empty) { App.Router.openSub(App.Subs.topicCreate()); return; }
        var card = e.target.closest('[data-topic]');
        if (card) App.Router.openSub(App.Subs.topicDetail(card.dataset.topic));
      };
      this.refresh();
    },
    refresh: async function () {
      var box = this.node ? $('#forum-list', this.node) : null;
      if (!box) return;
      var topics = await App.svc.forum.topics();
      if (!topics.length) {
        box.innerHTML = '<div class="forum-pad"><div class="life-empty">' + I('chat', '', 'width:64px;height:64px') +
          '<p>还没有话题<br>来发布第一个话题吧</p>' +
          '<button class="btn btn-primary" type="button" id="forum-empty-new">发起话题</button></div></div>';
        return;
      }
      box.innerHTML = topics.map(function (t) {
        return '<div class="topic-card" data-topic="' + t.id + '">' +
          '<div class="tc-author"><img class="av" src="' + t.authorAvatar + '" alt=""><span class="tc-name">' + esc(t.authorName) + '</span>' +
          '<span class="tc-time">' + forumTime(t.updatedAt || t.createdAt) + '</span></div>' +
          '<div class="tc-title">' + esc(t.title) + '</div>' +
          '<div class="tc-excerpt">' + esc(t.content) + '</div>' +
          '<div class="tc-foot"><span class="tc-cmt">' + I('chat', '', 'width:15px;height:15px') + ' ' + t.replyCount + ' 条评论</span></div></div>';
      }).join('');
    },
    onShow: function () { this.refresh(); }
  };

  /* ---------------- 我的（M2 完整版） ---------------- */
  App.Pages = {
    home: {
      mount: function (node) { App.Home.mount(node); },
      onShow: function () { App.Home.onShow(); }
    },
    schedule: {
      mount: function (node) { App.Schedule.mount(node); },
      onShow: function () { App.Schedule.onShow(); }
    },
    life: {
      mount: function (node) { App.Life.mount(node); },
      onShow: function () { App.Life.onShow(); }
    },
    forum: {
      mount: function (node) { App.Forum.mount(node); },
      onShow: function () { App.Forum.onShow(); }
    },

    profile: {
      mount: function (node) {
        node.classList.add('page-pad');
        node.innerHTML =
          '<div class="profile-head" id="pf-head"></div>' +
          '<div class="menu-group-label">我的内容</div>' +
          '<div class="card menu-card" id="pf-menu"></div>' +
          '<div class="menu-group-label">数据与安全</div>' +
          '<div class="card menu-card" id="pf-menu-data"></div>' +
          '<button class="btn btn-outline btn-block" id="pf-logout" style="margin-top:20px;color:var(--red);border-color:#ecc4c2">退出登录</button>' +
          '<p class="muted small" style="text-align:center;margin-top:14px;line-height:1.7">完美诚毅 第一版 · 数据保存在本机浏览器<br>清除浏览器站点数据前，请先在「数据管理」导出备份</p>';
        $('#pf-logout', node).onclick = async function () {
          var ok = await App.UI.modal({ title: '退出登录', body: '退出后需要重新登录才能查看你的课程、备忘和订单，数据不会丢失。', confirmText: '退出', danger: true });
          if (!ok) return;
          await App.svc.auth.logout();
          App.user = null;
          App.Router.stack = []; $('#subview-layer').innerHTML = '';
          App.bus.emit('auth:changed', null);
          Gate.show();
        };
        node.onclick = function (e) {
          var row = e.target.closest('[data-act]'); if (!row) return;
          var act = row.dataset.act;
          if (act === 'edit') App.Router.openSub(App.Subs.profileEdit());
          if (act === 'orders') App.Router.openSub(App.Subs.ordersList());
          if (act === 'mytopics') App.Router.openSub(App.Subs.myForum('topics'));
          if (act === 'myreplies') App.Router.openSub(App.Subs.myForum('replies'));
          if (act === 'data') App.Router.openSub(App.Subs.dataManager());
          if (act === 'about') App.UI.alert({ title: '关于完美诚毅', body: '一款仅在本机浏览器运行的校园生活演示应用：课程表、备忘、模拟购物与校园论坛数据均保存在本机，不连接学校、商家或支付平台。' });
        };
      },
      onShow: async function () {
        if (!App.user) return;
        var u = await App.svc.auth.current();
        if (u) App.user = u;
        var balance = await App.svc.settings.balance();
        var head = $('#pf-head');
        if (head) head.innerHTML =
          '<div class="pf-top">' + avatarHtml(App.user.avatar, 'pf-avatar') +
          '<div class="pf-info"><div class="pf-name">' + esc(App.user.nickname) + '</div>' +
          '<div class="pf-sign">' + esc(App.user.signature || '这位同学很懒，还没有签名') + '</div></div>' +
          '<button class="pf-edit-btn" data-act="edit">' + I('edit') + '<span>编辑</span></button></div>' +
          '<div class="pf-school">' + I('location', '', 'width:14px;height:14px') +
          '<span class="ellipsis">' + esc(App.user.school) + (App.user.studentNo ? ' · ' + esc(App.user.studentNo) : '') + '</span></div>' +
          '<div class="pf-balance">' + I('wallet', '', 'width:18px;height:18px;color:#d9a441') +
          '<span>校园卡余额（模拟）</span><b>¥ ' + Core.formatMoney(balance) + '</b></div>';
        var menu = $('#pf-menu');
        if (menu) menu.innerHTML =
          App.menuRow('edit', 'user', '编辑资料', '头像、昵称、签名与学号') +
          App.menuRow('orders', 'order', '我的订单', '查看模拟下单与取餐状态') +
          App.menuRow('mytopics', 'pen', '我的话题', '我发布的话题') +
          App.menuRow('myreplies', 'chat', '我的评论', '我发表过的评论');
        var menuData = $('#pf-menu-data');
        if (menuData) menuData.innerHTML =
          App.menuRow('data', 'settings', '数据管理', '备份、恢复、快照与开学日期') +
          App.menuRow('about', 'shield', '关于与数据说明', '本地演示，不联网');
      }
    },

    mountAll: function () {
      var self = this;
      TABS.forEach(function (t) {
        var node = $('#view-' + t);
        if (node && self[t].mount) self[t].mount(node);
      });
    }
  };

  App.menuRow = function (act, icon, title, sub) {
    return '<div class="list-row menu-row" data-act="' + act + '">' +
      '<span class="menu-icon">' + I(icon, '', 'width:20px;height:20px') + '</span>' +
      '<div class="grow"><div>' + esc(title) + '</div><div class="muted small ellipsis">' + esc(sub) + '</div></div>' +
      '<span class="chev">' + I('chevronRight', '', 'width:18px;height:18px') + '</span></div>';
  };

  /* ---------------- 二级视图：资料编辑 ---------------- */
  App.Subs = {
    profileEdit: function () {
      var draft, initial, avatarChanged = false, fileInput;
      return {
        title: '编辑资料',
        mount: function (body) {
          var u = App.user;
          draft = { nickname: u.nickname, signature: u.signature || '', studentNo: u.studentNo || '', school: u.school || Core.SCHOOL_NAME };
          initial = JSON.stringify(draft) + '|' + (avatarChanged ? 'x' : 'o');
          body.classList.add('subview-pad');
          body.innerHTML =
            '<div class="avatar-edit">' +
            '<div class="avatar-edit-img" id="av-img">' + avatarHtml(u.avatar, 'pf-avatar') + '</div>' +
            '<button class="btn btn-ghost btn-sm" id="av-change" type="button">' + I('camera', '', 'width:15px;height:15px') + ' 更换头像</button>' +
            '<button class="btn btn-sm" type="button" id="av-reset" style="color:var(--ink-sub)">恢复默认头像</button>' +
            '<input type="file" id="av-file" accept="image/*" style="display:none"></div>' +
            '<form id="pf-form">' +
            '<div class="field" data-k="nickname"><label>昵称</label><input type="text" name="nickname" maxlength="12" value="' + esc(draft.nickname) + '"><div class="err"></div></div>' +
            '<div class="field" data-k="signature"><label>个性签名</label><input type="text" name="signature" maxlength="30" placeholder="写一句话介绍自己" value="' + esc(draft.signature) + '"><div class="err"></div></div>' +
            '<div class="field" data-k="studentNo"><label>学号</label><input type="text" name="studentNo" maxlength="20" value="' + esc(draft.studentNo) + '"><div class="err"></div></div>' +
            '<div class="field" data-k="school"><label>学校</label><input type="text" name="school" maxlength="30" value="' + esc(draft.school) + '"><div class="err"></div></div>' +
            '<button type="submit" class="btn btn-primary btn-block">保存</button></form>';

          fileInput = $('#av-file', body);
          $('#av-change', body).onclick = function () { fileInput.click(); };
          fileInput.onchange = async function () {
            var file = fileInput.files[0]; if (!file) return;
            try {
              var dataUrl = await App.fileToAvatar(file);
              draft.avatar = dataUrl; avatarChanged = true;
              $('#av-img', body).innerHTML = avatarHtml(dataUrl, 'pf-avatar');
              App.UI.toast('头像已更新，保存后生效');
            } catch (e) { App.UI.toast(e.message); }
            fileInput.value = '';
          };
          $('#av-reset', body).onclick = async function () {
            draft.avatar = DB.defaultAvatar(u.avatarColor || '#4d8df7');
            avatarChanged = true;
            $('#av-img', body).innerHTML = avatarHtml(draft.avatar, 'pf-avatar');
          };
          $('#pf-form', body).onsubmit = async function (e) {
            e.preventDefault();
            var fd = new FormData(this);
            draft.nickname = fd.get('nickname'); draft.signature = fd.get('signature');
            draft.studentNo = fd.get('studentNo'); draft.school = fd.get('school');
            try {
              var btn = this.querySelector('button[type=submit]'); btn.disabled = true;
              var updated = await App.svc.auth.updateProfile(u.id, draft);
              if (avatarChanged) updated = await App.svc.auth.updateAvatar(u.id, draft.avatar);
              App.user = updated;
              App.bus.emit('profile:changed', updated);
              App.UI.toast('资料已保存');
              App.Router.clearGuard();
              App.Router.back();
            } catch (err) {
              btn.disabled = false;
              App.UI.toast(err.message || '保存失败');
            }
          };
        },
        guard: function () {
          var form = $('#pf-form');
          var text = form ? JSON.stringify({
            nickname: form.nickname.value, signature: form.signature.value,
            studentNo: form.studentNo.value, school: form.school.value
          }) + '|' + (avatarChanged ? 'x' : 'o') : initial;
          return text !== initial ? '资料还没有保存，确定离开吗？' : null;
        }
      };
    },

    /* 全部备忘（M3 基础版：分区 / 新增 / 勾选 / 删除；M4 补编辑） */
    memoList: function () {
      function row(m) {
        return '<div class="memo-item' + (m.done ? ' done' : '') + '">' +
          '<button class="memo-check" type="button" data-act="toggle" data-mid="' + m.id + '" aria-label="切换完成">' + I('check', '', 'width:12px;height:12px') + '</button>' +
          '<span class="memo-text">' + esc(m.content) + '</span>' +
          '<button class="memo-del" type="button" data-act="edit" data-mid="' + m.id + '" aria-label="编辑">' + I('edit', '', 'width:14px;height:14px') + '</button>' +
          '<button class="memo-del" type="button" data-act="del" data-mid="' + m.id + '" aria-label="删除">' + I('trash', '', 'width:15px;height:15px') + '</button></div>';
      }
      return {
        title: '全部备忘',
        mount: function (body) {
          body.innerHTML =
            '<div class="subview-pad">' +
            '<div style="display:flex;gap:8px;margin-bottom:14px">' +
            '<input id="ml-input" type="text" maxlength="100" placeholder="添加一条备忘…" style="flex:1;height:40px;border:1px solid var(--line);border-radius:20px;padding:0 16px;font-size:14px;background:#fbfaf8;outline:none">' +
            '<button id="ml-add" class="btn btn-primary" style="height:40px;border-radius:20px;padding:0 20px">添加</button></div>' +
            '<div class="apps-group-title" id="ml-open-title" style="display:none;margin-top:2px">待办</div>' +
            '<div id="ml-open"></div>' +
            '<div class="apps-group-title" id="ml-done-title" style="display:none">已完成</div>' +
            '<div id="ml-done"></div></div>';
          var byId = {};
          var load = async function () {
            var all = await App.svc.memo.list(App.user.id);
            byId = {};
            all.forEach(function (m) { byId[m.id] = m; });
            var open = all.filter(function (m) { return !m.done; });
            var done = all.filter(function (m) { return m.done; });
            $('#ml-open-title', body).textContent = '待办（' + open.length + '）';
            $('#ml-open-title', body).style.display = '';
            $('#ml-open', body).innerHTML = open.length ? open.map(row).join('') :
              '<div class="memo-empty">' + I('emptyBox', '', 'width:52px;height:52px') + '<p>暂无待办备忘，在上方添加一条</p></div>';
            $('#ml-done-title', body).textContent = '已完成（' + done.length + '）';
            $('#ml-done-title', body).style.display = done.length ? '' : 'none';
            $('#ml-done', body).innerHTML = done.map(row).join('');
            App.bus.emit('memo:changed');
          };
          var add = async function () {
            var inp = $('#ml-input', body), txt = inp.value;
            if (!txt.trim()) { App.UI.toast('备忘内容不能为空'); return; }
            await App.svc.memo.add(App.user.id, txt);
            inp.value = ''; App.UI.toast('已添加'); load();
          };
          var edit = function (mid) {
            var m = byId[mid];
            if (!m) return;
            var wrap = el('div');
            wrap.innerHTML = '<textarea id="me-input" rows="3" maxlength="100" style="width:100%;border:1px solid var(--line);background:#fbfaf8;border-radius:12px;padding:10px;font-size:14px;resize:none;outline:none"></textarea>';
            $('#me-input', wrap).value = m.content;
            App.UI.modal({ title: '编辑备忘', body: wrap, confirmText: '保存', cancelText: '取消' }).then(async function (ok) {
              if (!ok) return;
              var txt = $('#me-input', wrap).value;
              if (!txt.trim()) { App.UI.toast('备忘内容不能为空'); return; }
              await App.svc.memo.update(mid, App.user.id, txt);
              App.UI.toast('已保存修改'); load();
            });
          };
          $('#ml-add', body).onclick = add;
          $('#ml-input', body).addEventListener('keydown', function (ev) { if (ev.key === 'Enter') add(); });
          body.onclick = async function (e) {
            var b = e.target.closest('[data-act]'); if (!b) return;
            var mid = b.dataset.mid;
            if (b.dataset.act === 'toggle') { await App.svc.memo.toggle(mid, App.user.id); load(); }
            else if (b.dataset.act === 'edit') { edit(mid); }
            else if (b.dataset.act === 'del') {
              var ok = await App.UI.modal({ title: '删除备忘', body: '确定删除这条备忘吗？此操作不可撤销。', confirmText: '删除', danger: true });
              if (ok) { await App.svc.memo.remove(mid, App.user.id); App.UI.toast('已删除'); load(); }
            }
          };
          load();
        }
      };
    },

    /* 全部应用面板 */
    appsPanel: function () {
      var EXTRA = [
        { icon: 'box', label: '快递查询', color: '#ff8a3d' },
        { icon: 'tshirt', label: '自助洗衣', color: '#4d8df7' },
        { icon: 'clock', label: '校车时刻', color: '#46bf82' },
        { icon: 'book', label: '图书馆', color: '#9b7ff5' }
      ];
      return {
        title: '全部应用',
        mount: function (body) {
          var common = Icons.SERVICE.map(function (s) {
            return '<button class="serv-item" type="button" data-srv="' + s.key + '">' + Icons.circleIcon(s.icon, s.color, 44) + '<span>' + s.label + '</span></button>';
          }).join('');
          var extra = EXTRA.map(function (s) {
            return '<button class="serv-item" type="button" data-demo="' + s.label + '">' + Icons.circleIcon(s.icon, s.color, 44) + '<span>' + s.label + '</span></button>';
          }).join('');
          body.innerHTML = '<div class="subview-pad">' +
            '<div class="apps-group-title" style="margin-top:4px">常用服务</div><div class="apps-grid">' + common + '</div>' +
            '<div class="apps-group-title">生活便民（本地演示）</div><div class="apps-grid">' + extra + '</div></div>';
          body.onclick = function (e) {
            var srv = e.target.closest('[data-srv]');
            if (srv) { App.Home.runService(srv.dataset.srv); return; }
            var demo = e.target.closest('[data-demo]');
            if (demo) App.demo(demo.dataset.demo);
          };
        }
      };
    },

    /* 课程表单（新增 / 编辑，M5） */
    courseForm: function (course, preset) {
      var editing = !!course;
      preset = preset || {};
      var P = Core.PERIODS, today = Core.todayStr();
      var defMonday = Core.mondayOfWeek(preset.date || today);
      var state = course ? {
        wd: Number(course.weekday), rp: course.repeat, color: course.color
      } : { wd: preset.weekday || Core.weekdayOf(today), rp: 'weekly', color: 'blue' };
      var anchor = null;
      function field(key, label, req, inputHtml) {
        return '<div class="fld"><label>' + label + (req ? '<span class="req"> *</span>' : '') + '</label>' + inputHtml +
          '<div class="err" id="cf-err-' + key + '"></div></div>';
      }
      function chipGroup(keys, labels, cur, attr) {
        return '<div class="chip-row">' + keys.map(function (k, i) {
          return '<button type="button" class="chip' + (cur === k ? ' on' : '') + '" data-' + attr + '="' + k + '">' + labels[i] + '</button>';
        }).join('') + '</div>';
      }
      return {
        title: editing ? '编辑课程' : '添加课程',
        mount: function (body) {
          var self = this;
          var rpKeys = ['weekly', 'odd', 'even', 'once'], rpLabels = ['每周', '单周', '双周', '仅一次'];
          var periods = P.map(function (p, i) {
            return '<button type="button" class="period-chip" data-period="' + i + '">第' + p.no + '节<span>' + p.start + '-' + p.end + '</span></button>';
          }).join('');
          var colors = Core.COURSE_COLORS.map(function (c) {
            return '<button type="button" class="color-dot' + (state.color === c.key ? ' on' : '') + '" data-color="' + c.key + '" style="background:' + c.value + '">' +
              (state.color === c.key ? I('check', '', 'width:15px;height:15px') : '') + '</button>';
          }).join('');
          body.innerHTML = '<div class="subview-pad">' +
            field('name', '课程名称', true, '<input type="text" id="cf-name" maxlength="30" placeholder="如：高等数学">') +
            field('teacher', '任课教师（选填）', false, '<input type="text" id="cf-teacher" maxlength="20" placeholder="如：张老师">') +
            field('location', '上课地点', true, '<input type="text" id="cf-location" maxlength="30" placeholder="如：景祺楼 A301">') +
            '<div class="fld"><label>星期<span class="req"> *</span></label><div id="cf-wd-row">' + chipGroup([1, 2, 3, 4, 5, 6, 7], Core.WEEKDAY_SHORT, state.wd, 'wd') + '</div><div class="err" id="cf-err-wd"></div></div>' +
            '<div class="fld"><label>节次（点选，可跨节连堂）</label><div class="period-grid" id="cf-periods">' + periods + '</div></div>' +
            '<div class="time-row"><div class="fld"><label>开始时间<span class="req"> *</span></label><input type="time" id="cf-start"><div class="err" id="cf-err-start"></div></div>' +
            '<div class="fld"><label>结束时间<span class="req"> *</span></label><input type="time" id="cf-end"><div class="err" id="cf-err-end"></div></div></div>' +
            '<div class="fld" style="margin-top:16px"><label>重复规则</label><div id="cf-rp-row">' + chipGroup(rpKeys, rpLabels, state.rp, 'rp') + '</div></div>' +
            '<div class="time-row" style="margin-top:16px"><div class="fld"><label>开始日期<span class="req"> *</span></label><input type="date" id="cf-sdate"><div class="err" id="cf-err-sdate"></div></div>' +
            '<div class="fld" id="cf-edate-wrap"><label>结束日期<span class="req"> *</span></label><input type="date" id="cf-edate"><div class="err" id="cf-err-edate"></div></div></div>' +
            '<div class="fld" style="margin-top:16px"><label>课程颜色</label><div class="color-row" id="cf-colors">' + colors + '</div></div>' +
            field('note', '备注', false, '<textarea id="cf-note" rows="2" maxlength="200" placeholder="选填，如作业、教材、注意事项"></textarea>') +
            '<div class="cf-conflict" id="cf-conflict"></div>' +
            '<button class="btn btn-primary btn-block cf-save" id="cf-save" type="button">' + (editing ? '保存修改' : '添加课程') + '</button>' +
            (editing ? '<button class="cf-delete" id="cf-delete" type="button">' + I('trash', '', 'width:17px;height:17px') + '删除该课程</button>' : '') +
            '</div>';

          $('#cf-name', body).value = course ? course.name : '';
          $('#cf-teacher', body).value = course ? (course.teacher || '') : '';
          $('#cf-location', body).value = course ? course.location : '';
          $('#cf-start', body).value = course ? course.startTime : P[0].start;
          $('#cf-end', body).value = course ? course.endTime : P[0].end;
          $('#cf-sdate', body).value = course ? course.startDate : (preset.date || defMonday);
          $('#cf-edate', body).value = course ? (course.endDate || course.startDate) : Core.addDays(defMonday, 17 * 7 + 6);
          $('#cf-note', body).value = course ? (course.note || '') : '';

          function collect() {
            var rp = state.rp;
            return {
              id: editing ? course.id : undefined,
              name: Core.trim($('#cf-name', body).value),
              teacher: Core.trim($('#cf-teacher', body).value),
              location: Core.trim($('#cf-location', body).value),
              weekday: state.wd,
              startTime: $('#cf-start', body).value, endTime: $('#cf-end', body).value,
              repeat: rp, startDate: $('#cf-sdate', body).value,
              endDate: rp === 'once' ? $('#cf-sdate', body).value : $('#cf-edate', body).value,
              color: state.color, note: Core.trim($('#cf-note', body).value)
            };
          }
          var ERRMAP = { name: 'name', location: 'location', weekday: 'wd', startTime: 'start', endTime: 'end', startDate: 'sdate', endDate: 'edate' };
          function clearErrors() {
            Object.keys(ERRMAP).forEach(function (k) {
              var ui = ERRMAP[k], f = $('#cf-err-' + ui, body), inp = $('#cf-' + ui, body);
              if (f) { f.style.display = 'none'; f.textContent = ''; }
              if (inp) inp.classList.remove('invalid');
            });
          }
          function showErrors(errors) {
            Object.keys(ERRMAP).forEach(function (k) {
              var ui = ERRMAP[k], msg = errors[k] || '', f = $('#cf-err-' + ui, body), inp = $('#cf-' + ui, body);
              if (f) { f.style.display = msg ? '' : 'none'; f.textContent = msg; }
              if (inp) inp.classList.toggle('invalid', !!msg);
            });
          }
          function toggleEdate() { $('#cf-edate-wrap', body).style.display = state.rp === 'once' ? 'none' : ''; }
          function highlightPeriods() {
            var s = Core.hmToMinutes($('#cf-start', body).value), e = Core.hmToMinutes($('#cf-end', body).value);
            $all('#cf-periods .period-chip', body).forEach(function (chip, i) {
              var p = P[i], on = !isNaN(s) && !isNaN(e) && Core.hmToMinutes(p.start) < e && s < Core.hmToMinutes(p.end);
              chip.classList.toggle('on', on);
            });
          }
          async function checkConflict() {
            var box = $('#cf-conflict', body), data = collect(), chk = Core.validateCourseInput(data);
            var canCheck = !chk.errors.weekday && !chk.errors.startTime && !chk.errors.endTime && !chk.errors.startDate &&
              (data.repeat === 'once' || !chk.errors.endDate);
            if (!canCheck) { box.style.display = 'none'; return; }
            var cf = await App.svc.course.conflicts(App.user.id, data, App.sem);
            if (cf.length) {
              box.style.display = '';
              box.innerHTML = '与 ' + cf.length + ' 门课时间重叠：' +
                cf.map(function (c) { return c.name + '（' + Core.WEEKDAY_SHORT[c.weekday - 1] + ' ' + c.startTime + '-' + c.endTime + '）'; }).join('、') +
                '。仍可保存，请确认是否为连堂或误排。';
            } else box.style.display = 'none';
          }
          toggleEdate(); highlightPeriods();

          body.onclick = async function (e) {
            var wd = e.target.closest('[data-wd]');
            if (wd) { state.wd = Number(wd.dataset.wd); syncChips('#cf-wd-row', 'wd', state.wd); checkConflict(); return; }
            var rp = e.target.closest('[data-rp]');
            if (rp) { state.rp = rp.dataset.rp; syncChips('#cf-rp-row', 'rp', state.rp); toggleEdate(); checkConflict(); return; }
            var cl = e.target.closest('[data-color]');
            if (cl) {
              state.color = cl.dataset.color;
              $all('#cf-colors .color-dot', body).forEach(function (d) {
                var on = d.dataset.color === state.color;
                d.classList.toggle('on', on); d.innerHTML = on ? I('check', '', 'width:15px;height:15px') : '';
              });
              return;
            }
            var pp = e.target.closest('[data-period]');
            if (pp) {
              var i = Number(pp.dataset.period);
              if (anchor === null) { anchor = i; applyPeriod(i, i); }
              else { var a = Math.min(anchor, i), b = Math.max(anchor, i); applyPeriod(a, b); anchor = null; }
              return;
            }
            var save = e.target.closest('#cf-save');
            if (save) { await doSave(); return; }
            var del = e.target.closest('#cf-delete');
            if (del) { await doDelete(); };
          };
          function syncChips(sel, attr, val) {
            $all(sel + ' .chip', body).forEach(function (c) { c.classList.toggle('on', String(c.dataset[attr]) === String(val)); });
          }
          function applyPeriod(a, b) {
            $('#cf-start', body).value = P[a].start; $('#cf-end', body).value = P[b].end;
            highlightPeriods(); checkConflict();
          }
          ['#cf-start', '#cf-end', '#cf-sdate', '#cf-edate'].forEach(function (s) {
            $(s, body).addEventListener('change', function () { highlightPeriods(); checkConflict(); });
          });

          async function doSave() {
            clearErrors();
            var data = collect(), chk = Core.validateCourseInput(data);
            if (!chk.ok) { showErrors(chk.errors); App.UI.toast('请检查标红的内容'); return; }
            var cf = await App.svc.course.conflicts(App.user.id, data, App.sem);
            if (cf.length) {
              var names = cf.map(function (c) { return c.name + '（' + Core.WEEKDAY_SHORT[c.weekday - 1] + ' ' + c.startTime + '）'; }).join('、');
              var go = await App.UI.modal({ title: '时间冲突提示', body: '该课程与以下课程时间重叠：' + names + '。系统不会自动阻止排课，确认仍要保存吗？', confirmText: '仍要保存', cancelText: '再想想' });
              if (!go) return;
            }
            if (editing) await App.svc.course.update(course.id, App.user.id, data);
            else await App.svc.course.add(App.user.id, data);
            App.UI.toast(editing ? '已保存修改' : '已添加课程');
            App.bus.emit('course:changed');
            App.Schedule.refresh(); App.Home.refresh();
            App.Router.clearGuard(); App.Router.back();
          }
          async function doDelete() {
            var ok = await App.UI.modal({ title: '删除课程', body: '确定删除「' + course.name + '」吗？删除后课程表与首页都不再显示。', confirmText: '删除', danger: true });
            if (!ok) return;
            await App.svc.course.remove(course.id, App.user.id);
            App.UI.toast('已删除课程');
            App.bus.emit('course:changed');
            App.Schedule.refresh(); App.Home.refresh();
            App.Router.clearGuard(); App.Router.back();
          }

          App.Router.setGuard(function () {
            return JSON.stringify(collect()) !== initial ? '课程还没有保存，确定离开吗？' : null;
          });
          var initial = JSON.stringify(collect());
        }
      };
    },

    /* 课程 Excel 导入向导（M5） */
    courseImport: function () {
      var HEAD = ['课程名称', '任课教师', '上课地点', '星期(1-7,1=周一)', '开始时间', '结束时间', '开始日期', '结束日期', '重复规则', '颜色', '备注'];
      var SAMPLE = [
        ['高等数学', '张老师', '景祺楼A301', 1, '08:00', '09:40', '2026-09-07', '2026-12-28', '每周', '蓝', ''],
        ['大学英语', '李老师', '教学楼B202', 3, '10:00', '11:40', '2026-09-07', '2026-12-28', '每周', '绿', '']
      ];
      return {
        title: '导入课程',
        mount: function (body) {
          body.innerHTML = '<div class="subview-pad">' +
            '<div class="ie-hint">使用模板批量排课：先下载模板、按表头填写，再选择文件导入。导入前会逐行校验并预览，时间冲突的课程会标黄但不会被阻止。</div>' +
            '<div class="ie-actions">' +
            '<button class="ie-btn outline" type="button" id="ie-tpl">' + I('download', '', 'width:18px;height:18px') + '下载课程导入模板</button>' +
            '<button class="ie-btn primary" type="button" id="ie-pick">' + I('scanDoc', '', 'width:18px;height:18px') + '选择 Excel 文件</button>' +
            '<input type="file" id="ie-file" accept=".xlsx,.xls" style="display:none">' +
            '</div><div id="ie-preview"></div></div>';

          $('#ie-tpl', body).onclick = function () {
            if (typeof XLSX === 'undefined') { App.UI.toast('表格组件未加载'); return; }
            var ws = XLSX.utils.aoa_to_sheet([HEAD].concat(SAMPLE));
            ws['!cols'] = [{ wch: 14 }, { wch: 10 }, { wch: 16 }, { wch: 18 }, { wch: 9 }, { wch: 9 }, { wch: 12 }, { wch: 12 }, { wch: 9 }, { wch: 6 }, { wch: 16 }];
            var wb = XLSX.utils.book_new();
            XLSX.utils.book_append_sheet(wb, ws, '课程导入');
            XLSX.writeFile(wb, '课程导入模板.xlsx');
            App.UI.toast('模板已下载，含两行示例可修改或删除');
          };
          $('#ie-pick', body).onclick = function () { $('#ie-file', body).click(); };
          $('#ie-file', body).addEventListener('change', function (e) {
            var f = e.target.files && e.target.files[0];
            if (f) readFile(f);
          });

          async function readFile(f) {
            var preview = $('#ie-preview', body);
            try {
              var buf = await f.arrayBuffer();
              if (typeof XLSX === 'undefined') throw new Error('表格组件未加载');
              var wb = XLSX.read(buf, { type: 'array' });
              var ws = wb.Sheets[wb.SheetNames[0]];
              var raw = XLSX.utils.sheet_to_json(ws, { defval: '' });
              if (!raw.length) { preview.innerHTML = '<div class="ie-hint">没有读到任何数据行，请确认按模板表头填写。</div>'; return; }
              var parsed = Core.parseImportRows(raw);
              var existing = await App.svc.course.list(App.user.id);
              renderPreview(parsed, existing);
            } catch (err) {
              preview.innerHTML = '<div class="ie-hint" style="color:var(--red);background:#fdeeec">文件解析失败：' + esc(err.message || '无法识别，请使用模板格式') + '</div>';
            }
          }

          function renderPreview(parsed, existing) {
            var selected = {};
            parsed.forEach(function (r) { if (r.ok) selected[r.index] = { on: true, warn: Core.findConflicts(r.value, existing, App.sem) }; });
            function draw() {
              var rows = parsed.map(function (r) {
                if (!r.ok) {
                  return '<tr class="row-err"><td></td><td>' + r.index + '</td><td colspan="6" class="ie-err">无法导入：' + esc(r.errors.join('；')) + '</td></tr>';
                }
                var v = r.value, warn = selected[r.index] ? selected[r.index].warn : [];
                var cls = warn.length ? 'row-warn' : '';
                var cb = '<input type="checkbox" data-row="' + r.index + '"' + (selected[r.index] && selected[r.index].on ? ' checked' : '') + '>';
                var status = warn.length ? '<span class="ie-warn">与「' + esc(warn.map(function (c) { return c.name; }).join('、')) + '」时间重叠</span>' : '<span style="color:var(--green)">可导入</span>';
                return '<tr class="' + cls + '"><td>' + cb + '</td><td>' + r.index + '</td><td>' + esc(v.name) + '</td><td>' +
                  Core.WEEKDAY_SHORT[v.weekday - 1] + '</td><td>' + v.startTime + '-' + v.endTime + '</td><td>' + esc(v.location) + '</td><td>' +
                  (Core.REPEAT_TYPES[v.repeat] ? Core.REPEAT_TYPES[v.repeat].label : '') + '</td><td>' + status + '</td></tr>';
              }).join('');
              var okN = parsed.filter(function (r) { return r.ok; }).length;
              var errN = parsed.length - okN;
              var chosen = Object.keys(selected).filter(function (k) { return selected[k].on; }).length;
              $('#ie-preview', body).innerHTML =
                '<div class="ie-summary">共 ' + parsed.length + ' 行：可导入 ' + okN + ' 行' + (errN ? '，格式错误 ' + errN + ' 行' : '') + '，已选 ' + chosen + ' 行</div>' +
                '<div style="overflow-x:auto"><table class="ie-table"><thead><tr><th style="width:34px"><input type="checkbox" id="ie-all"' + (chosen === okN && okN > 0 ? ' checked' : '') + '></th>' +
                '<th style="width:34px">#</th><th>课程</th><th>星期</th><th>时间</th><th>地点</th><th>重复</th><th>状态</th></tr></thead><tbody>' + rows + '</tbody></table></div>' +
                '<button class="ie-btn primary" id="ie-confirm" style="margin-top:16px">确认导入选中的 ' + chosen + ' 门课程</button>';
              $('#ie-all', body).onchange = function () {
                var on = this.checked;
                parsed.forEach(function (r) { if (r.ok) selected[r.index].on = on; });
                draw();
              };
              $all('input[data-row]', body).forEach(function (cb) {
                cb.onchange = function () { selected[Number(cb.dataset.row)].on = cb.checked; draw(); };
              });
              $('#ie-confirm', body).onclick = async function () {
                var values = parsed.filter(function (r) { return r.ok && selected[r.index] && selected[r.index].on; }).map(function (r) { return r.value; });
                if (!values.length) { App.UI.toast('请先勾选要导入的课程'); return; }
                await App.svc.course.importMany(App.user.id, values);
                App.UI.toast('已导入 ' + values.length + ' 门课程');
                App.bus.emit('course:changed');
                App.Schedule.refresh(); App.Home.refresh();
                App.Router.back();
              };
            }
            draw();
          }
        }
      };
    },

    /* 商家详情与加购（M6 T17） */
    shopDetail: function (shopId) {
      return {
        title: '店铺',
        mount: function (body, entry) {
          var self = this;
          self.entry = entry;
          body.innerHTML = '<div class="life-pad" style="padding-top:16px">加载中…</div>';
          async function cartItems() {
            return (await App.svc.cart.list(App.user.id)).filter(function (i) { return i.shopId === shopId; });
          }
          async function draw() {
            var shop = await App.svc.shop.byId(shopId);
            if (!shop) { body.innerHTML = '<div class="life-empty"><p>商家信息不存在</p></div>'; return; }
            var products = await App.svc.shop.products(shopId);
            var items = await cartItems();
            self.shop = shop;
            var qtyMap = {};
            items.forEach(function (i) { qtyMap[i.productId] = i.qty; });
            var groups = [], gmap = {};
            products.forEach(function (p) {
              if (!gmap[p.category]) { gmap[p.category] = []; groups.push(p.category); }
              gmap[p.category].push(p);
            });
            var groupsHtml = groups.map(function (g) {
              var rows = gmap[g].map(function (p) {
                var sold = p.stock === 'soldout';
                var qty = qtyMap[p.id] || 0;
                var action = sold
                  ? '<span class="prod-badge soldout">已售罄</span>'
                  : (qty > 0
                    ? '<div class="stepper"><button type="button" class="st-minus" data-minus="' + p.id + '">−</button><span class="st-qty">' + qty + '</span><button type="button" class="st-plus" data-plus="' + p.id + '">+</button></div>'
                    : '<button class="add-btn" type="button" data-add="' + p.id + '" aria-label="加入购物车">+</button>');
                return '<div class="prod-row' + (sold ? ' is-soldout' : '') + '">' +
                  '<div class="prod-icon" style="background:' + hexA(shop.color, 0.14) + ';color:' + shop.color + '">' + I(productIcon(p), '', 'width:25px;height:25px') + '</div>' +
                  '<div class="prod-main"><div class="prod-name">' + esc(p.name) +
                    (p.stock === 'limited' ? '<span class="prod-badge limited">限量</span>' : '') + '</div>' +
                    (p.desc ? '<div class="prod-desc">' + esc(p.desc) + '</div>' : '') +
                    '<div class="prod-price">¥' + Core.formatMoney(p.price) + '<small>/ ' + esc(p.unit) + '</small></div></div>' +
                  '<div class="prod-action">' + action + '</div></div>';
              }).join('');
              return '<div class="prod-group-title">' + esc(g) + '</div>' + rows;
            }).join('');
            var total = Core.sumCart(items);
            var qtyAll = items.reduce(function (s, i) { return s + i.qty; }, 0);
            var enough = shop.minOrder <= 0 || total >= shop.minOrder;
            var bar = '<div style="position:sticky;bottom:0;background:linear-gradient(to top,var(--bg) 70%,rgba(247,245,241,0));padding:14px 0 0;">' +
              '<div class="cart-bar' + (qtyAll ? '' : ' empty') + '">' +
              '<div class="cb-ico">' + I('bag', '', 'width:23px;height:23px') + (qtyAll ? '<span class="cb-badge">' + qtyAll + '</span>' : '') + '</div>' +
              '<div class="cb-main">' +
                (qtyAll
                  ? '<div class="cb-total">¥' + Core.formatMoney(total) + '</div><div class="cb-hint">' + (enough ? '已满足起送，可以去结算' : '还差 ¥' + Core.formatMoney(shop.minOrder - total) + ' 起送') + '</div>'
                  : '<div class="cb-total" style="font-size:15px;color:rgba(255,255,255,.72)">购物车还是空的</div><div class="cb-hint">' + (shop.minOrder > 0 ? '¥' + Core.formatMoney(shop.minOrder) + ' 起送' : '无起送门槛') + '</div>') +
              '</div>' +
              '<button type="button" class="cb-go ' + (qtyAll && enough ? 'ready' : 'disabled') + '" data-act="checkout">去结算</button></div></div>';
            body.innerHTML =
              '<div class="shop-hero"><div class="sh-hero-top">' + AppIcons.circleIcon(shopIcon(shop), shop.color, 54) +
              '<div style="flex:1;min-width:0"><div class="sh-name">' + esc(shop.name) + '</div>' +
              '<div class="sh-sub"><span class="shop-cat">' + shop.category + '</span><span>' + esc(shop.deliveryDesc) + '</span><span>' + (shop.minOrder > 0 ? '¥' + Core.formatMoney(shop.minOrder) + ' 起送' : '免起送') + '</span></div></div></div>' +
              (shop.notice ? '<div class="sh-notice">' + I('horn', '', 'width:13px;height:13px;vertical-align:-2px') + ' ' + esc(shop.notice) + '</div>' : '') + '</div>' +
              '<div class="life-pad" style="padding-top:8px;padding-bottom:0">' + groupsHtml + '</div>' + bar;
          }
          self.draw = draw;
          body.onclick = async function (e) {
            var add = e.target.closest('[data-add]');
            var plus = e.target.closest('[data-plus]');
            var minus = e.target.closest('[data-minus]');
            var checkout = e.target.closest('[data-act="checkout"]');
            try {
              if (add) {
                var p = (await App.svc.shop.products(shopId)).filter(function (x) { return x.id === add.dataset.add; })[0];
                var r = await App.svc.cart.addItem(App.user.id, p, 1);
                if (r && r.ok === false && r.code === 'shop_conflict') {
                  var go = await App.UI.modal({ title: '购物车中有其他店铺的商品', body: '购物车里已有「' + esc(r.shopName) + '」的商品。一次只能结算一家店，是否清空购物车并加入「' + esc(self.shop.name) + '」的商品？', confirmText: '清空并加入', cancelText: '再想想' });
                  if (go) { await App.svc.cart.addItem(App.user.id, p, 1, true); App.UI.toast('已加入 ' + p.name); }
                } else { App.UI.toast('已加入 ' + p.name); }
                draw(); App.Life.refresh();
              } else if (plus || minus) {
                var pid = plus ? plus.dataset.plus : minus.dataset.minus;
                var it = (await cartItems()).filter(function (x) { return x.productId === pid; })[0];
                if (it) await App.svc.cart.setQty(it.id, App.user.id, it.qty + (plus ? 1 : -1));
                draw(); App.Life.refresh();
              } else if (checkout) {
                var itemsNow = await cartItems();
                var totalNow = Core.sumCart(itemsNow);
                var shopNow = await App.svc.shop.byId(shopId);
                if (!itemsNow.length) { App.UI.toast('购物车还是空的'); return; }
                if (shopNow.minOrder > 0 && totalNow < shopNow.minOrder) { App.UI.toast('还差 ¥' + Core.formatMoney(shopNow.minOrder - totalNow) + ' 才起送'); return; }
                App.Router.openSub(App.Subs.cartCheckout(shopId));
              }
            } catch (err) { App.UI.toast(err.message || '操作失败'); }
          };
          draw();
        },
        onResume: function () { if (this.draw) this.draw(); }
      };
    },

    /* 购物车与模拟下单（M6 T18） */
    cartCheckout: function (shopId) {
      return {
        title: '确认订单',
        mount: function (body) {
          var self = this;
          body.classList.add('subview-pad');
          self.pickup = '';
          async function draw() {
            var sum = await App.svc.cart.summary(App.user.id);
            var shop = sum.shopId ? await App.svc.shop.byId(sum.shopId) : null;
            self.shop = shop;
            if (!sum.items.length) {
              body.innerHTML = '<div class="life-empty">' + I('emptyBox', '', 'width:70px;height:70px') +
                '<p>购物车还是空的<br>去挑选想吃的、想用的吧</p>' +
                '<button class="btn btn-primary" type="button" data-act="back">去逛逛</button></div>';
              return;
            }
            var itemsHtml = sum.items.map(function (it) {
              return '<div class="cart-item"><div class="ci-top">' +
                '<div class="prod-icon" style="background:' + hexA(shop.color, 0.14) + ';color:' + shop.color + ';width:46px;height:46px">' + I('bag', '', 'width:22px;height:22px') + '</div>' +
                '<div class="ci-info"><div class="ci-name">' + esc(it.name) + '</div>' +
                '<div class="ci-price">¥' + Core.formatMoney(it.price) + '<small>/ 份</small></div></div>' +
                '<div style="display:flex;flex-direction:column;align-items:flex-end;gap:8px">' +
                '<div class="stepper"><button type="button" class="st-minus" data-minus="' + it.id + '">−</button><span class="st-qty">' + it.qty + '</span><button type="button" class="st-plus" data-plus="' + it.id + '">+</button></div>' +
                '<button type="button" class="ci-del" data-del="' + it.id + '">删除</button></div></div>' +
                '<input class="ci-remark" type="text" maxlength="50" data-remark="' + it.id + '" placeholder="给商家留言（选填，如少辣）" value="' + esc(it.remark || '') + '"></div>';
            }).join('');
            var qtyAll = sum.items.reduce(function (s, i) { return s + i.qty; }, 0);
            var enough = shop.minOrder <= 0 || sum.total >= shop.minOrder;
            body.innerHTML =
              '<div class="cart-shop-head">' + AppIcons.circleIcon(shopIcon(shop), shop.color, 34) + esc(shop.name) + '</div>' +
              itemsHtml +
              '<div class="pickup-box"><label>取货说明（选填）</label>' +
              '<textarea id="co-pickup" rows="2" maxlength="100" placeholder="如：中午 12 点后到店自取、放宿舍楼下货架…">' + esc(self.pickup) + '</textarea></div>' +
              '<div class="cart-total-card">' +
              '<div class="ct-row"><span>商品件数</span><span>' + qtyAll + ' 件</span></div>' +
              '<div class="ct-row"><span>' + esc(shop.deliveryDesc) + '</span><span>' + (shop.minOrder > 0 ? '¥' + Core.formatMoney(shop.minOrder) + ' 起送' : '免起送') + '</span></div>' +
              '<div class="ct-row grand"><span>合计</span><b>¥' + Core.formatMoney(sum.total) + '</b></div></div>' +
              '<button class="checkout-btn' + (enough ? '' : ' disabled') + '" type="button" data-act="submit">' +
              (enough ? '模拟下单 · ¥' + Core.formatMoney(sum.total) : '还差 ¥' + Core.formatMoney(shop.minOrder - sum.total) + ' 起送') + '</button>' +
              '<p class="muted small" style="text-align:center;margin-top:10px;line-height:1.6">本地模拟下单，不产生真实支付与配送</p>';
          }
          self.draw = draw;
          body.onclick = async function (e) {
            var back = e.target.closest('[data-act="back"]');
            if (back) { App.Router.back(); return; }
            var plus = e.target.closest('[data-plus]');
            var minus = e.target.closest('[data-minus]');
            var del = e.target.closest('[data-del]');
            var submit = e.target.closest('[data-act="submit"]');
            try {
              if (plus || minus) {
                var id = plus ? plus.dataset.plus : minus.dataset.minus;
                var it = await App.svc.cart.list(App.user.id);
                var cur = it.filter(function (x) { return x.id === id; })[0];
                if (cur) { await App.svc.cart.setQty(id, App.user.id, cur.qty + (plus ? 1 : -1)); draw(); App.Life.refresh(); }
              } else if (del) {
                await App.svc.cart.remove(del.dataset.del, App.user.id); draw(); App.Life.refresh();
              } else if (submit) {
                // 提交前先把页面上的单品备注与取货说明一次性落库，避免输入后立即下单丢备注
                var remarkInputs = body.querySelectorAll('.ci-remark');
                for (var k = 0; k < remarkInputs.length; k++) {
                  await App.svc.cart.setRemark(remarkInputs[k].dataset.remark, App.user.id, remarkInputs[k].value);
                }
                var pkEl = body.querySelector('#co-pickup');
                if (pkEl) self.pickup = pkEl.value;
                var sum = await App.svc.cart.summary(App.user.id);
                var shop = sum.shopId ? await App.svc.shop.byId(sum.shopId) : null;
                if (!sum.items.length) { App.UI.toast('购物车还是空的'); return; }
                if (shop && shop.minOrder > 0 && sum.total < shop.minOrder) { App.UI.toast('未达到起送金额'); return; }
                var order = await App.svc.order.create(App.user.id, self.pickup || '');
                App.bus.emit('order:changed');
                App.Home.refresh(); App.Life.refresh();
                App.UI.toast('模拟下单成功，等待取餐');
                App.Router.stack = []; $('#subview-layer').innerHTML = '';
                App.Router.go('life');
                App.Router.openSub(App.Subs.orderDetail(order.id));
              }
            } catch (err) { App.UI.toast(err.message || '下单失败'); }
          };
          body.addEventListener('change', function (e) {
            var rk = e.target.closest('[data-remark]');
            if (rk) { App.svc.cart.setRemark(rk.dataset.remark, App.user.id, rk.value); return; }
            var pk = e.target.closest('#co-pickup');
            if (pk) self.pickup = pk.value;
          });
          body.addEventListener('input', function (e) {
            var pk = e.target.closest('#co-pickup');
            if (pk) self.pickup = pk.value;
          });
          draw();
        }
      };
    },

    /* 我的订单列表（M6 T19） */
    ordersList: function () {
      return {
        title: '我的订单',
        mount: function (body) {
          var self = this;
          body.classList.add('subview-pad');
          async function draw() {
            var orders = await App.svc.order.list(App.user.id);
            if (!orders.length) {
              body.innerHTML = '<div class="life-empty">' + I('order', '', 'width:70px;height:70px') +
                '<p>还没有订单<br>去生活页挑一家店试试模拟下单</p>' +
                '<button class="btn btn-primary" type="button" data-act="go-life">去逛逛</button></div>';
              return;
            }
            body.innerHTML = orders.map(function (o) {
              var qty = o.items.reduce(function (s, i) { return s + i.qty; }, 0);
              return '<div class="order-card" data-order="' + o.id + '">' +
                '<div class="oc-top"><div class="oc-shop">' + esc(o.shopName) + '</div>' + statusPill(o.status) + '</div>' +
                '<div class="oc-no">' + esc(o.orderNo) + ' · ' + fmtTime(o.createdAt) + '</div>' +
                '<div class="oc-items">' + esc(orderItemText(o)) + '</div>' +
                '<div class="oc-bottom"><div class="oc-total">¥' + Core.formatMoney(o.total) + '<small> 共' + qty + '件</small></div>' +
                '<span class="oc-act">查看详情 ›</span></div></div>';
            }).join('');
          }
          self.draw = draw;
          body.onclick = function (e) {
            if (e.target.closest('[data-act="go-life"]')) { App.Router.back(); return; }
            var card = e.target.closest('[data-order]');
            if (card) App.Router.openSub(App.Subs.orderDetail(card.dataset.order));
          };
          draw();
        },
        onResume: function () { if (this.draw) this.draw(); }
      };
    },

    /* 订单详情与状态推进（M6 T19） */
    orderDetail: function (orderId) {
      return {
        title: '订单详情',
        mount: function (body) {
          var self = this;
          body.classList.add('subview-pad');
          async function draw() {
            var o;
            try { o = await App.svc.order.byId(orderId, App.user.id); }
            catch (e) { body.innerHTML = '<div class="life-empty"><p>' + esc(e.message) + '</p></div>'; return; }
            var steps = ['pending', 'doing', 'done'];
            var tl = steps.map(function (st) {
              var log = o.logs.filter(function (l) { return l.status === st; })[0];
              var cls = st === o.status ? 'current' : (log ? 'done' : '');
              return '<div class="tl-item ' + cls + '"><div class="tl-dot"></div><div>' +
                '<div class="tl-status">' + Core.ORDER_STATUS[st].label + '</div>' +
                '<div class="tl-time">' + (log ? fmtTime(log.at) : '待处理') + '</div></div></div>';
            }).join('');
            var itemsHtml = o.items.map(function (i) {
              return '<div class="od-item"><span>' + esc(i.name) + '<span class="oi-qty">×' + i.qty + '</span>' +
                (i.remark ? '<div class="oi-remark">留言：' + esc(i.remark) + '</div>' : '') + '</span>' +
                '<span>¥' + Core.formatMoney(i.price * i.qty) + '</span></div>';
            }).join('');
            var btn;
            if (o.status === 'done') {
              btn = '<button class="advance-btn done" type="button" disabled>订单已完成</button>';
            } else if (o.status === 'pending') {
              btn = '<button class="advance-btn" type="button" data-act="advance">商家已接单 · 标记为进行中</button>';
            } else {
              btn = '<button class="advance-btn" type="button" data-act="advance">已取到餐 · 标记为已完成</button>';
            }
            body.innerHTML =
              '<div class="order-detail-sec" style="display:flex;align-items:center;justify-content:space-between">' +
              '<div><div style="font-size:16px;font-weight:800">' + esc(o.shopName) + '</div>' +
              '<div class="muted small" style="margin-top:4px">' + esc(o.orderNo) + '<br>' + fmtTime(o.createdAt) + ' 下单</div></div>' +
              statusPill(o.status) + '</div>' +
              '<div class="order-detail-sec"><div class="ods-title">商品明细</div>' + itemsHtml +
              '<div class="ct-row grand" style="display:flex;justify-content:space-between;margin-top:8px"><span>合计</span><b>¥' + Core.formatMoney(o.total) + '</b></div></div>' +
              '<div class="order-detail-sec"><div class="ods-title">取货说明</div><div class="od-kv">' + (o.pickupNote ? esc(o.pickupNote) : '<span class="muted">未填写，按商家常规方式准备</span>') + '</div></div>' +
              '<div class="order-detail-sec"><div class="ods-title">订单进度</div><div class="status-timeline">' + tl + '</div></div>' +
              btn;
          }
          self.draw = draw;
          body.onclick = async function (e) {
            if (!e.target.closest('[data-act="advance"]')) return;
            try {
              var o = await App.svc.order.advance(orderId, App.user.id);
              App.bus.emit('order:changed');
              App.Home.refresh(); App.Life.refresh();
              App.UI.toast('订单已更新为「' + Core.ORDER_STATUS[o.status].label + '」');
              draw();
            } catch (err) { App.UI.toast(err.message || '操作失败'); }
          };
          draw();
        }
      };
    },

    /* 发起话题（M7 T21，必填校验 + 字数统计 + 未保存守卫） */
    topicCreate: function () {
      return {
        title: '发起话题',
        guard: function () {
          var t = document.querySelector('.subview.show #tf-title');
          var c = document.querySelector('.subview.show #tf-content');
          return ((t && t.value.trim()) || (c && c.value.trim())) ? '话题还没有发布，确定要离开吗？' : null;
        },
        mount: function (body) {
          body.classList.add('subview-pad');
          body.innerHTML =
            '<div class="form-group" id="fg-title"><label>标题</label>' +
            '<input class="field" id="tf-title" maxlength="30" placeholder="一句话说清你想聊的（30 字内）">' +
            '<div class="char-count" id="cc-title">0/30</div><div class="err" id="err-title">标题不能为空</div></div>' +
            '<div class="form-group" id="fg-content"><label>正文</label>' +
            '<textarea class="field" id="tf-content" maxlength="5000" placeholder="说说详细内容，让同学们更好地回应你…"></textarea>' +
            '<div class="char-count" id="cc-content">0/5000</div><div class="err" id="err-content">正文不能为空</div></div>' +
            '<button class="topic-submit" id="tf-submit" type="button">发布话题</button>';
          var ti = $('#tf-title', body), ci = $('#tf-content', body);
          ti.addEventListener('input', function () {
            $('#cc-title', body).textContent = ti.value.trim().length + '/30';
            $('#fg-title', body).classList.remove('field-invalid');
          });
          ci.addEventListener('input', function () {
            $('#cc-content', body).textContent = ci.value.trim().length + '/5000';
            $('#fg-content', body).classList.remove('field-invalid');
          });
          $('#tf-submit', body).onclick = async function () {
            var check = Core.validateTopic(ti.value, ci.value);
            var bad = false;
            if (check.errors.title) {
              $('#err-title', body).textContent = check.errors.title;
              $('#fg-title', body).classList.add('field-invalid');
              bad = true;
            }
            if (check.errors.content) {
              $('#err-content', body).textContent = check.errors.content;
              $('#fg-content', body).classList.add('field-invalid');
              bad = true;
            }
            if (bad) { App.UI.toast('请完善标题和正文'); return; }
            try {
              var t = await App.svc.forum.createTopic(App.user.id, ti.value, ci.value);
              App.bus.emit('forum:changed');
              App.Home.refresh(); App.Forum.refresh();
              App.Router.clearGuard();
              App.Router.stack = []; $('#subview-layer').innerHTML = '';
              App.Router.go('forum');
              App.Router.openSub(App.Subs.topicDetail(t.id));
              App.UI.toast('话题已发布');
            } catch (e) {
              if (!e.errors) App.UI.toast(e.message || '发布失败');
            }
          };
        }
      };
    },

    /* 话题详情与评论（M7 T22） */
    topicDetail: function (topicId) {
      return {
        title: '话题详情',
        mount: function (body, entry) {
          var self = this;
          body.classList.add('subview-pad');
          body.innerHTML = '<div class="forum-pad">加载中…</div>';
          async function draw() {
            var t;
            try { t = await App.svc.forum.topic(topicId); }
            catch (e) { body.innerHTML = '<div class="forum-pad"><div class="life-empty"><p>' + esc(e.message) + '</p></div></div>'; return; }
            if (entry) { var ti2 = entry.el.querySelector('.ab-title'); if (ti2) ti2.textContent = '话题详情'; }
            var repliesHtml = t.replies.length
              ? t.replies.map(function (r) {
                var mine = r.authorId === App.user.id;
                return '<div class="reply-item"><img class="av av-32" src="' + r.authorAvatar + '" alt="">' +
                  '<div class="rp-body"><div class="rp-top"><span class="rp-name">' + esc(r.authorName) + '</span>' +
                  '<span class="rp-time">' + forumTime(r.createdAt) + '</span>' +
                  (mine ? '<button type="button" class="rp-del" data-del-reply="' + r.id + '">删除</button>' : '') +
                  '</div><div class="rp-content">' + esc(r.content) + '</div></div></div>';
              }).join('')
              : '<div class="muted small" style="padding:14px 2px;text-align:center">还没有评论，来抢沙发</div>';
            body.innerHTML =
              '<div class="td-card"><div class="td-title">' + esc(t.title) + '</div>' +
              '<div class="td-author"><img class="av" src="' + t.authorAvatar + '" alt=""><div>' +
              '<div class="td-name">' + esc(t.authorName) + '</div>' +
              '<div class="td-time">' + fmtTime(t.createdAt) + ' 发布</div></div></div>' +
              '<div class="td-content">' + esc(t.content) + '</div></div>' +
              '<div class="td-card"><div class="td-reply-head">全部评论 ' + t.replies.length + '</div>' + repliesHtml + '</div>' +
              '<div class="reply-bar"><textarea id="rd-input" rows="1" maxlength="1000" placeholder="友善发言，说点什么…"></textarea>' +
              '<button type="button" class="reply-send" id="rd-send">发送</button></div>';
            var input = $('#rd-input', body);
            input.addEventListener('input', function () {
              $('#rd-send', body).classList.toggle('disabled', !input.value.trim());
            });
            $('#rd-send', body).onclick = async function () {
              var content = input.value.trim();
              var check = Core.validateReply(content);
              if (!check.ok) { App.UI.toast(check.error); return; }
              try {
                await App.svc.forum.createReply(App.user.id, topicId, content);
                App.bus.emit('forum:changed');
                App.Forum.refresh(); App.Home.refresh();
                App.UI.toast('评论已发布');
                draw();
              } catch (e) { App.UI.toast(e.message || '评论失败'); }
            };
          }
          self.draw = draw;
          body.onclick = async function (e) {
            var del = e.target.closest('[data-del-reply]');
            if (!del) return;
            var go = await App.UI.modal({ title: '删除评论', body: '确定删除你发表的这条评论吗？删除后不可恢复。', danger: true, confirmText: '删除', cancelText: '取消' });
            if (!go) return;
            try {
              await App.svc.forum.deleteReply(del.dataset.delReply, App.user.id);
              App.bus.emit('forum:changed');
              App.Forum.refresh();
              App.UI.toast('评论已删除');
              draw();
            } catch (err) { App.UI.toast(err.message || '删除失败'); }
          };
          draw();
        }
      };
    },

    /* 我的话题 / 我的评论（M7 T22，M8 从我的页再次接线） */
    myForum: function (tab) {
      return {
        title: '我的论坛',
        mount: function (body) {
          var self = this;
          self.tab = tab || 'topics';
          body.innerHTML =
            '<div class="seg" style="margin-top:14px"><div class="seg-item" data-seg="topics">我的话题</div>' +
            '<div class="seg-item" data-seg="replies">我的评论</div></div><div id="my-list"></div>';
          async function draw() {
            $all('.seg-item', body).forEach(function (s) { s.classList.toggle('on', s.dataset.seg === self.tab); });
            var box = $('#my-list', body);
            if (self.tab === 'topics') {
              var list = await App.svc.forum.myTopics(App.user.id);
              if (!list.length) { box.innerHTML = '<div class="life-empty">' + I('chat', '', 'width:60px;height:60px') + '<p>你还没有发布过话题</p></div>'; return; }
              box.innerHTML = list.map(function (t) {
                return '<div class="my-item" data-topic="' + t.id + '"><div class="my-item-title">' + esc(t.title) + '</div>' +
                  '<div class="my-item-meta"><span>' + forumTime(t.createdAt) + ' 发布</span></div></div>';
              }).join('');
            } else {
              var rs = await App.svc.forum.myReplies(App.user.id);
              if (!rs.length) { box.innerHTML = '<div class="life-empty">' + I('chat', '', 'width:60px;height:60px') + '<p>你还没有发表过评论</p></div>'; return; }
              box.innerHTML = rs.map(function (r) {
                return '<div class="my-item" data-topic="' + r.topicId + '"><div class="my-reply-on">来自话题：' + esc(r.topicTitle) + '</div>' +
                  '<div class="my-reply-content">' + esc(r.content) + '</div>' +
                  '<div class="my-item-meta"><span>' + forumTime(r.createdAt) + '</span></div></div>';
              }).join('');
            }
          }
          self.draw = draw;
          body.onclick = function (e) {
            var seg = e.target.closest('[data-seg]');
            if (seg) { if (self.tab !== seg.dataset.seg) { self.tab = seg.dataset.seg; draw(); } return; }
            var card = e.target.closest('[data-topic]');
            if (card) { App.Router.openSub(App.Subs.topicDetail(card.dataset.topic)); return; }
          };
          draw();
        }
      };
    },

    /* 数据管理：导出 / 恢复 / 快照回滚 / 开学日期 / 风险提示（M8 T24，A-17~A-20） */
    dataManager: function () {
      return {
        title: '数据管理',
        mount: function (body) {
          body.classList.add('subview-pad');
          var SNAP_LABELS = [
            ['users', '账户'], ['courses', '课程'], ['memos', '备忘'], ['orders', '订单'],
            ['cart', '购物车'], ['topics', '话题'], ['replies', '评论'], ['shops', '商家'],
            ['products', '商品'], ['notices', '通知']
          ];
          function backupFileName(iso) {
            var d = new Date(iso), p = function (n) { return (n < 10 ? '0' : '') + n; };
            return 'chengyi-campus-backup-' + d.getFullYear() + p(d.getMonth() + 1) + p(d.getDate()) +
              '-' + p(d.getHours()) + p(d.getMinutes()) + '.json';
          }
          function snapReason(s) {
            if (s.reason === 'before_restore') return '恢复前自动快照';
            if (s.reason === 'before_rollback') return '回滚前自动快照';
            return s.reason || '操作前快照';
          }
          function setError(msg) {
            var box = $('#dm-restore-err', body);
            if (!box) return;
            if (msg) { box.textContent = msg; box.style.display = 'block'; }
            else box.style.display = 'none';
          }
          async function doExport() {
            var backup = await App.svc.backup.export();
            await App.svc.settings.set('lastExportAt', backup.exportedAt);
            var blob = new Blob([JSON.stringify(backup, null, 2)], { type: 'application/json' });
            var url = URL.createObjectURL(blob);
            var a = document.createElement('a');
            a.href = url; a.download = backupFileName(backup.exportedAt);
            document.body.appendChild(a); a.click(); a.remove();
            setTimeout(function () { URL.revokeObjectURL(url); }, 1500);
            App.UI.toast('备份文件已开始下载');
            draw();
          }
          function afterReplace(title) {
            App.UI.modal({
              title: title,
              body: '数据已写入本机数据库。为保证界面与数据完全一致，建议立即重新加载页面。',
              confirmText: '立即重新加载', cancelText: '稍后'
            }).then(function (reloadNow) {
              if (reloadNow) location.reload();
              else draw();
            });
          }
          async function confirmRestore(r) {
            var parts = SNAP_LABELS.filter(function (x) { return (r.summary[x[0]] || 0) > 0; })
              .map(function (x) { return x[1] + ' ' + r.summary[x[0]]; });
            var go = await App.UI.modal({
              title: '确认恢复备份', danger: true, confirmText: '确认恢复', cancelText: '取消',
              body: '备份导出时间：' + fmtTime(r.exportedAt) + '<br>恢复范围：' + esc(parts.join('、')) +
                '<br><br>恢复将<b>覆盖</b>当前全部数据。系统已自动为当前数据创建快照，恢复后可在本页回滚。'
            });
            if (!go) return;
            try {
              await App.svc.backup.restore(r.backup);
              setError('');
              App.UI.toast('恢复完成');
              afterReplace('恢复完成');
            } catch (e) {
              setError('恢复失败，原有数据未被改动：' + (e.message || '未知错误'));
            }
          }
          async function doMigrate() {
            var msg = $('#dm-migrate-msg', body);
            if (!window.AppDB || !window.AppDB.IDBRepo || !window.AppDBHttp || !App.repo) {
              setError('当前环境不支持读取本机数据库（请通过后端地址访问本页）');
              return;
            }
            var HM = window.AppDBHttp;
            var idb = new window.AppDB.IDBRepo(window.indexedDB);
            var stats;
            try {
              await idb.open();
              var data = await idb.exportAll();
              stats = HM.summarizeMigration(data);
            } catch (e) {
              setError('读取本机数据失败：' + ((e && e.message) || e));
              return;
            }
            if (!HM.hasPersonalData(stats)) {
              App.UI.toast('本机没有需要迁移的个人数据，未改动数据库');
              if (msg) msg.textContent = '检测完成：本机仅有初始示例数据，无需迁移。';
              return;
            }
            var p = stats.personal || {};
            var lines = [];
            if (stats.realUserCount) lines.push('账户 ' + stats.realUserCount + ' 个');
            if (p.courses) lines.push('课程 ' + p.courses + ' 门');
            if (p.memos) lines.push('备忘 ' + p.memos + ' 条');
            if (p.orders) lines.push('订单 ' + p.orders + ' 笔');
            if (p.cart) lines.push('购物车 ' + p.cart + ' 项');
            if (p.topics) lines.push('话题 ' + p.topics + ' 个');
            if (p.replies) lines.push('评论 ' + p.replies + ' 条');
            var go = await App.UI.modal({
              title: '确认迁移到数据库', danger: true, confirmText: '确认迁移', cancelText: '取消',
              body: '在本机浏览器检测到：<b>' + esc(lines.join('、')) + '</b>。<br><br>' +
                '迁移将用本机数据<b>整体覆盖</b>数据库当前全部内容；本机浏览器里的原数据不会被删除，可随时重试。确定继续吗？'
            });
            if (!go) return;
            try {
              await HM.migrateRepo(App.repo, idb);
              setError('');
              App.UI.toast('迁移完成');
              afterReplace('迁移完成');
            } catch (e) {
              setError('迁移失败，数据库未被改动：' + ((e && e.message) || '未知错误'));
            }
          }
          async function draw() {
            var lastExport = await App.svc.settings.get('lastExportAt', null);
            var snaps = await App.svc.backup.listSnapshots();
            var sem = App.sem || await App.svc.settings.semesterStart();
            var snapsHtml = snaps.length
              ? snaps.map(function (s) {
                return '<div class="snap-item"><div class="snap-info"><div class="snap-reason">' + esc(snapReason(s)) + '</div>' +
                  '<div class="snap-time">' + fmtTime(s.createdAt) + '</div></div>' +
                  '<button type="button" class="snap-rollback" data-snap="' + s.id + '">回滚</button></div>';
              }).join('')
              : '<div class="muted small" style="padding:6px 2px 10px">还没有自动快照。恢复备份或回滚前会自动创建，最多保留最近 3 个。</div>';
            $('#dm-last-export', body).textContent = lastExport ? ('最近导出：' + fmtTime(lastExport)) : '还没有导出过备份';
            $('#dm-snaps', body).innerHTML = snapsHtml;
            var di = $('#dm-semester', body);
            if (di && !di.value) di.value = sem;
          }

          body.innerHTML =
            '<div class="dm-card">' +
            '<div class="dm-title">备份与恢复</div>' +
            '<div class="dm-desc">导出一份 JSON 备份保存到电脑，换机或清除浏览器数据后可用它恢复全部内容。</div>' +
            '<button type="button" class="dm-btn dm-btn-primary" id="dm-export">' + I('upload', '', 'width:17px;height:17px;vertical-align:-3px') + ' 导出备份（JSON）</button>' +
            '<button type="button" class="dm-btn dm-btn-outline" id="dm-choose">' + I('refresh', '', 'width:16px;height:16px;vertical-align:-3px') + ' 从备份文件恢复</button>' +
            '<input type="file" id="dm-file" accept="application/json,.json" hidden>' +
            '<div class="dm-meta" id="dm-last-export">还没有导出过备份</div>' +
            '<div class="dm-error" id="dm-restore-err" style="display:none"></div></div>' +

            (window.__APP_DB_MODE === 'http'
              ? '<div class="dm-card" id="dm-migrate-card" style="border-color:#cfe3ff;background:#f5f9ff">' +
                '<div class="dm-title">从本机浏览器迁移旧数据到数据库</div>' +
                '<div class="dm-desc">第一版数据保存在浏览器本地（IndexedDB）。点击下方按钮，可把<b>当前这个浏览器</b>里原有的账户、课程表、备忘、订单、帖子等一次性迁移到 MySQL 数据库。<br><br>迁移只读取本机数据、<b>不会删除本机原数据</b>；但会用本机数据<b>整体覆盖</b>数据库现有内容。若本机没有个人数据，会提示无需迁移、不会覆盖。建议迁移前先在上方「导出备份」留一份 JSON。</div>' +
                '<button type="button" class="dm-btn dm-btn-primary" id="dm-migrate">检测并迁移本机数据</button>' +
                '<div class="dm-meta" id="dm-migrate-msg"></div></div>'
              : '') +

            '<div class="dm-card dm-warn">' +
            '<div class="dm-title" style="color:#b07a1c">' + I('horn', '', 'width:17px;height:17px;vertical-align:-3px') + ' 清除浏览器数据前请先备份</div>' +
            '<div class="dm-desc">如果你在浏览器里手动清除了本站的站点数据（缓存、Cookie、站点存储），应用里的课程、备忘、订单、话题、账户等将<b>无法由应用自行找回</b>。请定期点上面的「导出备份」把 JSON 文件保存在电脑里；清除后可在本页选择该文件恢复。</div>' +
            '<button type="button" class="dm-btn dm-btn-outline" data-act="export" style="border-color:#e6c483;color:#b07a1c">立即导出备份</button></div>' +

            '<div class="dm-card">' +
            '<div class="dm-title">本地恢复点（自动快照）</div>' +
            '<div class="dm-desc">每次恢复备份或回滚前，系统会自动把当时的数据存为一个本地快照，最多保留最近 3 个。</div>' +
            '<div id="dm-snaps"></div></div>' +

            '<div class="dm-card">' +
            '<div class="dm-title">学期设置</div>' +
            '<div class="dm-desc">设置本学期开学日期，课程表与首页会据此计算教学周（第几周）。</div>' +
            '<div class="dm-sem-row"><label for="dm-semester">开学日期</label>' +
            '<input type="date" id="dm-semester" class="dm-date"></div>' +
            '<button type="button" class="dm-btn dm-btn-primary" id="dm-save-sem" style="margin-top:12px">保存开学日期</button></div>';

          var fileInput = $('#dm-file', body);
          fileInput.addEventListener('change', function () {
            var f = fileInput.files && fileInput.files[0];
            if (!f) return;
            var reader = new FileReader();
            reader.onload = function () {
              var r = App.svc.backup.inspect(String(reader.result || ''));
              fileInput.value = '';
              if (!r.ok) { setError(r.error); App.UI.toast('备份文件无法识别'); return; }
              setError('');
              confirmRestore(r);
            };
            reader.onerror = function () { setError('文件读取失败，请重新选择'); fileInput.value = ''; };
            reader.readAsText(f);
          });

          body.onclick = async function (e) {
            if (e.target.closest('#dm-export') || e.target.closest('[data-act="export"]')) { await doExport(); return; }
            if (e.target.closest('#dm-choose')) { setError(''); fileInput.click(); return; }
            if (e.target.closest('#dm-migrate')) { setError(''); await doMigrate(); return; }
            var saveSem = e.target.closest('#dm-save-sem');
            if (saveSem) {
              var v = $('#dm-semester', body).value;
              if (!v || isNaN(new Date(v + 'T00:00:00').getTime())) { App.UI.toast('请选择正确的开学日期'); return; }
              await App.svc.settings.set('semesterStart', v);
              App.sem = v;
              App.bus.emit('semester:changed', v);
              App.Home.refresh();
              if (App.Schedule && App.Schedule.onShow) App.Schedule.onShow();
              App.UI.toast('开学日期已保存');
              return;
            }
            var rb = e.target.closest('[data-snap]');
            if (rb) {
              var go = await App.UI.modal({
                title: '回滚到该快照', danger: true, confirmText: '确认回滚', cancelText: '取消',
                body: '回滚会用该快照的内容<b>覆盖</b>当前全部数据，系统会先为当前数据再创建一个快照。确定继续吗？'
              });
              if (!go) return;
              try {
                await App.svc.backup.rollback(rb.dataset.snap);
                App.UI.toast('已回滚');
                afterReplace('回滚完成');
              } catch (err) { App.UI.toast(err.message || '回滚失败'); }
            }
          };

          draw();
        }
      };
    }
  };

  /* ---------------- 启动 ---------------- */
  App.boot = async function () {
    App.clock.start();
    try {
      var started = await DB.boot(window.indexedDB);
      App.repo = started.repo; App.svc = started.svc;
      App.sem = await App.svc.settings.semesterStart();
    } catch (e) {
      document.body.innerHTML = '<div style="padding:40px;font-family:sans-serif;color:#a33">应用数据库打开失败：' + (e && e.message) + '<br>请使用现代版 Edge 或 Chrome 浏览器打开。</div>';
      return;
    }
    var user = await App.svc.auth.current();
    if (user) App.enterApp(user);
    else Gate.show();
  };

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', App.boot);
  else App.boot();
})();
