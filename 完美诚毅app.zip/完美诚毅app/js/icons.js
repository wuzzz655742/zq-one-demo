/* ============================================================
 * icons.js —— 内联 SVG 图标库（线性风格，currentColor 继承）
 * 全局 AppIcons.svg(name) / AppIcons.SERVICE / AppIcons.SHOP
 * ============================================================ */
(function (root, factory) {
  'use strict';
  var api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.AppIcons = api;
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  // 24x24 线性图标，描边 currentColor
  var G = {
    back: '<path d="M15 5l-7 7 7 7"/>',
    chevronRight: '<path d="M9 5l7 7-7 7"/>',
    chevronDown: '<path d="M5 9l7 7 7-7"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    check: '<path d="M5 12.5l4.5 4.5L19 7"/>',
    close: '<path d="M6 6l12 12M18 6L6 18"/>',
    edit: '<path d="M4 20h4L19 9l-4-4L4 16v4z"/><path d="M13.5 6.5l4 4"/>',
    trash: '<path d="M4 7h16M9 7V5h6v2M6 7l1 13h10l1-13M10 11v6M14 11v6"/>',
    clock: '<circle cx="12" cy="12" r="8.5"/><path d="M12 7.5V12l3 2"/>',
    location: '<path d="M12 21s7-6.2 7-11a7 7 0 1 0-14 0c0 4.8 7 11 7 11z"/><circle cx="12" cy="10" r="2.5"/>',
    calendar: '<rect x="3.5" y="4.5" width="17" height="16" rx="2.5"/><path d="M3.5 9h17M8 2.5v4M16 2.5v4"/><path d="M7.5 13h2.5M11.5 13h2.5M15.5 13h2M7.5 16.5h2.5M11.5 16.5h2.5"/>',
    note: '<path d="M5 4h14v16l-3-2-2 2-2-2-2 2-2-2-3 2V4z"/><path d="M8.5 9h7M8.5 12.5h7M8.5 16h4"/>',
    search: '<circle cx="11" cy="11" r="6.5"/><path d="M16 16l4.5 4.5"/>',
    camera: '<rect x="3" y="7" width="18" height="13" rx="2.5"/><path d="M8.5 7l1-2.5h5L15.5 7"/><circle cx="12" cy="13.5" r="3.2"/>',
    image: '<rect x="3.5" y="4.5" width="17" height="15" rx="2.5"/><circle cx="8.5" cy="9.5" r="1.6"/><path d="M4.5 17l5-4.5 4 3.5 3-2.5 3 2.5"/>',
    cart: '<path d="M3 4h2l2.2 11.5h10L21 7H6.2"/><circle cx="9" cy="19.5" r="1.3"/><circle cx="17" cy="19.5" r="1.3"/>',
    bag: '<path d="M5 8h14l-1 12.5H6L5 8z"/><path d="M9 8a3 3 0 0 1 6 0"/>',
    chat: '<path d="M4 5h16v11H9l-4 3.5V16H4V5z"/><path d="M8.5 9.5h7M8.5 12.5h4.5"/>',
    wallet: '<rect x="3" y="6" width="18" height="13" rx="2.5"/><path d="M3 10h18"/><circle cx="16" cy="13.5" r="1.3" fill="currentColor" stroke="none"/>',
    yuan: '<path d="M7 5l5 6.5L17 5M12 11.5V19M8.5 14h7M8.5 17h7"/>',
    scan: '<path d="M4 8V5a1 1 0 0 1 1-1h3M16 4h3a1 1 0 0 1 1 1v3M20 16v3a1 1 0 0 1-1 1h-3M8 20H5a1 1 0 0 1-1-1v-3"/><path d="M4 12h16"/>',
    lightning: '<path d="M13 2L4 13.5h6L10 22l9-11.5h-6L13 2z"/>',
    cloud: '<path d="M7 18h10a4 4 0 0 0 .5-7.97A5.5 5.5 0 0 0 6.7 9.2 3.75 3.75 0 0 0 7 18z"/>',
    grid: '<rect x="4" y="4" width="6.5" height="6.5" rx="1.6"/><rect x="13.5" y="4" width="6.5" height="6.5" rx="1.6"/><rect x="4" y="13.5" width="6.5" height="6.5" rx="1.6"/><rect x="13.5" y="13.5" width="6.5" height="6.5" rx="1.6"/>',
    life: '<path d="M12 21s-7-4.6-7-10a4 4 0 0 1 7-2.6A4 4 0 0 1 19 11c0 5.4-7 10-7 10z"/>',
    bell: '<path d="M6 16V11a6 6 0 1 1 12 0v5l1.5 2.5h-15L6 16z" fill="currentColor" stroke="none"/>',
    refresh: '<path d="M20 12a8 8 0 1 1-2.3-5.6M20 3.5V7h-3.5"/>',
    download: '<path d="M12 3v12m0 0l-4-4m4 4l4-4M4 19h16"/>',
    upload: '<path d="M12 21V9m0 0l-4 4m4-4l4 4M4 5h16"/>',
    user: '<circle cx="12" cy="8" r="4"/><path d="M4 20.5c1.2-3.6 4.4-5 8-5s6.8 1.4 8 5"/>',
    logout: '<path d="M14 4H6v16h8M10 12h10m0 0l-3.5-3.5M20 12l-3.5 3.5"/>',
    order: '<path d="M6 3h12v18l-3-2-2 2-2-2-2 2-3-2V3z"/><path d="M9 8h6M9 11.5h6M9 15h3.5"/>',
    tshirt: '<path d="M8.5 4L4 7l2.5 3.5L8.5 9.5V20h7V9.5l2 1L20 7l-4.5-3a3.5 3.5 0 0 1-7 0z"/>',
    box: '<path d="M4 8l8-4 8 4v8l-8 4-8-4V8z"/><path d="M4 8l8 4 8-4M12 12v8"/>',
    filter: '<path d="M4 6h16l-6 7v5l-4 2v-7L4 6z"/>',
    star: '<path d="M12 3.5l2.6 5.3 5.9.9-4.3 4.1 1 5.8L12 16.9 6.8 19.6l1-5.8L3.5 9.7l5.9-.9L12 3.5z"/>',
    shield: '<path d="M12 3l7 3v6c0 4.5-3 7.5-7 9-4-1.5-7-4.5-7-9V6l7-3z"/><path d="M9 12l2 2 4-4"/>',
    book: '<path d="M5 4.5A2.5 2.5 0 0 1 7.5 2H19v17H7.5A2.5 2.5 0 0 0 5 21.5V4.5z"/><path d="M19 19H7.5A2.5 2.5 0 0 0 5 21.5"/>',
    printer: '<path d="M7 8V3.5h10V8"/><rect x="4" y="8" width="16" height="8" rx="1.5"/><path d="M7 14h10v6.5H7V14z"/><circle cx="17" cy="11.5" r="1" fill="currentColor" stroke="none"/>',
    cup: '<path d="M6 8h11v6a5 5 0 0 1-10 0V8z"/><path d="M17 9h2.5a2.5 2.5 0 0 1 0 5H17"/><path d="M8 5c0 1-1 1.5-1 2.5M11.5 5c0 1-1 1.5-1 2.5M15 5c0 1-1 1.5-1 2.5"/>',
    bowl: '<path d="M4 12h16a8 8 0 0 1-16 0z"/><path d="M9 8.5c.5-.8.5-1.6 0-2.5M13 8.5c.5-.8.5-1.6 0-2.5"/>',
    dumpling: '<path d="M4 14a8 8 0 0 1 16 0c0 1.5-16 1.5-16 0z"/><path d="M8.5 10.5l-.5-2M12 10l0-2.5M15.5 10.5l.5-2"/>',
    rice: '<path d="M4 13h16a8 8 0 0 1-16 0z"/><path d="M9 10.5c.3-.6.3-1.2 0-1.8M12.5 10.5c.3-.6.3-1.2 0-1.8M16 10.5c.3-.6.3-1.2 0-1.8"/>',
    veg: '<path d="M5 19c0-8 6-13 14-14-1 8-6 13-14 14z"/><path d="M5 19C8 15 11 12 15 10"/>',
    bottle: '<path d="M10 2h4v3l1.5 3v12.5a1.5 1.5 0 0 1-1.5 1.5h-4a1.5 1.5 0 0 1-1.5-1.5V8L10 5V2z"/><path d="M8.5 11h7"/>',
    snack: '<path d="M5 8l2-4h10l2 4-3 2v10H8V10L5 8z"/><path d="M9 13h6M9 16.5h6"/>',
    tissue: '<rect x="4" y="9" width="16" height="11" rx="1.5"/><path d="M9 9c0-3 1.5-5 3-5s2 2 2 5"/>',
    pen: '<path d="M4 20l1-4L15.5 5.5a2 2 0 0 1 3 3L8 19l-4 1z"/>',
    banana: '<path d="M5 6c0 8 6 13 13 13 1.5 0 2-1 1.5-2.5-5.5 0-9-3.5-10-9C9 6 7 5 5 6z"/><path d="M5 6c0-1 .5-2 1.5-2.5"/>',
    apple: '<path d="M12 8c-1-2-3-3-5-2.5C4.5 6.5 4 10 5.5 13c1 2 2.5 4 4 3.5 1-.3 1.5-.3 2.5 0 1.5.5 3-1.5 4-3.5 1.5-3 1-6.5-1.5-7.5C12 5 13 6 12 8z"/><path d="M12 8c0-2 1-3.5 3-4"/>',
    watermelon: '<path d="M3 11a9 9 0 0 1 18 0H3z"/><path d="M8.5 11a3.5 3.5 0 0 1 7 0"/><path d="M6.5 13.5l1 1M11 14.5l1 1M15.5 13.5l1 1"/>',
    photo: '<rect x="4" y="5" width="16" height="14" rx="2.5"/><circle cx="12" cy="11" r="3"/><path d="M8 17l3-2.5 2 1.5 3-2"/>',
    scanDoc: '<path d="M7 3h7l4 4v14H7V3z"/><path d="M14 3v4h4M9.5 12h5M9.5 15.5h5"/>',
    horn: '<path d="M4 9v6h3l6 4V5L7 9H4z" fill="currentColor" stroke="none"/><path d="M17 8.5a5 5 0 0 1 0 7"/>',
    rainbow: '<path d="M4 18a8 8 0 0 1 16 0" stroke="#4d8df7" stroke-width="2.2"/><path d="M7 18a5 5 0 0 1 10 0" stroke="#46bf82" stroke-width="2.2"/><path d="M10 18a2 2 0 0 1 4 0" stroke="#ff8a3d" stroke-width="2.2"/>',
    card: '<rect x="3" y="6" width="18" height="13" rx="2.5"/><path d="M3 10h18"/>',
    settings: '<circle cx="12" cy="12" r="3.2"/><path d="M12 2.5v2.5M12 19v2.5M21.5 12H19M5 12H2.5M18.7 5.3l-1.8 1.8M7.1 16.9l-1.8 1.8M18.7 18.7l-1.8-1.8M7.1 7.1 5.3 5.3"/>',
    shield: '<path d="M12 3l7 3v5c0 4.6-3 7.8-7 9-4-1.2-7-4.4-7-9V6l7-3z"/><path d="M9 12l2 2 4-4" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/>',
    order: '<path d="M6.5 3h11v18l-2.7-1.8L12 21l-2.8-1.8L6.5 21V3z"/><path d="M9.5 8h5M9.5 11.5h5M9.5 15h3" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>',
    emptyBox: '<path d="M4 9l8-4.5L20 9v6l-8 4.5L4 15V9z"/><path d="M4 9l8 4.5L20 9M12 13.5V19.5"/><path d="M8.5 6.5l7 4M16.5 5.5l1.5-2M20 9l2-1.5" stroke-width="1.2" opacity=".6"/>',
    logo: '<polygon points="12,4.5 21,9 12,13.5 3,9" fill="currentColor"/><path d="M7.6 11.7v3c0 1.4 2 2.5 4.4 2.5s4.4-1.1 4.4-2.5v-3" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/><path d="M21 9v3.3" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"/><circle cx="21" cy="13.4" r="0.85" fill="currentColor"/>'
  };

  function svg(name, cls, style) {
    var inner = G[name] || G.grid;
    var rainbow = name === 'rainbow' || name === 'horn' || name === 'bell';
    return '<svg class="' + (cls || '') + '" style="' + (style || '') + '" viewBox="0 0 24 24" fill="none" stroke="' + (rainbow ? 'none' : 'currentColor') +
      '" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + inner + '</svg>';
  }

  // 服务入口配置（key / 文案 / 颜色 / 图标）
  var SERVICE = [
    { key: 'pay', label: '缴费', color: '#ff6b8a', icon: 'wallet' },
    { key: 'scan', label: '扫一扫', color: '#4d8df7', icon: 'scan' },
    { key: 'power', label: '用电服务', color: '#38a8f5', icon: 'lightning' },
    { key: 'water', label: '智能水电', color: '#38b6e8', icon: 'cloud' },
    { key: 'schedule', label: '课程表', color: '#5b8ff9', icon: 'calendar' },
    { key: 'shop', label: '校园购物', color: '#46bf82', icon: 'bag' },
    { key: 'life', label: '生活服务', color: '#ff8a3d', icon: 'life' },
    { key: 'memo', label: '今日备忘', color: '#ff6b8a', icon: 'note' },
    { key: 'forum', label: '学生论坛', color: '#46bf82', icon: 'chat' },
    { key: 'apps', label: '全部应用', color: '#5b8ff9', icon: 'grid' }
  ];

  // 商家与品类图标
  var SHOP = {
    canteen: 'bowl', spicy: 'lightning', tea: 'cup', market: 'bag', fruit: 'apple', print: 'printer'
  };
  var PRODUCT_ICONS = ['bowl', 'dumpling', 'rice', 'rice', 'rice', 'cup', 'rice', 'veg', 'lightning', 'lightning', 'bottle', 'rice', 'cup', 'bottle', 'cup', 'cup', 'bottle', 'bottle', 'bottle', 'snack', 'snack', 'tissue', 'pen', 'book', 'banana', 'watermelon', 'apple', 'apple', 'apple', 'scanDoc', 'printer', 'printer', 'scanDoc', 'photo', 'book', 'scanDoc'];

  function circleIcon(iconName, color, size) {
    var s = size || 52;
    return '<span class="icon-circle" style="width:' + s + 'px;height:' + s + 'px;background:' + color + '">' +
      svg(iconName, '', 'width:' + Math.round(s * 0.5) + 'px;height:' + Math.round(s * 0.5) + 'px;color:#fff') + '</span>';
  }

  return { G: G, svg: svg, SERVICE: SERVICE, SHOP: SHOP, PRODUCT_ICONS: PRODUCT_ICONS, circleIcon: circleIcon };
});
