/* ============================================================
 * seed.js —— 内置种子数据（虚拟商家 / 商品 / 论坛话题 / 通知 / 虚拟学生）
 * UMD：浏览器 window.AppSeed；Node module.exports
 * ============================================================ */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.AppSeed = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';
  var SEED_VERSION = 1;

  // 虚拟学生账号（用户名以 __ 开头，禁止登录；仅用于承载示例话题与评论）
  function virtualUsers() {
    return [
      { id: 'sys_helper', username: '__helper__', passwordHash: '!virtual', salt: '!virtual', nickname: '诚毅小助手', school: '集美大学诚毅学院', studentNo: '', avatarColor: '#d9534d', signature: '校园生活，我来帮你', createdAt: '2026-09-01T08:00:00.000Z' },
      { id: 'sys_fresh', username: '__freshman__', passwordHash: '!virtual', salt: '!virtual', nickname: '计科小透明', school: '集美大学诚毅学院', studentNo: '', avatarColor: '#4d8df7', signature: '大一新生，请多关照', createdAt: '2026-09-02T08:00:00.000Z' },
      { id: 'sys_senior', username: '__senior__', passwordHash: '!virtual', salt: '!virtual', nickname: '大三老油条', school: '集美大学诚毅学院', studentNo: '', avatarColor: '#46bf82', signature: '有问题尽管问', createdAt: '2026-09-02T08:00:00.000Z' }
    ];
  }

  function shops() {
    return [
      { id: 'shop_canteen', name: '景祺楼风味餐厅', category: '外卖', deliveryDesc: '校内自取 · 约 15 分钟', minOrder: 10, icon: 'canteen', color: '#ff8a3d', notice: '高峰时段出餐约 20 分钟，请提前下单' },
      { id: 'shop_spicy', name: '川香园麻辣香锅', category: '外卖', deliveryDesc: '配送到宿舍楼下', minOrder: 15, icon: 'spicy', color: '#d9534d', notice: '微辣 / 中辣 / 特辣，下单请备注' },
      { id: 'shop_tea', name: '一杯时光奶茶', category: '外卖', deliveryDesc: '校内自取 · 约 10 分钟', minOrder: 8, icon: 'tea', color: '#9b7ff5', notice: '第二杯半价活动进行中' },
      { id: 'shop_market', name: '诚毅校园超市', category: '超市', deliveryDesc: '满 20 元配送到宿舍', minOrder: 0, icon: 'market', color: '#4d8df7', notice: '营业时间 07:00 - 23:00' },
      { id: 'shop_fruit', name: '鲜果日记', category: '水果', deliveryDesc: '现切现做 · 约 10 分钟', minOrder: 6, icon: 'fruit', color: '#46bf82', notice: '每日新鲜到货' },
      { id: 'shop_print', name: '快易印图文', category: '文印', deliveryDesc: '到店自取', minOrder: 0, icon: 'print', color: '#38b6e8', notice: '支持 U 盘 / 网盘文件打印' }
    ];
  }

  function products() {
    var p = [];
    function add(shopId, arr) { arr.forEach(function (it, i) { p.push({ id: shopId + '_p' + (i + 1), shopId: shopId, name: it[0], price: it[1], unit: it[2], category: it[3], icon: it[4], stock: it[5] || 'normal', desc: it[6] || '' }); }); }
    add('shop_canteen', [
      ['飘香拌面', 7, '份', '主食', 'noodles', 'normal', '花生酱拌面，经典味道'],
      ['沙县扁食', 8, '份', '主食', 'dumpling', 'normal', '皮薄馅大，汤鲜味美'],
      ['番茄鸡蛋盖饭', 12, '份', '盖饭', 'rice', 'normal', ''],
      ['鱼香肉丝盖饭', 13, '份', '盖饭', 'rice', 'normal', '微辣下饭'],
      ['黄焖鸡米饭', 14, '份', '盖饭', 'rice', 'limited', '每日限量 80 份'],
      ['紫菜蛋花汤', 4, '份', '汤品', 'soup', 'normal', ''],
      ['白米饭', 2, '份', '主食', 'rice', 'normal', '']
    ]);
    add('shop_spicy', [
      ['素菜拼盘', 10, '份', '香锅', 'veg', 'normal', '十余种素菜任选'],
      ['麻辣香锅（小）', 18, '份', '香锅', 'spicy', 'normal', '含米饭，适合一人食'],
      ['麻辣香锅（大）', 26, '份', '香锅', 'spicy', 'normal', '含米饭，建议两人分享'],
      ['肥牛冒菜', 20, '份', '冒菜', 'spicy', 'normal', ''],
      ['酸梅汤', 5, '杯', '饮品', 'drink', 'soldout', '今日已售罄'],
      ['米饭', 2, '份', '主食', 'rice', 'normal', '']
    ]);
    add('shop_tea', [
      ['柠檬水', 6, '杯', '果茶', 'juice', 'normal', '清爽解腻'],
      ['珍珠奶茶', 9, '杯', '奶茶', 'tea', 'normal', '招牌黑糖珍珠'],
      ['烧仙草', 9, '杯', '甜品', 'tea', 'normal', ''],
      ['四季奶青', 10, '杯', '奶茶', 'tea', 'normal', ''],
      ['百香果双响炮', 12, '杯', '果茶', 'juice', 'limited', '每日限量 50 杯'],
      ['杨枝甘露', 14, '杯', '甜品', 'juice', 'normal', '芒果西柚西米露']
    ]);
    add('shop_market', [
      ['矿泉水', 2, '瓶', '饮料', 'water', 'normal', '550ml'],
      ['可乐', 3.5, '罐', '饮料', 'water', 'normal', '330ml'],
      ['康师傅泡面', 5, '桶', '速食', 'noodles', 'normal', '红烧牛肉味'],
      ['火腿肠', 2.5, '根', '零食', 'snack', 'normal', ''],
      ['抽纸', 4, '包', '日用', 'paper', 'normal', '3 层 100 抽'],
      ['中性笔', 2, '支', '文具', 'pen', 'normal', '黑色 0.5mm'],
      ['笔记本', 6, '本', '文具', 'book', 'normal', 'A5 / 60 页']
    ]);
    add('shop_fruit', [
      ['香蕉', 2, '根', '鲜果', 'banana', 'normal', ''],
      ['西瓜果切', 6, '盒', '果切', 'watermelon', 'normal', '约 400g'],
      ['哈密瓜果切', 7, '盒', '果切', 'fruit', 'normal', '约 400g'],
      ['苹果', 3.5, '个', '鲜果', 'apple', 'normal', '红富士'],
      ['圣女果', 8, '盒', '鲜果', 'fruit', 'limited', '今日限量 30 盒'],
      ['精品果盒', 12, '盒', '果切', 'fruit', 'normal', '三种时令水果拼盒']
    ]);
    add('shop_print', [
      ['黑白打印', 0.2, '张', '打印', 'print', 'normal', 'A4 单面'],
      ['彩色打印', 1, '张', '打印', 'print', 'normal', 'A4 单面'],
      ['复印', 0.2, '张', '复印', 'print', 'normal', 'A4'],
      ['扫描', 1, '页', '扫描', 'scan', 'normal', '发送到邮箱'],
      ['证件照', 10, '版', '摄影', 'photo', 'normal', '一寸 / 二寸可选'],
      ['论文胶装', 8, '本', '装订', 'book', 'normal', '含封面打印'],
      ['U 盘打印服务费', 2, '次', '打印', 'print', 'normal', '使用店内电脑排版']
    ]);
    return p;
  }

  function isoDaysAgo(now, days, hours) {
    var d = new Date(now.getTime() - days * 86400000 - (hours || 0) * 3600000);
    return d.toISOString();
  }

  function topics(now) {
    return [
      { id: 'topic_1', title: '求推荐！这学期公选课哪些比较好过', content: '学弟选课求助！想选几门给分高、作业少的公选课凑学分，学长学姐有推荐吗？最好是上课不点名、期末交论文的那种，先谢谢大家了！', authorId: 'sys_fresh', createdAt: isoDaysAgo(now, 6, 2), updatedAt: isoDaysAgo(now, 5, 1) },
      { id: 'topic_2', title: '景祺楼新档口测评：黄焖鸡真香', content: '今天试了景祺楼新开的黄焖鸡档口，14 块一份分量很足，鸡肉嫩、汤汁拌饭绝了，就是下课高峰要排队。吃过的同学觉得怎么样？', authorId: 'sys_senior', createdAt: isoDaysAgo(now, 5, 3), updatedAt: isoDaysAgo(now, 4, 2) },
      { id: 'topic_3', title: '图书馆期末占座也太卷了吧', content: '早上八点到图书馆已经快满了，还有座位上放着书人却不在的。建议大家离开超过半小时把东西收一下，互相体谅。', authorId: 'sys_fresh', createdAt: isoDaysAgo(now, 4, 1), updatedAt: isoDaysAgo(now, 3, 2) },
      { id: 'topic_4', title: '校园网怎么办理？宿舍宽带求攻略', content: '刚住校，宿舍想办宽带，校园网账号在哪开通、网速怎么样、一个月多少钱，求一份办理攻略，感谢！', authorId: 'sys_fresh', createdAt: isoDaysAgo(now, 3, 4), updatedAt: isoDaysAgo(now, 2, 1) },
      { id: 'topic_5', title: '专升本上岸诚毅，有同专业的吗', content: '退役士兵专升本上岸计算机科学与技术专业，马上开学了有点期待也有点慌，有没有同专业的同学认识一下，一起学习！', authorId: 'sys_helper', createdAt: isoDaysAgo(now, 2, 2), updatedAt: isoDaysAgo(now, 1, 3) },
      { id: 'topic_6', title: '周末在厦门可以去哪玩', content: '第一次在厦门过周末，除了鼓浪屿和曾厝垵还有哪里值得去？想看海、吃海鲜，预算 100 以内，求本地同学带路。', authorId: 'sys_senior', createdAt: isoDaysAgo(now, 1, 5), updatedAt: isoDaysAgo(now, 0, 6) }
    ];
  }

  function replies(now) {
    return [
      { id: 'reply_1', topicId: 'topic_1', content: '推荐影视鉴赏和大学生心理健康，基本不点名，期末一篇论文搞定。', authorId: 'sys_senior', createdAt: isoDaysAgo(now, 5, 5) },
      { id: 'reply_2', topicId: 'topic_1', content: '同问！码住等更多推荐。', authorId: 'sys_helper', createdAt: isoDaysAgo(now, 5, 2) },
      { id: 'reply_3', topicId: 'topic_2', content: '昨天刚吃过，确实可以，就是有点咸，记得让阿姨少放盐。', authorId: 'sys_fresh', createdAt: isoDaysAgo(now, 4, 4) },
      { id: 'reply_4', topicId: 'topic_3', content: '支持，占座不文明，图书馆是大家的。', authorId: 'sys_senior', createdAt: isoDaysAgo(now, 3, 5) },
      { id: 'reply_5', topicId: 'topic_4', content: '带学生证到信息中心开通，宿舍宽带运营商会来摆摊，多对比价格。', authorId: 'sys_senior', createdAt: isoDaysAgo(now, 2, 4) },
      { id: 'reply_6', topicId: 'topic_5', content: '欢迎新同学！计算机专业在景祺楼上课，开学见。', authorId: 'sys_senior', createdAt: isoDaysAgo(now, 1, 5) },
      { id: 'reply_7', topicId: 'topic_6', content: '推荐集美学村龙舟池散步，傍晚特别美，还不要门票。', authorId: 'sys_fresh', createdAt: isoDaysAgo(now, 0, 8) }
    ];
  }

  function notices() {
    return [
      { id: 'notice_1', iconType: 'rainbow', content: '自己上传照片，定制校园卡卡面、校园码背景和课表皮肤', timeText: '', createdAt: 0 },
      { id: 'notice_2', iconType: 'horn', content: '同学你好，学生权益中心有新权益上架，点击查看详情', timeText: '1天前', createdAt: 1 },
      { id: 'notice_3', iconType: 'horn', content: '本周六凌晨 0:00-2:00 校园系统维护，部分服务暂不可用', timeText: '2天前', createdAt: 2 }
    ];
  }

  function buildSeed(now) {
    now = now || new Date();
    return {
      users: virtualUsers(),
      shops: shops(),
      products: products(),
      topics: topics(now),
      replies: replies(now),
      notices: notices(),
      settings: [
        { key: 'semesterStart', value: '2026-09-07' },
        { key: 'cardBalance', value: 14.18 }
      ],
      meta: [{ key: 'seedVersion', value: SEED_VERSION }, { key: 'seededAt', value: now.toISOString() }]
    };
  }

  return { SEED_VERSION: SEED_VERSION, buildSeed: buildSeed };
});
