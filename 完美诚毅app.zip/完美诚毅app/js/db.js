/* ============================================================
 * db.js —— 仓储层（MemRepo / IDBRepo）+ 业务服务层 + 备份恢复
 * UMD：浏览器 window.AppDB；Node 下导出内存版与服务工厂供自动化测试
 * ============================================================ */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) {
    module.exports = factory(require('./core.js'), require('./seed.js'));
  } else {
    root.AppDB = factory(root.AppCore, root.AppSeed);
  }
})(typeof self !== 'undefined' ? self : this, function (Core, Seed) {
  'use strict';

  var DB_NAME = 'chengyi_campus';
  var DB_VERSION = 1;

  var STORES = [
    { name: 'meta', key: 'key' },
    { name: 'settings', key: 'key' },
    { name: 'users', key: 'id', indexes: [{ name: 'username', keyPath: 'username', unique: true }] },
    { name: 'session', key: 'key' },
    { name: 'courses', key: 'id', indexes: [{ name: 'userId', keyPath: 'userId' }] },
    { name: 'memos', key: 'id', indexes: [{ name: 'userId', keyPath: 'userId' }] },
    { name: 'shops', key: 'id' },
    { name: 'products', key: 'id', indexes: [{ name: 'shopId', keyPath: 'shopId' }] },
    { name: 'cart', key: 'id', indexes: [{ name: 'userId', keyPath: 'userId' }] },
    { name: 'orders', key: 'id', indexes: [{ name: 'userId', keyPath: 'userId' }] },
    { name: 'topics', key: 'id', indexes: [{ name: 'authorId', keyPath: 'authorId' }] },
    { name: 'replies', key: 'id', indexes: [{ name: 'topicId', keyPath: 'topicId' }] },
    { name: 'notices', key: 'id' },
    { name: 'noticeDismiss', key: 'id' },
    { name: 'snapshots', key: 'id', indexes: [{ name: 'createdAt', keyPath: 'createdAt' }] }
  ];
  var KEYPATH = {};
  STORES.forEach(function (s) { KEYPATH[s.name] = s.key; });

  function clone(v) { return JSON.parse(JSON.stringify(v)); }

  function defaultAvatar(color) {
    var c = color || '#4d8df7';
    var svg = "<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 80 80'>" +
      "<rect width='80' height='80' rx='40' fill='" + c + "'/>" +
      "<circle cx='40' cy='32' r='14' fill='#ffffff' opacity='.95'/>" +
      "<path d='M13 70c5-16 16-23 27-23s22 7 27 23z' fill='#ffffff' opacity='.95'/></svg>";
    return 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg);
  }

  /* ============================ 内存仓储（测试用） ============================ */
  function MemRepo() {
    this.tables = {};
    STORES.forEach(function (s) { this.tables[s.name] = new Map(); }.bind(this));
  }
  MemRepo.prototype.getAll = async function (store) { return Array.from(this.tables[store].values()).map(clone); };
  MemRepo.prototype.get = async function (store, key) { var v = this.tables[store].get(key); return v ? clone(v) : undefined; };
  MemRepo.prototype.put = async function (store, value) { this.tables[store].set(value[KEYPATH[store]], clone(value)); return clone(value); };
  MemRepo.prototype.bulkPut = async function (store, arr) { arr.forEach(function (v) { this.tables[store].set(v[KEYPATH[store]], clone(v)); }.bind(this)); };
  MemRepo.prototype.del = async function (store, key) { this.tables[store].delete(key); };
  MemRepo.prototype.clear = async function (store) { this.tables[store].clear(); };
  MemRepo.prototype.exportAll = async function () {
    var data = {};
    Object.keys(this.tables).forEach(function (name) { data[name] = Array.from(this.tables[name].values()).map(clone); }.bind(this));
    return data;
  };
  // 原子替换：中途任何错误都回滚到替换前
  MemRepo.prototype.replaceAll = async function (data) {
    var backup = {};
    Object.keys(this.tables).forEach(function (name) { backup[name] = new Map(this.tables[name]); }.bind(this));
    try {
      Object.keys(data).forEach(function (name) {
        if (!this.tables[name]) throw new Error('未知的数据表: ' + name);
        if (!Array.isArray(data[name])) throw new Error('数据表内容不是数组: ' + name);
        var m = this.tables[name];
        m.clear();
        var key = KEYPATH[name];
        data[name].forEach(function (row) {
          if (!row || typeof row !== 'object' || row[key] == null) throw new Error('数据表 ' + name + ' 存在缺少主键的记录');
          m.set(row[key], clone(row));
        });
      }.bind(this));
    } catch (e) {
      Object.keys(backup).forEach(function (name) { this.tables[name] = backup[name]; }.bind(this));
      throw e;
    }
  };

  /* ============================ IndexedDB 仓储（浏览器） ============================ */
  function IDBRepo(idbFactory) { this.idbFactory = idbFactory; this.db = null; }
  IDBRepo.prototype.open = function () {
    var self = this;
    return new Promise(function (resolve, reject) {
      var req = self.idbFactory.open(DB_NAME, DB_VERSION);
      req.onupgradeneeded = function (e) {
        var db = e.target.result;
        STORES.forEach(function (s) {
          if (!db.objectStoreNames.contains(s.name)) {
            var os = db.createObjectStore(s.name, { keyPath: s.key });
            (s.indexes || []).forEach(function (ix) { os.createIndex(ix.name, ix.keyPath, { unique: !!ix.unique }); });
          }
        });
      };
      req.onsuccess = function (e) { self.db = e.target.result; resolve(); };
      req.onerror = function () { reject(req.error); };
    });
  };
  IDBRepo.prototype._store = function (store, mode) { return this.db.transaction(store, mode).objectStore(store); };
  IDBRepo.prototype.getAll = function (store) {
    return new Promise(function (resolve, reject) {
      var r = this._store(store, 'readonly').getAll();
      r.onsuccess = function () { resolve(r.result); };
      r.onerror = function () { reject(r.error); };
    }.bind(this));
  };
  IDBRepo.prototype.get = function (store, key) {
    return new Promise(function (resolve, reject) {
      var r = this._store(store, 'readonly').get(key);
      r.onsuccess = function () { resolve(r.result); };
      r.onerror = function () { reject(r.error); };
    }.bind(this));
  };
  IDBRepo.prototype.put = function (store, value) {
    return new Promise(function (resolve, reject) {
      var r = this._store(store, 'readwrite').put(value);
      r.onsuccess = function () { resolve(value); };
      r.onerror = function () { reject(r.error); };
    }.bind(this));
  };
  IDBRepo.prototype.bulkPut = function (store, arr) {
    return new Promise(function (resolve, reject) {
      var t = this.db.transaction(store, 'readwrite');
      var os = t.objectStore(store);
      arr.forEach(function (v) { os.put(v); });
      t.oncomplete = function () { resolve(); };
      t.onerror = function () { reject(t.error); };
      t.onabort = function () { reject(t.error); };
    }.bind(this));
  };
  IDBRepo.prototype.del = function (store, key) {
    return new Promise(function (resolve, reject) {
      var r = this._store(store, 'readwrite').delete(key);
      r.onsuccess = function () { resolve(); };
      r.onerror = function () { reject(r.error); };
    }.bind(this));
  };
  IDBRepo.prototype.clear = function (store) {
    return new Promise(function (resolve, reject) {
      var r = this._store(store, 'readwrite').clear();
      r.onsuccess = function () { resolve(); };
      r.onerror = function () { reject(r.error); };
    }.bind(this));
  };
  IDBRepo.prototype.exportAll = function () {
    var self = this;
    return Promise.all(STORES.map(function (s) { return self.getAll(s.name); })).then(function (lists) {
      var data = {};
      STORES.forEach(function (s, i) { data[s.name] = lists[i]; });
      return data;
    });
  };
  // 单事务原子替换：任一错误事务 abort，IndexedDB 自动回滚
  IDBRepo.prototype.replaceAll = function (data) {
    var self = this;
    return new Promise(function (resolve, reject) {
      var names = Object.keys(data).filter(function (n) { return STORES.some(function (s) { return s.name === n; }); });
      names.forEach(function (name) {
        if (!Array.isArray(data[name])) throw new Error('数据表内容不是数组: ' + name);
        data[name].forEach(function (row) { if (!row || row[KEYPATH[name]] == null) throw new Error('数据表 ' + name + ' 存在缺少主键的记录'); });
      });
      var t = self.db.transaction(names, 'readwrite');
      t.oncomplete = function () { resolve(); };
      t.onerror = function () { reject(t.error); };
      t.onabort = function () { reject(t.error || new Error('恢复事务已中止')); };
      names.forEach(function (name) {
        var os = t.objectStore(name);
        os.clear();
        data[name].forEach(function (row) { os.put(row); });
      });
    });
  };

  /* ============================ 业务服务层 ============================ */
  function createServices(repo) {
    var svc = {};

    function all(store) { return repo.getAll(store); }
    function find(store, id) { return repo.get(store, id); }
    function put(store, v) { return repo.put(store, v); }
    function nowIso() { return new Date().toISOString(); }
    function fail(errors) { var e = new Error('validation'); e.errors = errors; throw e; }
    function isVirtual(u) { return !u || String(u.username).indexOf('__') === 0 || u.passwordHash === '!virtual'; }

    function safeUser(u) {
      if (!u) return null;
      var o = clone(u);
      delete o.passwordHash;
      delete o.salt;
      return o;
    }
    async function userMap() {
      var users = await all('users');
      var m = {};
      users.forEach(function (u) { m[u.id] = u; });
      return m;
    }
    function attachAuthor(obj, um, authorField) {
      var u = um[obj.authorId];
      obj[authorField || 'authorName'] = u ? u.nickname : '已注销用户';
      obj.authorAvatar = u ? (u.avatar || defaultAvatar(u.avatarColor)) : defaultAvatar('#bbb');
      return obj;
    }

    /* ---------- 种子 ---------- */
    svc.seed = {
      ensure: async function () {
        var v = await find('meta', 'seedVersion');
        if (v && v.value === Seed.SEED_VERSION) return false;
        var seed = Seed.buildSeed(new Date());
        seed.users.forEach(function (u) { u.avatar = defaultAvatar(u.avatarColor); });
        var stores = ['users', 'shops', 'products', 'topics', 'replies', 'notices', 'settings', 'meta'];
        for (var i = 0; i < stores.length; i++) {
          await repo.bulkPut(stores[i], seed[stores[i]]);
        }
        return true;
      }
    };

    /* ---------- 设置 ---------- */
    svc.settings = {
      get: async function (key, def) { var row = await find('settings', key); return row ? row.value : def; },
      set: async function (key, value) { await put('settings', { key: key, value: value }); return value; },
      semesterStart: async function () { return this.get('semesterStart', Core.DEFAULT_SEMESTER_START); },
      balance: async function () { return Number(await this.get('cardBalance', Core.DEFAULT_BALANCE)); },
      recharge: async function (delta) {
        delta = Number(delta);
        if (!(delta > 0)) throw new Error('充值金额不正确');
        var b = Core.round2(Number(await this.balance()) + delta);
        await this.set('cardBalance', b);
        return b;
      }
    };

    /* ---------- 账户 ---------- */
    svc.auth = {
      register: async function (form) {
        var check = Core.validateRegisterForm(form || {});
        if (!check.ok) fail(check.errors);
        var username = Core.trim(form.username);
        if (username.indexOf('__') === 0) fail({ username: '用户名不能以双下划线开头' });
        var users = await all('users');
        if (users.some(function (u) { return u.username === username; })) fail({ username: '该用户名已被注册' });
        var salt = Core.randomSalt();
        var passwordHash = await Core.hashPassword(form.password, salt);
        var color = Core.COURSE_COLORS[users.length % Core.COURSE_COLORS.length].value;
        var user = {
          id: Core.uid('u'), username: username, passwordHash: passwordHash, salt: salt,
          nickname: Core.trim(form.nickname), school: Core.SCHOOL_NAME,
          studentNo: Core.trim(form.studentNo || ''), avatar: defaultAvatar(color), avatarColor: color,
          signature: '', createdAt: nowIso(), lastLoginAt: nowIso()
        };
        await put('users', user);
        await put('session', { key: 'current', userId: user.id, at: nowIso() });
        return safeUser(user);
      },
      login: async function (username, password) {
        username = Core.trim(username);
        var users = await all('users');
        var u = users.filter(function (x) { return x.username === username; })[0];
        if (!u || isVirtual(u)) fail({ username: '用户名或密码不正确' });
        var hash = await Core.hashPassword(password || '', u.salt);
        if (hash !== u.passwordHash) fail({ password: '用户名或密码不正确' });
        u.lastLoginAt = nowIso();
        await put('users', u);
        await put('session', { key: 'current', userId: u.id, at: nowIso() });
        return safeUser(u);
      },
      logout: async function () { await repo.del('session', 'current'); },
      current: async function () {
        var s = await find('session', 'current');
        if (!s) return null;
        var u = await find('users', s.userId);
        return u && !isVirtual(u) ? safeUser(u) : null;
      },
      updateProfile: async function (userId, patch) {
        var u = await find('users', userId);
        if (!u) throw new Error('用户不存在');
        if (patch.nickname != null) {
          var n = Core.trim(patch.nickname);
          if (!n) throw new Error('昵称不能为空');
          if (n.length > 12) throw new Error('昵称不能超过 12 字');
          u.nickname = n;
        }
        if (patch.signature != null) u.signature = Core.trim(patch.signature).slice(0, 30);
        if (patch.studentNo != null) {
          var no = Core.trim(patch.studentNo);
          if (no && !/^[0-9A-Za-z]{0,20}$/.test(no)) throw new Error('学号格式不正确');
          u.studentNo = no;
        }
        if (patch.school != null && Core.trim(patch.school)) u.school = Core.trim(patch.school);
        await put('users', u);
        return safeUser(u);
      },
      updateAvatar: async function (userId, dataURL) {
        var u = await find('users', userId);
        if (!u) throw new Error('用户不存在');
        u.avatar = dataURL;
        await put('users', u);
        return safeUser(u);
      },
      removeAvatar: async function (userId) {
        var u = await find('users', userId);
        if (!u) throw new Error('用户不存在');
        u.avatar = defaultAvatar(u.avatarColor);
        await put('users', u);
        return safeUser(u);
      }
    };

    /* ---------- 课程 ---------- */
    svc.course = {
      list: async function (userId) {
        return (await all('courses')).filter(function (c) { return c.userId === userId; });
      },
      conflicts: async function (userId, data, semStart) {
        var mine = await this.list(userId);
        return Core.findConflicts(data, mine, semStart);
      },
      add: async function (userId, data) {
        var check = Core.validateCourseInput(data);
        if (!check.ok) fail(check.errors);
        var c = Object.assign({}, data, {
          id: Core.uid('c'), userId: userId,
          teacher: Core.trim(data.teacher || ''), note: Core.trim(data.note || ''),
          createdAt: nowIso(), updatedAt: nowIso()
        });
        await put('courses', c);
        return c;
      },
      update: async function (id, userId, data) {
        var old = await find('courses', id);
        if (!old || old.userId !== userId) throw new Error('课程不存在');
        var check = Core.validateCourseInput(data);
        if (!check.ok) fail(check.errors);
        var c = Object.assign({}, old, data, { teacher: Core.trim(data.teacher || ''), note: Core.trim(data.note || ''), updatedAt: nowIso() });
        await put('courses', c);
        return c;
      },
      remove: async function (id, userId) {
        var old = await find('courses', id);
        if (!old || old.userId !== userId) throw new Error('课程不存在');
        await repo.del('courses', id);
      },
      importMany: async function (userId, values) {
        var rows = values.map(function (v) {
          return Object.assign({}, v, {
            id: Core.uid('c'), userId: userId, teacher: v.teacher || '', note: v.note || '',
            createdAt: nowIso(), updatedAt: nowIso()
          });
        });
        await repo.bulkPut('courses', rows);
        return rows;
      },
      onDate: async function (userId, dateStr, semStart) {
        var mine = await this.list(userId);
        return Core.coursesAt(mine, dateStr, semStart);
      },
      week: async function (userId, monday, semStart) {
        var mine = await this.list(userId);
        var days = [];
        for (var i = 0; i < 7; i++) {
          var d = Core.addDays(monday, i);
          days.push({ date: d, weekday: i + 1, courses: Core.coursesAt(mine, d, semStart) });
        }
        return days;
      },
      next: async function (userId, dateStr, hm, semStart) {
        var today = Core.coursesAt(await this.list(userId), dateStr, semStart);
        var cur = Core.hmToMinutes(hm);
        return today.filter(function (c) { return Core.hmToMinutes(c.endTime) > cur; })
          .sort(function (a, b) { return Core.hmToMinutes(a.startTime) - Core.hmToMinutes(b.startTime); })[0] || null;
      }
    };

    /* ---------- 备忘 ---------- */
    svc.memo = {
      list: async function (userId) {
        return (await all('memos')).filter(function (m) { return m.userId === userId; })
          .sort(function (a, b) { return (a.done - b.done) || (b.createdAt < a.createdAt ? 1 : -1); });
      },
      add: async function (userId, content) {
        content = Core.trim(content);
        if (!content) throw new Error('备忘内容不能为空');
        var m = { id: Core.uid('m'), userId: userId, content: content, done: 0, createdAt: nowIso(), completedAt: '' };
        await put('memos', m);
        return m;
      },
      toggle: async function (id, userId) {
        var m = await find('memos', id);
        if (!m || m.userId !== userId) throw new Error('备忘不存在');
        m.done = m.done ? 0 : 1;
        m.completedAt = m.done ? nowIso() : '';
        await put('memos', m);
        return m;
      },
      update: async function (id, userId, content) {
        content = Core.trim(content);
        if (!content) throw new Error('备忘内容不能为空');
        var m = await find('memos', id);
        if (!m || m.userId !== userId) throw new Error('备忘不存在');
        m.content = content;
        await put('memos', m);
        return m;
      },
      remove: async function (id, userId) {
        var m = await find('memos', id);
        if (!m || m.userId !== userId) throw new Error('备忘不存在');
        await repo.del('memos', id);
      },
      openCount: async function (userId) {
        return (await all('memos')).filter(function (m) { return m.userId === userId && !m.done; }).length;
      }
    };

    /* ---------- 商家 / 商品 ---------- */
    svc.shop = {
      list: async function (category) {
        var s = await all('shops');
        return category && category !== '全部' ? s.filter(function (x) { return x.category === category; }) : s;
      },
      byId: async function (id) { return find('shops', id); },
      products: async function (shopId) {
        return (await all('products')).filter(function (p) { return p.shopId === shopId; });
      },
      productById: async function (id) { return find('products', id); }
    };

    /* ---------- 购物车 ---------- */
    svc.cart = {
      list: async function (userId) {
        return (await all('cart')).filter(function (c) { return c.userId === userId; });
      },
      addItem: async function (userId, product, qty, force) {
        qty = qty || 1;
        if (product.stock === 'soldout') throw new Error('该商品已售罄');
        var items = await this.list(userId);
        if (items.length && items[0].shopId !== product.shopId && !force) {
          var shop = await svc.shop.byId(items[0].shopId);
          return { ok: false, code: 'shop_conflict', shopName: shop ? shop.name : '另一家店' };
        }
        if (items.length && items[0].shopId !== product.shopId && force) {
          await this.clear(userId);
          items = [];
        }
        var same = items.filter(function (x) { return x.productId === product.id; })[0];
        if (same) {
          same.qty += qty;
          await put('cart', same);
        } else {
          await put('cart', {
            id: Core.uid('cart'), userId: userId, shopId: product.shopId, productId: product.id,
            name: product.name, price: product.price, qty: qty, remark: ''
          });
        }
        return { ok: true };
      },
      setQty: async function (id, userId, qty) {
        var item = await find('cart', id);
        if (!item || item.userId !== userId) throw new Error('购物车商品不存在');
        if (qty <= 0) { await repo.del('cart', id); return; }
        item.qty = Math.floor(qty);
        await put('cart', item);
        return item;
      },
      setRemark: async function (id, userId, remark) {
        var item = await find('cart', id);
        if (!item || item.userId !== userId) throw new Error('购物车商品不存在');
        item.remark = Core.trim(remark).slice(0, 50);
        await put('cart', item);
        return item;
      },
      remove: async function (id, userId) {
        var item = await find('cart', id);
        if (!item || item.userId !== userId) throw new Error('购物车商品不存在');
        await repo.del('cart', id);
      },
      clear: async function (userId) {
        var items = await this.list(userId);
        for (var i = 0; i < items.length; i++) await repo.del('cart', items[i].id);
      },
      summary: async function (userId) {
        var items = await this.list(userId);
        return { items: items, shopId: items[0] ? items[0].shopId : null, total: Core.sumCart(items) };
      }
    };

    /* ---------- 订单 ---------- */
    svc.order = {
      create: async function (userId, pickupNote) {
        var sum = await svc.cart.summary(userId);
        if (!sum.items.length) throw new Error('购物车是空的');
        var shop = await svc.shop.byId(sum.shopId);
        if (!shop) throw new Error('商家信息不存在');
        var order = {
          id: Core.uid('o'), orderNo: Core.makeOrderNo(), userId: userId,
          shopId: shop.id, shopName: shop.name,
          items: sum.items.map(function (i) { return { productId: i.productId, name: i.name, price: i.price, qty: i.qty, remark: i.remark }; }),
          total: sum.total, pickupNote: Core.trim(pickupNote || '').slice(0, 100),
          status: 'pending', createdAt: nowIso(), completedAt: '',
          logs: [{ status: 'pending', at: nowIso() }]
        };
        await put('orders', order);
        await svc.cart.clear(userId);
        return order;
      },
      list: async function (userId, status) {
        var list = (await all('orders')).filter(function (o) { return o.userId === userId && (!status || o.status === status); });
        return list.sort(function (a, b) { return a.createdAt < b.createdAt ? 1 : -1; });
      },
      byId: async function (id, userId) {
        var o = await find('orders', id);
        if (!o || o.userId !== userId) throw new Error('订单不存在');
        return o;
      },
      advance: async function (id, userId) {
        var o = await this.byId(id, userId);
        var next = Core.nextOrderStatus(o.status);
        if (!next) return o;
        o.status = next;
        o.logs.push({ status: next, at: nowIso() });
        if (next === 'done') o.completedAt = nowIso();
        await put('orders', o);
        return o;
      },
      pendingCount: async function (userId) {
        return (await all('orders')).filter(function (o) { return o.userId === userId && o.status !== 'done'; }).length;
      }
    };

    /* ---------- 论坛 ---------- */
    svc.forum = {
      topics: async function () {
        var um = await userMap();
        var replies = await all('replies');
        var counts = {};
        replies.forEach(function (r) { counts[r.topicId] = (counts[r.topicId] || 0) + 1; });
        return (await all('topics'))
          .map(function (t) {
            t = clone(t);
            attachAuthor(t, um);
            t.replyCount = counts[t.id] || 0;
            return t;
          })
          .sort(function (a, b) { return a.createdAt < b.createdAt ? 1 : -1; });
      },
      topic: async function (id) {
        var t = await find('topics', id);
        if (!t) throw new Error('话题不存在或已被删除');
        var um = await userMap();
        t = clone(t);
        attachAuthor(t, um);
        var replies = (await all('replies')).filter(function (r) { return r.topicId === id; })
          .sort(function (a, b) { return a.createdAt < b.createdAt ? -1 : 1; })
          .map(function (r) { return attachAuthor(clone(r), um); });
        t.replies = replies;
        t.replyCount = replies.length;
        return t;
      },
      createTopic: async function (userId, title, content) {
        var check = Core.validateTopic(title, content);
        if (!check.ok) fail(check.errors);
        var t = { id: Core.uid('t'), title: Core.trim(title), content: Core.trim(content), authorId: userId, createdAt: nowIso(), updatedAt: nowIso() };
        await put('topics', t);
        return t;
      },
      createReply: async function (userId, topicId, content) {
        var check = Core.validateReply(content);
        if (!check.ok) throw new Error(check.error);
        var t = await find('topics', topicId);
        if (!t) throw new Error('话题不存在');
        var r = { id: Core.uid('r'), topicId: topicId, content: Core.trim(content), authorId: userId, createdAt: nowIso() };
        await put('replies', r);
        t.updatedAt = nowIso();
        await put('topics', t);
        return r;
      },
      deleteReply: async function (replyId, userId) {
        var r = await find('replies', replyId);
        if (!r) throw new Error('评论不存在');
        if (r.authorId !== userId) throw new Error('只能删除自己发表的评论');
        await repo.del('replies', replyId);
      },
      myTopics: async function (userId) {
        var um = await userMap();
        return (await all('topics')).filter(function (t) { return t.authorId === userId; })
          .sort(function (a, b) { return a.createdAt < b.createdAt ? 1 : -1; })
          .map(function (t) { return attachAuthor(clone(t), um); });
      },
      myReplies: async function (userId) {
        var um = await userMap();
        var topics = {};
        (await all('topics')).forEach(function (t) { topics[t.id] = t.title; });
        return (await all('replies')).filter(function (r) { return r.authorId === userId; })
          .sort(function (a, b) { return a.createdAt < b.createdAt ? -1 : 1; })
          .map(function (r) { r = attachAuthor(clone(r), um); r.topicTitle = topics[r.topicId] || '话题已删除'; return r; });
      },
      recentCount: async function (days) {
        var since = Date.now() - (days || 7) * 86400000;
        return (await all('topics')).filter(function (t) { return new Date(t.createdAt).getTime() >= since; }).length;
      }
    };

    /* ---------- 通知 ---------- */
    svc.notice = {
      list: async function (userId) {
        var dismissed = {};
        (await all('noticeDismiss')).forEach(function (d) { dismissed[d.id] = true; });
        return (await all('notices'))
          .filter(function (n) { return !dismissed[userId + '__' + n.id]; })
          .sort(function (a, b) { return a.createdAt - b.createdAt; });
      },
      dismiss: async function (userId, noticeId) {
        await put('noticeDismiss', { id: userId + '__' + noticeId, userId: userId, noticeId: noticeId, at: nowIso() });
      }
    };

    /* ---------- 备份 / 快照 / 恢复 ---------- */
    svc.backup = {
      export: async function () {
        var data = {};
        for (var i = 0; i < Core.BACKUP_STORES.length; i++) {
          data[Core.BACKUP_STORES[i]] = await repo.getAll(Core.BACKUP_STORES[i]);
        }
        return { app: 'chengyi-campus', name: Core.APP_NAME, version: Core.DATA_VERSION, exportedAt: nowIso(), data: data };
      },
      inspect: function (text) {
        var obj;
        try { obj = JSON.parse(text); } catch (e) { return { ok: false, error: '文件不是合法的 JSON，可能已损坏' }; }
        var v = Core.validateBackup(obj);
        if (!v.ok) return { ok: false, error: v.error };
        return { ok: true, backup: obj, summary: Core.backupSummary(obj.data), exportedAt: obj.exportedAt };
      },
      _snapshot: async function (reason) {
        var data = {};
        var names = STORES.map(function (s) { return s.name; }).filter(function (n) { return n !== 'snapshots'; });
        for (var i = 0; i < names.length; i++) data[names[i]] = await repo.getAll(names[i]);
        var snap = { id: Core.uid('snap'), createdAt: nowIso(), reason: reason, data: data };
        await put('snapshots', snap);
        var all = await repo.getAll('snapshots');
        all.sort(function (a, b) { return a.createdAt < b.createdAt ? -1 : 1; });
        var extra = all.slice(0, Math.max(0, all.length - 3));
        for (var j = 0; j < extra.length; j++) await repo.del('snapshots', extra[j].id);
        return snap;
      },
      restore: async function (backup) {
        var v = Core.validateBackup(backup);
        if (!v.ok) throw new Error(v.error);
        await this._snapshot('before_restore');
        await repo.replaceAll(backup.data);
        return true;
      },
      listSnapshots: async function () {
        return (await repo.getAll('snapshots')).sort(function (a, b) { return a.createdAt < b.createdAt ? 1 : -1; });
      },
      rollback: async function (snapshotId) {
        var snap = await repo.get('snapshots', snapshotId);
        if (!snap) throw new Error('快照不存在');
        await this._snapshot('before_rollback');
        await repo.replaceAll(snap.data);
        return true;
      }
    };

    return svc;
  }

  /* ---------- 浏览器启动 ---------- */
  async function boot(idbFactory) {
    var repo = new IDBRepo(idbFactory);
    await repo.open();
    var svc = createServices(repo);
    await svc.seed.ensure();
    return { repo: repo, svc: svc };
  }

  return {
    DB_NAME: DB_NAME, DB_VERSION: DB_VERSION, STORES: STORES,
    defaultAvatar: defaultAvatar,
    MemRepo: MemRepo, IDBRepo: IDBRepo, createServices: createServices, boot: boot,
    version: 1
  };
});
