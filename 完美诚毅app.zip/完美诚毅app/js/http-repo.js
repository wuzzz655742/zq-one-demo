/* ============================================================
 * http-repo.js —— 远程仓储（HTTP → 后端 Flask → MySQL）
 *
 * 实现与 db.js 中 IDBRepo / MemRepo 完全相同的仓储接口：
 *   open / getAll / get / put / bulkPut / del / clear / exportAll / replaceAll
 * 业务服务层 createServices(repo) 无需任何改动即可在 MySQL 上运行。
 *
 * 浏览器：本文件在 db.js 之后加载，会自动包装 window.AppDB.boot，
 *         优先连接后端 MySQL；后端不可达时回退 IndexedDB 并提示。
 *         可用 URL 参数控制：?db=auto（默认）/ ?db=http（强制，失败报错）/ ?db=local（强制本地）
 * Node  ：导出 { HttpRepo }，供端到端测试注入 baseUrl/fetch。
 * ============================================================ */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) {
    module.exports = factory();
  } else {
    root.AppDBHttp = factory();
  }
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  function HttpRepo(opts) {
    opts = opts || {};
    // 浏览器默认同源（相对路径）；Node 测试传入完整地址
    this.baseUrl = opts.baseUrl || '';
    if (opts.fetch) {
      this.fetchImpl = opts.fetch;
    } else {
      // 浏览器原生 fetch 必须绑定到全局对象，否则解引用调用会抛 Illegal invocation
      var g = typeof globalThis !== 'undefined' ? globalThis
        : (typeof self !== 'undefined' ? self : this);
      this.fetchImpl = (typeof g.fetch === 'function') ? g.fetch.bind(g) : null;
    }
  }

  HttpRepo.prototype._request = async function (method, path, body) {
    if (!this.fetchImpl) throw new Error('当前环境不支持 fetch');
    var options = { method: method, headers: {} };
    if (body !== undefined) {
      options.headers['Content-Type'] = 'application/json';
      options.body = JSON.stringify(body);
    }
    var res, json;
    try {
      res = await this.fetchImpl(this.baseUrl + path, options);
    } catch (networkErr) {
      throw new Error('无法连接后端服务（' + (networkErr && networkErr.message) + '）');
    }
    try {
      json = await res.json();
    } catch (e) {
      throw new Error('后端返回了无法解析的内容（HTTP ' + res.status + '）');
    }
    if (!res.ok || !json || json.ok === false) {
      var err = new Error((json && json.error) || ('请求失败（HTTP ' + res.status + '）'));
      err.status = res.status;
      throw err;
    }
    return json;
  };

  HttpRepo.prototype.open = async function () {
    var r = await this._request('GET', '/api/health');
    this._health = r;
    return r;
  };

  HttpRepo.prototype.getAll = async function (store) {
    var r = await this._request('GET', '/api/tables/' + encodeURIComponent(store));
    return r.data || [];
  };

  // 与 IDBRepo/MemRepo 契约一致：查不到记录返回 undefined（后端 404），其他错误才抛出
  HttpRepo.prototype.get = async function (store, key) {
    var path = '/api/tables/' + encodeURIComponent(store) + '/' + encodeURIComponent(key);
    var r;
    try {
      r = await this._request('GET', path);
    } catch (e) {
      if (e.status === 404) return undefined;
      throw e;
    }
    return r.data === null || r.data === undefined ? undefined : r.data;
  };

  HttpRepo.prototype.put = async function (store, value) {
    var r = await this._request('PUT', '/api/tables/' + encodeURIComponent(store), value);
    return r.data || value;
  };

  HttpRepo.prototype.bulkPut = async function (store, arr) {
    await this._request('POST', '/api/tables/' + encodeURIComponent(store) + '/bulk', arr);
  };

  HttpRepo.prototype.del = async function (store, key) {
    await this._request('DELETE', '/api/tables/' + encodeURIComponent(store) + '/' + encodeURIComponent(key));
  };

  HttpRepo.prototype.clear = async function (store) {
    await this._request('POST', '/api/tables/' + encodeURIComponent(store) + '/clear');
  };

  HttpRepo.prototype.exportAll = async function () {
    var r = await this._request('GET', '/api/export');
    return r.data;
  };

  // 整库替换：后端在单事务内 清空->重写，任一步失败整体回滚
  HttpRepo.prototype.replaceAll = async function (data) {
    await this._request('POST', '/api/replace', { data: data });
  };

  /* ============================================================
   * 一次性迁移：把源仓储（通常是浏览器 IndexedDB）的全量数据
   * 经目标仓储（HttpRepo → MySQL）的整库事务替换写入数据库。
   * 只读取源、不删除源；目标在单事务内清空重写，失败整体回滚。
   * ============================================================ */

  // 统计本地数据中的“个人内容”（种子虚拟用户 __ 开头、商家/商品等不计入）
  function summarizeMigration(data) {
    var STORE_NAMES = ['meta', 'settings', 'users', 'session', 'courses', 'memos',
      'shops', 'products', 'cart', 'orders', 'topics', 'replies',
      'notices', 'noticeDismiss', 'snapshots'];
    var counts = {};
    STORE_NAMES.forEach(function (k) {
      counts[k] = Array.isArray(data[k]) ? data[k].length : 0;
    });
    var list = function (k) { return Array.isArray(data[k]) ? data[k] : []; };
    var realUsers = list('users').filter(function (u) {
      return u && !/^__/.test(u.username || '');
    });
    var realIds = {};
    realUsers.forEach(function (u) { realIds[u.id] = true; });
    return {
      counts: counts,
      realUserCount: realUsers.length,
      personal: {
        courses: list('courses').length,
        memos: list('memos').length,
        orders: list('orders').length,
        cart: list('cart').length,
        topics: list('topics').filter(function (t) { return realIds[t.authorId]; }).length,
        replies: list('replies').filter(function (r) { return realIds[r.authorId]; }).length
      }
    };
  }

  // 是否存在值得迁移的个人数据（真实账户，或课程/备忘/订单/购物车/个人发帖）
  function hasPersonalData(stats) {
    if (!stats) return false;
    if (stats.realUserCount > 0) return true;
    var p = stats.personal || {};
    return Object.keys(p).some(function (k) { return p[k] > 0; });
  }

  async function migrateRepo(target, source) {
    if (!target || typeof target.replaceAll !== 'function') {
      throw new Error('目标数据库不可用，迁移已取消');
    }
    if (!source || typeof source.exportAll !== 'function') {
      throw new Error('本机浏览器数据库不可用，迁移已取消');
    }
    if (typeof source.open === 'function') await source.open();
    var data = await source.exportAll();
    if (!data || typeof data !== 'object') {
      throw new Error('未能读取本机数据，迁移已取消');
    }
    if (!Array.isArray(data.users)) {
      throw new Error('本机数据结构异常（缺少 users），为安全起见已取消迁移');
    }
    var stats = summarizeMigration(data);
    // 整库替换写入目标（单事务，失败回滚，目标原有数据不受半成品影响）
    await target.replaceAll(data);
    return stats;
  }

  /* ---------------- 浏览器启动安装 ---------------- */
  function showFallbackBanner() {
    if (typeof document === 'undefined') return;
    function add() {
      if (document.getElementById('__db_fallback_banner')) return;
      var d = document.createElement('div');
      d.id = '__db_fallback_banner';
      d.style.cssText =
        'position:fixed;left:50%;top:8px;transform:translateX(-50%);z-index:99999;' +
        'max-width:92%;background:#fff3cd;color:#8a6d3b;border:1px solid #ffe08a;' +
        'border-radius:10px;padding:8px 14px;font-size:13px;line-height:1.5;' +
        'box-shadow:0 4px 16px rgba(0,0,0,.15);font-family:sans-serif;text-align:center;';
      d.textContent = '未连接后端数据库，当前为浏览器本地模式；请运行「启动校园App.bat」后刷新，以使用 MySQL。';
      document.body.appendChild(d);
    }
    if (document.body) add();
    else window.addEventListener('DOMContentLoaded', add);
  }

  function install(AppDB, RepoCtor) {
    if (!AppDB || AppDB.__httpInstalled || typeof AppDB.boot !== 'function') return;
    AppDB.__httpInstalled = true;
    var idbBoot = AppDB.boot.bind(AppDB);

    function dbMode() {
      try {
        return new URLSearchParams(window.location.search).get('db') || 'auto';
      } catch (e) {
        return 'auto';
      }
    }

    AppDB.boot = async function (idbFactory) {
      var mode = dbMode();
      if (mode === 'local') return idbBoot(idbFactory);
      try {
        var repo = new RepoCtor();
        await repo.open();
        var svc = AppDB.createServices(repo);
        await svc.seed.ensure();
        window.__APP_DB_MODE = 'http';
        return { repo: repo, svc: svc };
      } catch (err) {
        if (mode === 'http') {
          throw new Error('无法连接后端数据库服务（' + (err && err.message) +
            '）。请先双击「启动校园App.bat」启动后端，再刷新页面。');
        }
        console.warn('[完美诚毅] 后端服务不可用，回退到浏览器本地数据库（IndexedDB）：', err);
        window.__APP_DB_MODE = 'local-fallback';
        showFallbackBanner();
        return idbBoot(idbFactory);
      }
    };
  }

  var api = {
    HttpRepo: HttpRepo,
    install: install,
    migrateRepo: migrateRepo,
    summarizeMigration: summarizeMigration,
    hasPersonalData: hasPersonalData
  };

  if (typeof window !== 'undefined' && window.AppDB) {
    install(window.AppDB, HttpRepo);
  }

  return api;
});
